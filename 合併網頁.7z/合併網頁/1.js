// 模擬使用者數據
const users = {};
let currentUser = null;

// 資源庫（模擬檔案上傳，僅在前端進行）
let resources = [];
let friends = [];

// 聊天室訊息
let messages = [];

// 登入處理
document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();  // 阻止表單提交後頁面刷新
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    
    // 驗證使用者帳號和密碼
    if (users[username] && users[username].password === password) {
        currentUser = users[username];  // 設定當前用戶為登錄用戶
        showMenuPage();  // 顯示主選單頁面
    } else {
        alert("帳號或密碼錯誤");
    }
});

// 註冊處理
document.getElementById("register-form").addEventListener("submit", function(event) {
    event.preventDefault();  // 阻止表單提交後頁面刷新
    const username = document.getElementById("new-username").value;
    const password = document.getElementById("new-password").value;
    const name = document.getElementById("name").value;
    const role = document.getElementById("role").value;
    
    // 檢查帳號是否存在
    if (!users[username]) {
        users[username] = { password: password, name: name, role: role, friends: [], messages: [] };
        currentUser = users[username];  // 註冊成功後自動登入
        alert("註冊成功");
        showMenuPage();  // 顯示主選單頁面
    } else {
        alert("帳號已存在");
    }
});

// 切換到註冊頁面
document.getElementById("register-link").addEventListener("click", function() {
    hideAllPages();  // 隱藏所有頁面
    document.getElementById("register-page").style.display = "block";  // 顯示註冊頁面
});

// 切換回登入頁面
document.getElementById("login-link").addEventListener("click", function() {
    hideAllPages();  // 隱藏所有頁面
    document.getElementById("login-page").style.display = "block";  // 顯示登入頁面
});

// 功能選單處理
document.getElementById("llm-btn").addEventListener("click", function() {
    window.location.href = "llm.html";  // 導航到 llm.html 頁面
});
document.getElementById("resources-btn").addEventListener("click", function() {
    showResourcesPage();  // 顯示資源庫頁面
});
document.getElementById("chatroom-btn").addEventListener("click", function() {
    showChatPage();  // 顯示即時聊天室頁面
});
document.getElementById("social-btn").addEventListener("click", function() {
    showSocialPage();  // 顯示社交頁面
});
document.getElementById("forum-btn").addEventListener("click", function() {
    showForumPage();  // 顯示論壇頁面
});

// LLM 功能提交處理
document.getElementById("submit-llm-query").addEventListener("click", function() {
    const query = document.getElementById("llm-query").value;  // 獲取用戶輸入的查詢
    if (query.trim() === "") {
        alert("請輸入問題");  // 提示用戶輸入問題
        return;
    }

    // 發送查詢請求給後端
    fetch('/llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: query })  // 將查詢轉換為 JSON 發送
    })
    .then(response => response.json())
    .then(data => {
        const llmResponse = data.response || "無法生成回應。";
        document.getElementById("llm-response").innerText = llmResponse;  // 顯示回應
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById("llm-response").innerText = "出錯了，請稍後再試。";
    });
});

// 即時聊天室處理
document.getElementById("send-btn").addEventListener("click", function() {
    const messageInput = document.getElementById("message-input");
    const messageText = messageInput.value.trim();
    
    if (messageText !== "") {
        messages.push({ user: currentUser.name, text: messageText });  // 添加新訊息
        displayMessages();  // 顯示訊息
        messageInput.value = '';  // 清空輸入框
    }
});

function displayMessages() {
    const messageContainer = document.getElementById("messages");
    messageContainer.innerHTML = '';  // 清空現有訊息
    messages.forEach(message => {
        const messageElement = document.createElement("p");
        messageElement.textContent = `${message.user}: ${message.text}`;  // 顯示訊息
        messageContainer.appendChild(messageElement);
    });
}

// 資源庫處理 - 檢視文件
function viewResource(resourceName) {
    fetch(`/uploads/${resourceName}`)  // 從後端檢索文件內容
    .then(response => response.text())  // 將文件轉為文字顯示
    .then(data => {
        alert(`檢視檔案內容：\n${data}`);  // 顯示文件內容
    })
    .catch(error => {
        alert("無法檢視此檔案類型");
        console.error('Error:', error);
    });
}

// 返回主選單處理
document.getElementById("back-to-menu-btn").addEventListener("click", function() {
    showMenuPage();  // 顯示主選單頁面
});
document.getElementById("back-to-menu-btn-llm").addEventListener("click", function() {
    showMenuPage();  // 返回主選單
});
document.getElementById("back-to-menu-btn-chat").addEventListener("click", function() {
    showMenuPage();  // 返回主選單
});
document.getElementById("back-to-menu-btn-social").addEventListener("click", function() {
    showMenuPage();  // 返回主選單
});
document.getElementById("back-to-menu-btn-forum").addEventListener("click", function() {
    showMenuPage();  // 返回主選單
});

// 功能顯示頁面
function showMenuPage() {
    hideAllPages();
    document.getElementById("menu-page").style.display = "block";  // 顯示主選單頁面
}

function showLlmPage() {
    hideAllPages();
    document.getElementById("llm-page").style.display = "block";  // 顯示LLM頁面
}

function showResourcesPage() {
    hideAllPages();
    document.getElementById("resources-page").style.display = "block";  // 顯示資源庫頁面
    displayResources();
    if (currentUser.role === 'teacher' || currentUser.role === '助教') {
        document.getElementById("upload-resources").style.display = "block";  // 顯示上傳按鈕
    } else {
        document.getElementById("upload-resources").style.display = "none";  // 隱藏上傳按鈕
    }
}

function showChatPage() {
    hideAllPages();
    document.getElementById("chat-page").style.display = "block";  // 顯示聊天室頁面
    displayMessages();
}

function showSocialPage() {
    hideAllPages();
    document.getElementById("social-page").style.display = "block";  // 顯示社交頁面
    displayFriends();
}

function showForumPage() {
    hideAllPages();
    document.getElementById("forum-page").style.display = "block";  // 顯示論壇頁面
    loadPosts();  // 加載所有文章
}

// 隱藏所有頁面
function hideAllPages() {
    document.getElementById("menu-page").style.display = "none";
    document.getElementById("llm-page").style.display = "none";
    document.getElementById("resources-page").style.display = "none";
    document.getElementById("chat-page").style.display = "none";
    document.getElementById("social-page").style.display = "none";
    document.getElementById("forum-page").style.display = "none";
    document.getElementById("login-page").style.display = "none";
    document.getElementById("register-page").style.display = "none";
}

// 資源庫顯示和處理
function displayResources() {
    const resourcesList = document.getElementById("resources-list");
    resourcesList.innerHTML = '';  // 清空現有資源
    resources.forEach(resource => {
        const resourceItem = document.createElement("li");
        resourceItem.textContent = resource.name;

        const downloadBtn = document.createElement("button");
        downloadBtn.textContent = "下載";
        downloadBtn.addEventListener("click", function() {
            window.open(`/uploads/${resource.name}`, '_blank');  // 下載文件
        });

        const viewBtn = document.createElement("button");
        viewBtn.textContent = "檢視";
        viewBtn.addEventListener("click", function() {
            viewResource(resource.name);  // 檢視文件內容
        });

        resourceItem.appendChild(downloadBtn);
        resourceItem.appendChild(viewBtn);
        resourcesList.appendChild(resourceItem);  // 顯示每個資源
    });
}

// 社交功能 - 顯示好友
function displayFriends() {
    const friendList = document.getElementById("friend-list");
    friendList.innerHTML = '';  // 清空現有好友列表
    friends.forEach(friend => {
        const friendItem = document.createElement("li");
        friendItem.textContent = friend;
        friendList.appendChild(friendItem);  // 顯示每個好友
    });
}

// 添加好友功能
document.getElementById("add-friend-btn").addEventListener("click", function() {
    const friendName = document.getElementById("add-friend-input").value;
    if (friendName.trim() !== "") {
        friends.push(friendName);  // 添加好友
        displayFriends();  // 顯示好友列表
        document.getElementById("add-friend-input").value = '';  // 清空輸入框
    }
});

// 資源上傳功能
document.getElementById("upload-btn").addEventListener("click", function() {
    const fileInput = document.getElementById("file-input");
    const file = fileInput.files[0];
    if (file) {
        resources.push({ name: file.name });  // 添加資源到資源庫
        displayResources();  // 顯示資源
        fileInput.value = '';  // 清空文件選擇
    }
});

// 帖子數據存儲
let posts = [];

// 發佈文章處理
document.getElementById("post-form").addEventListener("submit", function(event) {
    event.preventDefault();  // 阻止表單提交後頁面刷新
    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;
    const tags = document.getElementById("tags").value.split(',').map(tag => tag.trim());  // 用逗號分隔標籤

    // 發佈新文章
    const newPost = {
        author: currentUser.name,
        title: title,
        content: content,
        tags: tags,
        timestamp: new Date().toISOString()  // 記錄發佈時間
    };

    posts.push(newPost);  // 添加到文章列表
    loadPosts();  // 更新文章顯示
    alert("文章發佈成功");
});

// 加載並顯示文章列表
function loadPosts() {
    const postList = document.getElementById("post-list");
    postList.innerHTML = '';  // 清空現有文章

    // 將文章按時間順序顯示
    posts.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));

    posts.forEach(post => {
        const postItem = document.createElement("li");
        postItem.innerHTML = `
            <h3>${post.title} - ${post.author}</h3>
            <p>${post.content}</p>
            <p>標籤: ${post.tags.join(', ')}</p>
            <small>發佈時間: ${new Date(post.timestamp).toLocaleString()}</small>
        `;
        postList.appendChild(postItem);  // 顯示每篇文章
    });
}

// 預設顯示登入頁面
hideAllPages();
document.getElementById("login-page").style.display = "block";  // 預設顯示登入頁面
