# =============================================================================
# 模組導入與初始化
# =============================================================================
import os
import random
import re
import time
import datetime
import mimetypes
import json
import uuid
import numpy as np

# 文件嵌入與相似度檢索（RAG 相關）
from sentence_transformers import SentenceTransformer, util

# 資料庫連線
import mysql.connector

# Flask 相關模組
from flask import (
    Flask, render_template, request, jsonify, send_from_directory,
    session, redirect, url_for, g, Response, copy_current_request_context
)
from flask_session import Session
from flask_cors import CORS
from flask_socketio import SocketIO, send

# 密碼安全與檔案處理
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

# PDF 文件讀取
from PyPDF2 import PdfReader

# 翻譯功能
from deep_translator import GoogleTranslator

# Selenium 用於爬取新聞
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

# LLM API 客戶端（例如 OpenAI）
from openai import OpenAI

# =============================================================================
# Dummy 資料庫設定（供無真實資料庫時使用）
# =============================================================================
USE_DUMMY_DB = False

if USE_DUMMY_DB:
    dummy_users = [
        {
            "id": 1,
            "username": "test",
            "password_hash": generate_password_hash("test"),
            "role": "student",
            "full_name": "測試學生"
        },
        {
            "id": 2,
            "username": "teacher",
            "password_hash": generate_password_hash("teacher"),
            "role": "teacher",
            "full_name": "測試老師"
        }
    ]
    dummy_courses = [
        {"id": 1, "course_name": "示範課程", "description": "這是一個示範課程", "teacher_id": 2}
    ]
    dummy_enrollments = [
        {"student_id": 1, "course_id": 1, "status": "approved"}
    ]
    dummy_db = {
        "users": dummy_users,
        "courses": dummy_courses,
        "enrollments": dummy_enrollments,
    }
    print("使用 dummy 資料庫，預設學生帳號：test/test；老師帳號：teacher/teacher")
else:
    print("使用真實 MySQL 資料庫")

# =============================================================================
# Flask App 初始化與配置
# =============================================================================
app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# 設定上傳、RAG 文件與教材資料夾
UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
RAG_FOLDER = os.path.join(os.getcwd(), 'documents')
MATERIAL_UPLOAD_FOLDER = os.path.join(os.getcwd(), 'static', 'materials')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RAG'] = RAG_FOLDER
app.config['MATERIAL_UPLOAD_FOLDER'] = MATERIAL_UPLOAD_FOLDER
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RAG_FOLDER, exist_ok=True)
os.makedirs(MATERIAL_UPLOAD_FOLDER, exist_ok=True)

# 翻譯語言對照字典
languages = {
    'en': '英語',
    'zh-cn': '簡體中文',
    'zh-tw': '繁體中文',
    'es': '西班牙語',
    'fr': '法語',
    'de': '德語',
    'ja': '日語',
    'ko': '韓語',
    'ru': '俄語',
    'ar': '阿拉伯語',
    'pt': '葡萄牙語',
    'it': '意大利語',
    'nl': '荷蘭語',
    'tr': '土耳其語',
    'hi': '印地語',
    'bn': '孟加拉語',
    'vi': '越南語',
    'pl': '波蘭語',
    'ro': '羅馬尼亞語',
    'th': '泰語',
    'id': '印尼語',
    'ms': '馬來語',
    'uk': '烏克蘭語',
    'el': '希臘語',
    'sv': '瑞典語',
    'fi': '芬蘭語',
    'da': '丹麥語',
    'no': '挪威語',
    'hu': '匈牙利語',
    'cs': '捷克語'
}

# =============================================================================
# OpenAI 客戶端初始化
# =============================================================================
client = OpenAI(base_url="http://127.0.0.1:1234/v1", api_key="lm-studio")

# =============================================================================
# 資料庫連線管理
# =============================================================================
def get_db():
    """
    如果使用 dummy 模式，直接回傳 dummy_db；
    否則建立 MySQL 連線並儲存在 g 物件中
    """
    if USE_DUMMY_DB:
        return dummy_db
    if 'db' not in g or g.db is None:
        try:
            g.db = mysql.connector.connect(
                host="localhost",
                user="root",
                password="Jus08210821",
                database="users"
            )
            print("✅ MySQL 連線成功！")
        except mysql.connector.Error as err:
            print(f"❌ MySQL 連線失敗: {err}")
            g.db = None
    return g.db

@app.teardown_request
def teardown_request(exception):
    if not USE_DUMMY_DB:
        db_conn = g.pop('db', None)
        if db_conn is not None:
            try:
                db_conn.close()
                print("✅ MySQL 連線已關閉")
            except Exception as e:
                print(f"⚠️ 關閉 MySQL 連線時發生錯誤: {e}")

def allowed_file(filename):
    """檢查檔案副檔名是否允許上傳"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# =============================================================================
# 翻譯功能與頁面
# =============================================================================
def translate_text(text, source_language, target_language):
    """呼叫翻譯 API 將文字從 source_language 翻譯成 target_language"""
    try:
        translated_text = GoogleTranslator(source=source_language, target=target_language).translate(text)
        return translated_text
    except Exception as e:
        return f"翻譯時發生錯誤: {str(e)}"

@app.route('/api/translate', methods=['POST'])
def translate_api():
    data = request.get_json()
    text = data.get("text")
    source_language = data.get("source_language")
    target_language = data.get("target_language")
    if not text or not source_language or not target_language:
        return jsonify({'error': '缺少必要參數'}), 400
    translated_text = translate_text(text, source_language, target_language)
    return jsonify({'translated_text': translated_text})

@app.route('/translate')
def translate_page():
    """翻譯頁面"""
    return render_template('translate.html', languages=languages)

# =============================================================================
# 文件庫與 RAG 功能（文件讀取、檢索與 LLM 對話）
# =============================================================================
def load_documents_from_directory(directory_path):
    """
    從指定目錄讀取所有 TXT 與 PDF 文件，並回傳非空文件內容列表
    """
    documents = []
    for filename in os.listdir(directory_path):
        file_path = os.path.join(directory_path, filename)
        if not os.path.isfile(file_path):
            continue
        ext = os.path.splitext(filename)[1].lower()
        if ext == '.txt':
            documents.append(read_txt(file_path))
        elif ext == '.pdf':
            documents.append(read_pdf(file_path))
    return [doc for doc in documents if doc.strip()]

def read_txt(file_path):
    """讀取 TXT 文件內容"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"⚠️ 無法讀取 TXT 檔案 {file_path}: {e}")
        return ""

def read_pdf(file_path):
    """讀取 PDF 文件內容"""
    pdf_text = ""
    try:
        with open(file_path, 'rb') as file:
            reader = PdfReader(file)
            for page in reader.pages:
                pdf_text += page.extract_text() or ""
    except Exception as e:
        print(f"⚠️ 無法讀取 PDF 檔案 {file_path}: {e}")
    return pdf_text

# 初始化嵌入模型（此處使用 'all-MiniLM-L6-v2'）
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

def retrieve_documents(query, top_k=2, threshold=0.2):
    """
    根據查詢透過嵌入模型與 cosine 相似度，從文件庫中檢索相關文件
    只返回相似度高於閾值的文件，並印出各文件相似度
    """
    documents = load_documents_from_directory(app.config['RAG'])
    if not documents:
        return []
    # 計算所有文件的向量
    doc_embeddings = embedding_model.encode(documents, convert_to_tensor=True)
    # 計算查詢的向量
    query_embedding = embedding_model.encode(query, convert_to_tensor=True)
    # 計算 cosine 相似度
    cosine_scores = util.pytorch_cos_sim(query_embedding, doc_embeddings)[0]
    # 取得相似度最高的 top_k 個文件索引
    top_results = np.argpartition(-cosine_scores.cpu().numpy(), range(top_k))[:top_k]
    relevant_docs = []
    for idx in top_results:
        score = cosine_scores[idx].item()
        print(f"文件 {idx} 的相似度: {score:.4f}")
        if score >= threshold:
            relevant_docs.append(documents[idx])
            print(f"選擇文件 {idx}，相似度: {score:.4f}")
        else:
            print(f"文件 {idx} 相似度低於閾值 {threshold}，不使用")
    return relevant_docs






def is_arithmetic_query(query):
    """
    判斷查詢是否為算術運算題，僅包含數字與基本運算符號
    """
    cleaned = query.replace("=", "").replace("?", "").strip()
    allowed_chars = "0123456789+-*/(). "
    return all(char in allowed_chars for char in cleaned)

# ---------------------------------------------------------------------------
# 使用 LLM 流式生成回應（整合 RAG 與對話功能）
# ---------------------------------------------------------------------------
def generate_response_with_llm_stream(query, retrieved_docs, conversation_history):
    """
    根據查詢生成回應：
      - 若查詢為算術題則直接計算並回傳結果
      - 否則組合 RAG 摘要與查詢內容，呼叫 LLM 並以流式方式返回回答，
        同時要求模型直接返回最終答案，不包含任何 <think> 相關內容，且回答必須以繁體中文呈現
    """
    if is_arithmetic_query(query):
        expr = query.replace("=", "").replace("?", "").strip()
        try:
            answer = eval(expr)
            yield json.dumps({'response': str(answer)})
        except Exception as e:
            yield json.dumps({'response': "計算錯誤"})
    else:
        input_text = f"查詢：{query}\n"
        if retrieved_docs:
            input_text += "以下為RAG資料庫中部分相關資訊摘要（僅供參考）：\n"
            for idx, doc in enumerate(retrieved_docs, start=1):
                excerpt = doc[:1000]
                input_text += f"[文件{idx}摘要]：{excerpt}\n"
        # 修改系統提示，要求不要輸出任何 <think> 區段，並以繁體中文回答
        system_message = ("你是一位知識豐富且表達精簡的助教，請加快你的思考速度，請直接返回最終答案，"
                          "不要輸出任何內部思考或推理過程，也不要包含任何 <think> 標籤及其內容，"
                          "並且回答必須以繁體中文呈現。")
        try:
            completion = client.chat.completions.create(
                model="deepseek-r1-distill-qwen-32b",
                messages=[
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": input_text}
                ],
                temperature=0.2,
                stream=True
            )
            full_response = ""
            # 逐步處理 LLM 流式回應
            for chunk in completion:
                # 檢查 chunk 是否有 choices
                if hasattr(chunk, 'choices') and len(chunk.choices) > 0:
                    delta = chunk.choices[0].delta
                    content = delta.content or ""
                    if content:
                        # 移除回應中的 <think> 區段
                        cleaned_content = re.sub(r'<think>.*?</think>', '', content, flags=re.DOTALL).strip()
                        full_response += cleaned_content
                        yield json.dumps({'response': cleaned_content})
                elif isinstance(chunk, dict) and "choices" in chunk and len(chunk["choices"]) > 0:
                    delta = chunk["choices"][0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        cleaned_content = re.sub(r'<think>.*?</think>', '', content, flags=re.DOTALL).strip()
                        full_response += cleaned_content
                        yield json.dumps({'response': cleaned_content})
            # 最後再確保整體回應中移除 <think> 區段
            full_response = re.sub(r'<think>.*?</think>', '', full_response, flags=re.DOTALL).strip()
            print(f"最終回答（繁體中文）：{full_response}")
            conversation_history.append({"role": "assistant", "content": full_response})
        except Exception as e:
            yield json.dumps({'error': f"LLM API 錯誤: {str(e)}"})


@app.route('/llm', methods=['POST'])
def llm_query():
    """
    /llm 路由：接收查詢，利用 RAG 檢索文件並透過 LLM 以流式方式回傳回答
    """
    query = request.json.get('query')
    if not query:
        return jsonify({'error': '未提供查詢內容'}), 400
    conversation_history = session.get('conversation_history', [])
    conversation_history.append({"role": "user", "content": query})
    retrieved_docs = retrieve_documents(query)
    session['conversation_history'] = conversation_history

    def generate():
        for chunk in generate_response_with_llm_stream(query, retrieved_docs, conversation_history):
            yield f"{chunk}\n"  # 每個回應加上換行符方便前端解析

    return Response(generate(), mimetype="application/json")

@app.route('/clear_history', methods=['POST'])
def clear_history():
    """清除 LLM 對話歷史記錄"""
    session.pop('conversation_history', None)
    return jsonify({'status': '記憶已清除'})

@app.route('/llm')
def llm_page():
    """LLM 對話頁面"""
    return render_template('llm.html')

# =============================================================================
# 使用者認證與基本頁面
# =============================================================================
@app.route('/register', methods=['POST'])
def register():
    """
    使用者註冊 API：接收 username、password、full_name 與 role
    """
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    full_name = data.get('full_name')
    role = data.get('role')
    if role not in ['student', 'teacher']:
        return jsonify({'error': '無效的角色'}), 400
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()
    if user:
        return jsonify({'error': '帳號已存在'}), 400
    password_hash = generate_password_hash(password)
    cursor.execute(
        "INSERT INTO users (username, password_hash, full_name, role) VALUES (%s, %s, %s, %s)",
        (username, password_hash, full_name, role)
    )
    db.commit()
    return jsonify({'status': '註冊成功'}), 201

@app.route('/login', methods=['POST'])
def login():
    """
    使用者登入 API：檢查帳號密碼，並將必要資訊存入 session
    """
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if USE_DUMMY_DB:
        for user in dummy_db["users"]:
            if user["username"] == username and check_password_hash(user["password_hash"], password):
                session['user_id'] = user["id"]
                session['user'] = user["username"]
                session['role'] = user["role"]
                session['full_name'] = user["full_name"]
                return jsonify({
                    'status': '登入成功',
                    'user_id': user["id"],
                    'username': user["username"],
                    'full_name': user["full_name"],
                    'role': user["role"]
                }), 200
        return jsonify({'error': '帳號或密碼錯誤'}), 401
    else:
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT id, username, password_hash, role, full_name FROM users WHERE username = %s", (username,))
        user = cursor.fetchone()
        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['user'] = user[1]
            session['role'] = user[3]
            session['full_name'] = user[4]
            return jsonify({
                'status': '登入成功',
                'user_id': user[0],
                'username': user[1],
                'full_name': user[4],
                'role': user[3]
            }), 200
        else:
            return jsonify({'error': '帳號或密碼錯誤'}), 401

@app.route('/')
def log_page():
    """登入頁面"""
    return render_template('log.html')

@app.route('/home')
def home():
    """
    主頁面：根據 session 判斷使用者狀態與角色
    """
    if 'user' not in session:
        return redirect(url_for('log_page'))
    if USE_DUMMY_DB:
        user_role = session.get('role')
    else:
        username = session['user']
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT role FROM users WHERE username = %s", (username,))
        result = cursor.fetchone()
        if not result:
            return redirect(url_for('log_page'))
        user_role = result[0]
    return render_template('home.html', user_role=user_role)

# =============================================================================
# 檔案上傳與資源管理
# =============================================================================
@app.route('/upload', methods=['POST'])
def upload_file():
    """單純上傳檔案"""
    if 'file' not in request.files:
        return jsonify({'error': '沒有找到文件部分'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': '未選擇文件'}), 400
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)
    return jsonify({'filename': file.filename})

@app.route('/files', methods=['GET'])
def list_files():
    """回傳上傳目錄中所有檔案列表"""
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    return jsonify({'files': files})

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    """根據檔名下載上傳的檔案"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/resources')
def resources_page():
    """資源庫頁面，需登入才能進入"""
    if 'user_id' not in session:
        return redirect(url_for('log_page'))
    return render_template('resources.html')

@app.route('/upload-resource', methods=['POST'])
def upload_resource():
    """
    上傳資源 API：接收檔案、課程編號、分類等，儲存檔案並記錄資料庫
    """
    course_id = request.form.get('course_id')
    user_id = session.get('user_id') or request.form.get('user_id') or 1
    file = request.files.get('file')
    category = request.form.get('category') or "其他"
    if not course_id or not file:
        return 'Missing data', 400
    resource_name = file.filename
    resource_type = file.content_type
    filename = file.filename
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    try:
        file.save(save_path)
    except Exception as e:
        print(e)
        return 'File save error', 500
    db = get_db()
    try:
        cursor = db.cursor(dictionary=True)
        sql = """
            INSERT INTO resources (course_id, user_id, resource_name, resource_type, category, file_path)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(sql, (course_id, user_id, resource_name, resource_type, category, save_path))
        db.commit()
        cursor.close()
    except Exception as e:
        print(e)
        return 'Database error', 500
    return 'OK', 200

@app.route('/list-resources', methods=['GET'])
def list_resources():
    """取得指定課程的所有資源列表"""
    course_id = request.args.get('courseId')
    if not course_id:
        return jsonify([])
    db = get_db()
    try:
        cursor = db.cursor(dictionary=True)
        sql = """
            SELECT id, course_id, user_id, resource_name, resource_type, category, file_path, uploaded_at
            FROM resources
            WHERE course_id = %s
            ORDER BY uploaded_at DESC
        """
        cursor.execute(sql, (course_id,))
        rows = cursor.fetchall()
        cursor.close()
    finally:
        pass
    return jsonify(rows)

@app.route('/delete-resource', methods=['DELETE'])
def delete_resource():
    """
    刪除資源 API：僅允許上傳者刪除自己的資源
    """
    data = request.get_json()
    resource_id = data.get('resource_id')
    user_id = data.get('user_id') or session.get('user_id')
    if not resource_id or not user_id:
        return 'Missing data', 400
    db = get_db()
    try:
        cursor = db.cursor(dictionary=True)
        sql = "SELECT file_path, user_id FROM resources WHERE id = %s"
        cursor.execute(sql, (resource_id,))
        resource = cursor.fetchone()
        if not resource:
            return 'Resource not found', 404
        if str(resource['user_id']) != str(user_id):
            return 'Unauthorized', 403
        sql_delete = "DELETE FROM resources WHERE id = %s"
        cursor.execute(sql_delete, (resource_id,))
        db.commit()
        cursor.close()
    except Exception as e:
        print(e)
        return 'Database error', 500
    file_path = resource.get('file_path')
    if file_path and os.path.exists(file_path):
        try:
            os.remove(file_path)
        except Exception as e:
            print("Failed to delete file:", e)
    return 'OK', 200

@app.route('/update-resource-category', methods=['POST'])
def update_resource_category():
    """
    更新資源分類 API：僅允許上傳者更新自己的資源分類
    """
    data = request.get_json()
    resource_id = data.get('resource_id')
    new_category = data.get('new_category')
    user_id = data.get('user_id') or session.get('user_id')
    if not resource_id or not new_category or not user_id:
        return 'Missing data', 400
    db = get_db()
    try:
        cursor = db.cursor(dictionary=True)
        sql = "SELECT user_id FROM resources WHERE id = %s"
        cursor.execute(sql, (resource_id,))
        resource = cursor.fetchone()
        if not resource:
            return 'Resource not found', 404
        if str(resource['user_id']) != str(user_id):
            return 'Unauthorized', 403
        sql_update = "UPDATE resources SET category = %s WHERE id = %s"
        cursor.execute(sql_update, (new_category, resource_id))
        db.commit()
        cursor.close()
    except Exception as e:
        print(e)
        return 'Database error', 500
    return 'OK', 200

@app.route('/view-resource/<int:resource_id>', methods=['GET'])
def view_resource(resource_id):
    """
    內嵌預覽資源：依據資源 ID 顯示檔案內容（不作為附件下載）
    """
    db = get_db()
    try:
        cursor = db.cursor(dictionary=True)
        sql = "SELECT file_path, resource_name FROM resources WHERE id = %s"
        cursor.execute(sql, (resource_id,))
        resource = cursor.fetchone()
        cursor.close()
        if not resource:
            abort(404)
    finally:
        pass
    file_path = resource.get('file_path')
    if not file_path or not os.path.exists(file_path):
        abort(404)
    return send_from_directory(app.config['UPLOAD_FOLDER'], os.path.basename(file_path), as_attachment=False)

@app.route('/download-resource/<int:resource_id>', methods=['GET'])
def download_resource(resource_id):
    """
    資源下載：以附件方式下載指定資源
    """
    db = get_db()
    try:
        cursor = db.cursor(dictionary=True)
        sql = "SELECT file_path, resource_name FROM resources WHERE id = %s"
        cursor.execute(sql, (resource_id,))
        resource = cursor.fetchone()
        cursor.close()
        if not resource:
            abort(404)
    finally:
        pass
    file_path = resource.get('file_path')
    if not file_path or not os.path.exists(file_path):
        abort(404)
    return send_from_directory(app.config['UPLOAD_FOLDER'], os.path.basename(file_path), as_attachment=True, download_name=resource.get('resource_name'))

# =============================================================================
# Selenium 爬取 AI 相關新聞功能
# =============================================================================
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

@app.route('/fetch_ai_news', methods=['GET'])
def fetch_ai_news():
    """
    爬取新聞 API：使用 Selenium 從 Google News 搜尋結果中抓取前 4 筆新聞資訊
    """
    options = Options()
    # 若需要預覽視窗，取消 headless 模式（此處預設不使用 headless）
    options.add_argument("--headless")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    try:
        driver.get("https://news.google.com/search?q=機器學習&hl=zh-TW&gl=TW&ceid=TW:zh-Hant")
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "article"))
        )
        articles = driver.find_elements(By.CSS_SELECTOR, "article")[:4]
        news_list = []
        for idx, article in enumerate(articles, start=1):
            try:
                try:
                    title_elem = article.find_element(By.CSS_SELECTOR, "a.JtKRv")
                except Exception as e:
                    print(f"無法用 CSS 找到標題 {idx}: {e}")
                    links = article.find_elements(By.TAG_NAME, "a")
                    title_elem = None
                    for l in links:
                        if l.text.strip():
                            title_elem = l
                            break
                    if title_elem is None:
                        print(f"Article {idx} HTML:", article.get_attribute("outerHTML"))
                        raise Exception("找不到符合條件的連結")
                title = title_elem.text.strip()
                link = title_elem.get_attribute("href")
                try:
                    image_elem = article.find_element(By.CSS_SELECTOR, "img")
                    image_url = image_elem.get_attribute("src")
                except Exception:
                    image_url = "/static/images/default.jpg"
                news_list.append({
                    "title": title,
                    "link": link,
                    "image_url": image_url
                })
            except Exception as e:
                print(f"無法處理新聞 {idx}: {e}")
        return jsonify(news_list), 200
    except Exception as e:
        print(f"爬取新聞時出錯: {e}")
        driver.save_screenshot("error_screenshot.png")
        return jsonify({"error": "無法獲取新聞"}), 500
    finally:
        driver.quit()

# =============================================================================
# 論壇、留言與社交功能
# =============================================================================
@app.route('/forum')
def forum():
    """論壇頁面"""
    return render_template('forum.html')

@app.route('/code-compare')
def code_compare():
    """程式碼比較頁面"""
    return render_template('code-compare.html')

@app.route('/question')
def question():
    """單一問題頁面"""
    return render_template('question.html')

@app.route('/question-bank')
def question_bank():
    """問題庫頁面"""
    return render_template('question-bank.html')

@app.route('/materials')
def materials():
    """教材頁面，需傳入 course_id"""
    course_id = request.args.get('course_id')
    return render_template('materials.html', course_id=course_id)

@app.route('/homeworks')
def homeworks():
    """作業頁面"""
    return render_template('homeworks.html')

@app.route('/announcements')
def announcements():
    """公告頁面"""
    return render_template('announcements.html')

@app.route('/students')
def students():
    """學生管理頁面"""
    return render_template('students.html')

@app.route('/get_user_info', methods=['GET'])
def get_user_info():
    """取得當前使用者資訊"""
    if 'user_id' not in session:
        return jsonify({'error': '未登入'}), 401
    user_info = {
        "user_id": session['user_id'],
        "username": session['user'],
        "role": session['role'],
        "full_name": session['full_name']
    }
    return jsonify(user_info), 200

# =============================================================================
# 學生專用頁面
# =============================================================================
@app.route('/student-materials.html')
def student_materials():
    """學生教材頁面"""
    if 'user' not in session or session.get('role') != 'student':
        return redirect(url_for('log_page'))
    const_course_id = request.args.get('course_id')
    return render_template('student-materials.html', course_id=const_course_id)

@app.route('/student-homeworks.html', endpoint='student_homeworks')
def student_homeworks():
    """學生作業頁面"""
    return render_template('student-homeworks.html')

@app.route('/student-announcements.html')
def student_announcements():
    """學生公告頁面"""
    if 'user' not in session or session.get('role') != 'student':
        return redirect(url_for('log_page'))
    course_id = request.args.get('course_id')
    return render_template('student-announcements.html', course_id=course_id)

@app.route('/student-quizzes.html')
def student_quizzes_page():
    """學生測驗列表頁面"""
    if 'user' not in session or session.get('role') != 'student':
        return redirect(url_for('log_page'))
    course_id = request.args.get('course_id')
    return render_template('student-quizzes.html', course_id=course_id)

@app.route('/student-quiz-answer.html')
def student_quiz_answer():
    """學生作答頁面"""
    if 'user' not in session or session.get('role') != 'student':
        return redirect(url_for('log_page'))
    course_id = request.args.get('course_id')
    quiz_id = request.args.get('quiz_id')
    return render_template('student-quiz-answer.html', course_id=course_id, quiz_id=quiz_id)

@app.route('/student-quiz-view.html')
def student_quiz_view_page():
    """學生作答結果與檢視頁面"""
    if 'user' not in session or session.get('role') != 'student':
        return redirect(url_for('log_page'))
    course_id = request.args.get('course_id')
    quiz_id = request.args.get('quiz_id')
    return render_template('student-quiz-view.html', course_id=course_id, quiz_id=quiz_id)

# =============================================================================
# 測驗管理 API（教師／學生共用）
# =============================================================================
quizzes = {}  # 全域變數，用以暫存測驗資料（模擬資料庫，目前僅作示範）

@app.route('/get_quizzes', methods=['GET'])
def get_quizzes_endpoint():
    """
    取得指定課程下的所有測驗資料
    """
    course_id = request.args.get("course_id")
    if not course_id:
        return jsonify({"error": "必須提供 course_id"}), 400
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)
        sql = "SELECT id, name, description, created_at FROM quizzes WHERE course_id = %s"
        cursor.execute(sql, (course_id,))
        quizzes = cursor.fetchall()
        cursor.close()
        db.close()
        return jsonify(quizzes), 200
    except Exception as e:
        print("取得測驗列表失敗:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/upload_question', methods=['POST'])
def upload_question_endpoint():
    """
    上傳題目 API：教師上傳測驗題目，包含選擇題選項（若適用）
    """
    if 'user' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '未登入或無權限'}), 403
    data = request.get_json()
    if not data:
        return jsonify({"error": "未提供資料"}), 400
    quiz_id = data.get("quiz_id")
    question_type = data.get("question_type")
    question_text = data.get("question_text")
    score = data.get("score")
    options = data.get("options", [])
    question_order = 1
    if not quiz_id or not question_type or not question_text or score is None:
        return jsonify({"error": "缺少必要欄位"}), 400
    try:
        db = get_db()
        cursor = db.cursor()
        sql = """
            INSERT INTO questions (quiz_id, question_text, question_type, score, question_order)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(sql, (quiz_id, question_text, question_type, score, question_order))
        db.commit()
        question_id = cursor.lastrowid
        if question_type == "multiple_choice":
            if len(options) < 4:
                return jsonify({"error": "選擇題至少必須有 4 個選項"}), 400
            option_order = 1
            for opt in options:
                if "option_text" not in opt or "is_correct" not in opt:
                    return jsonify({"error": "選項格式錯誤"}), 400
                sql_opt = """
                    INSERT INTO options (question_id, option_text, is_correct, option_order)
                    VALUES (%s, %s, %s, %s)
                """
                cursor.execute(sql_opt, (question_id, opt["option_text"], opt["is_correct"], option_order))
                option_order += 1
            db.commit()
        cursor.close()
        db.close()
        return jsonify({"message": "題目上傳成功"}), 200
    except Exception as e:
        db.rollback()
        print("上傳題目失敗:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/update_question', methods=['PUT'])
def update_question_endpoint():
    """
    更新題目 API：教師可修改題目的內容與分數（選項更新功能可進一步擴充）
    """
    if 'user' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '未登入或無權限'}), 403
    data = request.get_json()
    if not data:
        return jsonify({"error": "未提供資料"}), 400
    quiz_id = data.get("id")
    question_id = data.get("question_id")
    new_text = data.get("question_text")
    new_score = data.get("score")
    if not quiz_id or not question_id or new_text is None or new_score is None:
        return jsonify({"error": "缺少必要欄位"}), 400
    try:
        db = get_db()
        cursor = db.cursor()
        sql = """
            UPDATE questions
            SET question_text = %s, score = %s
            WHERE id = %s AND quiz_id = %s
        """
        cursor.execute(sql, (new_text, new_score, question_id, quiz_id))
        db.commit()
        if cursor.rowcount == 0:
            return jsonify({"error": "找不到該題目"}), 404
        cursor.close()
        db.close()
        return jsonify({"message": "題目更新成功"}), 200
    except Exception as e:
        db.rollback()
        print("更新題目失敗:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/delete_question', methods=['DELETE'])
def delete_question_endpoint():
    """
    刪除題目 API：教師可刪除指定測驗題目
    """
    if 'user' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '未登入或無權限'}), 403
    data = request.get_json()
    if not data:
        return jsonify({"error": "未提供資料"}), 400
    quiz_id = data.get("id")
    question_id = data.get("question_id")
    if not quiz_id or not question_id:
        return jsonify({"error": "缺少必要欄位"}), 400
    try:
        db = get_db()
        cursor = db.cursor()
        sql = "DELETE FROM questions WHERE id = %s AND quiz_id = %s"
        cursor.execute(sql, (question_id, quiz_id))
        db.commit()
        if cursor.rowcount == 0:
            return jsonify({"error": "找不到該題目"}), 404
        cursor.close()
        db.close()
        return jsonify({"message": "題目刪除成功"}), 200
    except Exception as e:
        db.rollback()
        print("刪除題目失敗:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/finalize_quiz', methods=['POST'])
def finalize_quiz_endpoint():
    """
    最終建立測驗 API：檢查所有題目總分是否為 100 分，並標記測驗最終建立
    """
    if 'user' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '未登入或無權限'}), 403
    data = request.get_json()
    if not data:
        return jsonify({"error": "未提供資料"}), 400
    quiz_id = data.get("quiz_id")
    if not quiz_id:
        return jsonify({"error": "必須提供測驗ID (id)"}), 400
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)
        sql = "SELECT SUM(score) as total_score FROM questions WHERE quiz_id = %s"
        cursor.execute(sql, (quiz_id,))
        result = cursor.fetchone()
        total_score = result["total_score"] if result["total_score"] is not None else 0
        if total_score != 100:
            return jsonify({"error": f"題目總分必須等於 100，目前總分：{total_score}"}), 400
        sql_update = "UPDATE quizzes SET description = CONCAT(description, ' (已最終建立)') WHERE id = %s"
        cursor.execute(sql_update, (quiz_id,))
        db.commit()
        cursor.close()
        db.close()
        return jsonify({"message": "測驗最終建立成功", "total_score": total_score}), 200
    except Exception as e:
        db.rollback()
        print("Finalize quiz error:", e)
        return jsonify({"error": str(e)}), 500

@app.route('/get_quiz_questions', methods=['GET'])
def get_quiz_questions_endpoint():
    """
    取得指定測驗的所有題目與選項（以 JSON 格式回傳）
    """
    quiz_id = request.args.get("quiz_id")
    if not quiz_id:
        return jsonify({"error": "缺少必要的 quiz_id 欄位"}), 400
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)
        sql = """
            SELECT 
                q.id, 
                q.question_text, 
                q.question_type, 
                q.score, 
                q.question_order,
                IFNULL(
                    JSON_ARRAYAGG(
                        JSON_OBJECT(
                            'id', o.id, 
                            'option_text', o.option_text, 
                            'is_correct', o.is_correct, 
                            'option_order', o.option_order
                        )
                    ), '[]'
                ) AS options
            FROM questions q
            LEFT JOIN options o ON q.id = o.question_id
            WHERE q.quiz_id = %s
            GROUP BY q.id
            ORDER BY q.question_order
        """
        cursor.execute(sql, (quiz_id,))
        questions = cursor.fetchall()
        for question in questions:
            if isinstance(question.get("options"), str):
                try:
                    question["options"] = json.loads(question["options"])
                except Exception:
                    question["options"] = []
        return jsonify(questions), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# =============================================================================
# 學生測驗相關 API（教師/學生共用）
# =============================================================================
@app.route('/student/quizzes', methods=['GET'])
def student_quizzes():
    """
    取得指定課程下，學生的測驗列表，並標示是否已作答
    """
    if 'user_id' not in session:
        return jsonify({'error': '未登入'}), 403
    student_id = session['user_id']
    course_id = request.args.get("course_id")
    db = get_db()
    cursor = db.cursor(dictionary=True)
    sql = """
      SELECT q.id as quiz_id, q.name, q.description,
             IF(sqa.id IS NULL, 0, 1) as completed
      FROM quizzes q
      LEFT JOIN student_quiz_attempts sqa 
             ON q.id = sqa.quiz_id AND sqa.student_id = %s
      WHERE q.course_id = %s
      ORDER BY q.id
    """
    cursor.execute(sql, (student_id, course_id))
    quizzes = cursor.fetchall()
    cursor.close()
    return jsonify(quizzes), 200

@app.route('/student/quiz', methods=['GET'])
def student_quiz_view():
    """
    學生檢視單一測驗 API：回傳題目、選項以及已作答結果
    """
    if 'user_id' not in session:
        return jsonify({'error': '未登入'}), 403
    student_id = session['user_id']
    quiz_id = request.args.get("quiz_id")
    if not quiz_id:
        return jsonify({'error': '缺少 quiz_id'}), 400
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT id, name, description FROM quizzes WHERE id = %s", (quiz_id,))
    quiz = cursor.fetchone()
    if not quiz:
        return jsonify({'error': '找不到測驗'}), 404
    cursor.execute("""
        SELECT q.id as question_id, q.question_text, q.question_type, q.score
        FROM questions q
        WHERE q.quiz_id = %s
        ORDER BY q.question_order
    """, (quiz_id,))
    questions = cursor.fetchall()
    for q in questions:
        if q["question_type"] == "multiple_choice":
            cursor.execute("""
                SELECT id, option_text, is_correct, option_order
                FROM options
                WHERE question_id = %s
                ORDER BY option_order
            """, (q["question_id"],))
            q["options"] = cursor.fetchall()
    cursor.execute("""
       SELECT id as attempt_id, total_score
       FROM student_quiz_attempts
       WHERE quiz_id = %s AND student_id = %s
       ORDER BY attempt_date DESC LIMIT 1
    """, (quiz_id, student_id))
    attempt = cursor.fetchone()
    if attempt:
        cursor.execute("""
          SELECT question_id, chosen_option
          FROM student_quiz_answers
          WHERE attempt_id = %s
        """, (attempt["attempt_id"],))
        answers = cursor.fetchall()
        answer_map = { a["question_id"]: a["chosen_option"] for a in answers }
        for q in questions:
            q["student_answer"] = answer_map.get(q["question_id"])
        quiz["attempt"] = attempt
    cursor.close()
    quiz["questions"] = questions
    return jsonify(quiz), 200

@app.route('/student/quiz_submit', methods=['POST'])
def student_quiz_submit():
    """
    學生提交測驗答案 API：儲存答案並計算總分
    """
    if 'user_id' not in session:
        return jsonify({'error': '未登入'}), 403
    student_id = session['user_id']
    data = request.get_json()
    quiz_id = data.get("quiz_id")
    answers = data.get("answers")
    if not quiz_id or not answers:
        return jsonify({'error': '缺少必要欄位'}), 400
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
       INSERT INTO student_quiz_attempts (quiz_id, student_id, completed)
       VALUES (%s, %s, 1)
    """, (quiz_id, student_id))
    db.commit()
    attempt_id = cursor.lastrowid
    total_score = 0
    for answer in answers:
        question_id = answer.get("question_id")
        chosen_option = answer.get("chosen_option")
        if question_id is None or chosen_option is None:
            continue
        cursor.execute("""
            INSERT INTO student_quiz_answers (attempt_id, question_id, chosen_option)
            VALUES (%s, %s, %s)
        """, (attempt_id, question_id, chosen_option))
        cursor.execute("""
            SELECT is_correct, score
            FROM options
            JOIN questions ON options.question_id = questions.id
            WHERE options.id = %s AND questions.id = %s
        """, (chosen_option, question_id))
        result = cursor.fetchone()
        if result and result["is_correct"]:
            total_score += result["score"]
    cursor.execute("UPDATE student_quiz_attempts SET total_score = %s WHERE id = %s", (total_score, attempt_id))
    db.commit()
    cursor.close()
    return jsonify({"attempt_id": attempt_id, "total_score": total_score}), 200

@app.route('/ai_explanation', methods=['POST'])
def ai_explanation():
    """
    AI解析 API：
    接收包含 'question'、'correct_answer' 與 'student_answer' 的 JSON 請求，
    呼叫 LLM 生成該題的解題解析（要求只返回最終解析，不展示思考過程），
    並將解析結果以繁體中文返回。
    """
    data = request.get_json()
    question = data.get("question")
    correct_answer = data.get("correct_answer", "無")
    student_answer = data.get("student_answer", "未提供")
    
    if not question:
        return jsonify({"error": "缺少題目內容"}), 400

    # 組合 prompt，要求 LLM 僅返回最終解析，不展示內部思考過程
    prompt = f"""
【題目】：{question}
【正確答案】：{correct_answer}
【學生答案】：{student_answer}

請針對以上內容提供簡明扼要的解題解析，請以繁體中文回答，且請只返回最終解題說明，不展示任何內部思考或推理過程。
"""

    system_message = "你是一位知識豐富且表達精簡的助教，請只返回最終解題解析，不展示任何內部思考或推理過程，並以繁體中文回答。"

    try:
        completion = client.chat.completions.create(
            model="deepseek-r1-distill-qwen-32b",
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": prompt}
            ],
            temperature=0.2
        )
        explanation = completion.choices[0].message.content.strip()
        # 過濾掉 <think> 區段（若有出現的話）
        explanation = re.sub(r"<think>[\s\S]*?</think>", "", explanation)
        return jsonify({"explanation": explanation}), 200
    except Exception as e:
        return jsonify({"error": f"LLM API 錯誤: {str(e)}"}), 500


# =============================================================================
# AI 自動評分作業功能（整合 LLM 與檔案讀取）
# =============================================================================
def read_file(file_path):
    """
    讀取文件內容，支援 ipynb、純文字與 PDF 格式
    """
    try:
        if file_path.lower().endswith('.ipynb'):
            with open(file_path, 'r', encoding='utf-8') as f:
                nb = json.load(f)
            contents = []
            for cell in nb.get('cells', []):
                if cell.get('cell_type') in ['markdown', 'code']:
                    cell_text = ''.join(cell.get('source', []))
                    contents.append(cell_text)
            return "\n".join(contents)
        mime_type, _ = mimetypes.guess_type(file_path)
        if mime_type and mime_type.startswith("text"):
            with open(file_path, "r", encoding="utf-8") as file:
                return file.read()
        elif mime_type == "application/pdf":
            pdf_text = ""
            with open(file_path, "rb") as file:
                reader = PdfReader(file)
                for page in reader.pages:
                    pdf_text += page.extract_text() or ""
            return pdf_text.strip() if pdf_text else "⚠️ 無法提取 PDF 內容"
        else:
            return "⚠️ 非可解析的文字檔案，請使用 PDF、TXT 或 ipynb"
    except Exception as e:
        print(f"⚠️ 無法讀取 {file_path}: {e}")
        return "⚠️ 讀取作業時發生錯誤"

def chat_with_gpt(messages):
    """
    呼叫 LLM API 生成回答（同步模式，不使用流式）
    """
    completion = client.chat.completions.create(
        model="TheBloke/Mixtral-8x7B-Instruct-v0.1-GGUF",
        messages=messages,
        temperature=0.7
    )
    return completion.choices[0].message.content

@app.route('/ai_grade_homework', methods=['POST'])
def ai_grade_homework():
    """
    AI 自動評分作業 API：教師使用 LLM 自動評分學生提交的作業
    """
    if 'user_id' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '無權限操作'}), 403
    data = request.get_json()
    course_id = data.get('course_id')
    homework_id = data.get('homework_id')
    criteria = data.get('criteria')
    student_id_param = data.get('student_id')
    if not course_id or not homework_id or not criteria:
        return jsonify({'error': '缺少必要參數'}), 400
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT title, description FROM homeworks WHERE id = %s", (homework_id,))
    assignment = cursor.fetchone()
    if not assignment:
        return jsonify({'error': '找不到該作業資料'}), 404
    assignment_title = assignment['title']
    assignment_description = assignment['description']
    if student_id_param:
        cursor.execute("""
            SELECT hs.student_id, hs.file_path, u.full_name
            FROM homework_submissions hs
            JOIN users u ON hs.student_id = u.id
            WHERE hs.homework_id = %s AND hs.student_id = %s
        """, (homework_id, student_id_param))
    else:
        cursor.execute("""
            SELECT hs.student_id, hs.file_path, u.full_name
            FROM homework_submissions hs
            JOIN users u ON hs.student_id = u.id
            WHERE hs.homework_id = %s
        """, (homework_id,))
    submissions = cursor.fetchall()
    if not submissions:
        return jsonify({'error': '無學生繳交此作業'}), 404
    student_grades = []
    for submission in submissions:
        student_id = submission['student_id']
        student_name = submission['full_name']
        stored_filename = submission['file_path']
        actual_file_path = os.path.join(app.config['UPLOAD_FOLDER'], stored_filename)
        print(f"DEBUG: 正在檢查學生 {student_name} 的作業檔案完整路徑: {actual_file_path}")
        if not stored_filename or not os.path.exists(actual_file_path):
            print(f"⚠️ 學生 {student_name} 未繳交作業 - 檔案路徑: {actual_file_path}")
            continue
        homework_content = read_file(actual_file_path)
        prompt = f"""
你是一位負責評分的教師，分數範圍是0到100分，請根據以下作業規範進行評分，並給出分數與簡短評語，請使用繁體中文回答：
【作業名稱】：{assignment_title}
【作業描述】：{assignment_description}
【評分標準】：{criteria}
【學生提交內容】：{homework_content}

請輸出評分結果 (0-100) 以及簡短評語。
"""
        messages_payload = [
            {"role": "system", "content": "請依據上述作業規範進行評分，僅以中文給出簡短回饋。"},
            {"role": "user", "content": prompt}
        ]
        try:
            ai_response = chat_with_gpt(messages_payload).strip()
            ai_response = re.sub(r'<think>.*?</think>', '', ai_response, flags=re.DOTALL).strip()
            first_line = ai_response.split("\n")[0]
            match = re.search(r'(\d{1,3})', first_line)
            if match:
                score = int(match.group(1))
                if score < 0 or score > 100:
                    raise ValueError("AI 評分超出範圍")
            else:
                print(f"⚠️ AI 無法正確解析評分，預設為 50 分：{ai_response}")
                score = 50
            feedback_lines = ai_response.split("\n")
            feedback = "\n".join(feedback_lines[1:]) if len(feedback_lines) > 1 else "無評語"
            cursor.execute("""
                UPDATE homework_submissions
                SET score = %s, feedback = %s
                WHERE student_id = %s AND homework_id = %s
            """, (score, feedback, student_id, homework_id))
            student_grades.append({
                "student_name": student_name,
                "score": score,
                "feedback": feedback
            })
        except Exception as e:
            print(f"❌ AI 評分失敗: {e}")
            continue
    db.commit()
    cursor.close()
    return jsonify({'message': 'AI 評分完成', 'grades': student_grades}), 200

@app.route('/get_my_submissions/<int:course_id>', methods=['GET'])
def get_my_submissions(course_id):
    """
    取得學生在指定課程中所有作業提交紀錄
    """
    if 'user_id' not in session or session.get('role') != 'student':
        return jsonify({'error': '未登入或無權限'}), 401
    student_id = session['user_id']
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = """
            SELECT hs.id AS submission_id, hs.homework_id, hs.file_path, hs.submitted_at, h.title AS homework_title
            FROM homework_submissions hs
            JOIN homeworks h ON hs.homework_id = h.id
            WHERE hs.student_id = %s AND h.course_id = %s
            ORDER BY hs.submitted_at DESC
        """
        cursor.execute(query, (student_id, course_id))
        submissions = cursor.fetchall()
        return jsonify(submissions), 200
    except Exception as e:
        print("Error fetching submissions:", e)
        return jsonify({'error': '取得作業繳交紀錄失敗'}), 500
    finally:
        cursor.close()

@app.route('/delete_submission/<int:submission_id>', methods=['DELETE'])
def delete_submission(submission_id):
    """
    學生刪除自己提交的作業紀錄（同時刪除檔案）
    """
    if 'user_id' not in session or session.get('role') != 'student':
        return jsonify({'error': '未登入或無權限'}), 401
    student_id = session['user_id']
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = "SELECT file_path FROM homework_submissions WHERE id = %s AND student_id = %s"
        cursor.execute(query, (submission_id, student_id))
        result = cursor.fetchone()
        if not result:
            return jsonify({'error': '找不到該作業提交或無權限刪除'}), 404
        file_path = result['file_path']
        if file_path and os.path.exists(file_path):
            try:
                os.remove(file_path)
            except Exception as e:
                print("Error deleting file:", e)
        delete_query = "DELETE FROM homework_submissions WHERE id = %s AND student_id = %s"
        cursor.execute(delete_query, (submission_id, student_id))
        db.commit()
        return jsonify({'message': '作業提交已刪除'}), 200
    except Exception as e:
        db.rollback()
        print("Error deleting submission:", e)
        return jsonify({'error': '刪除作業提交失敗'}), 500
    finally:
        cursor.close()

# =============================================================================
# 社交功能
# =============================================================================
@app.route('/social')
def social_page():
    """社交頁面"""
    if 'user' not in session:
        return redirect(url_for('log_page'))
    return render_template('social.html')

@app.route('/search_user', methods=['GET'])
def search_user():
    """搜尋用戶 API：根據姓名關鍵字搜尋用戶"""
    name = request.args.get('name')
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT username, full_name FROM users WHERE full_name LIKE %s", (f"%{name}%",))
    users = cursor.fetchall()
    if not users:
        return jsonify({'error': '找不到符合條件的用戶'}), 404
    return jsonify(users)

@app.route('/get_friends_list', methods=['GET'])
def get_friends_list():
    """取得好友列表 API"""
    if 'user' not in session:
        return jsonify({'error': '用戶未登入'}), 401
    username = session['user']
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT u.username, u.full_name
        FROM friends AS f
        JOIN users AS u ON (f.friend_username = u.username OR f.user_username = u.username)
        WHERE (f.user_username = %s OR f.friend_username = %s) AND u.username != %s AND f.status = 'accepted'
    """, (username, username, username))
    friends = cursor.fetchall()
    return jsonify(friends), 200

@app.route('/send_friend_request', methods=['POST'])
def send_friend_request():
    """發送好友請求 API"""
    data = request.get_json()
    user_username = session.get('user')
    friend_username = data.get('friend_username')
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT * FROM friends 
        WHERE user_username = %s AND friend_username = %s AND status = 'pending'
    """, (user_username, friend_username))
    existing_request = cursor.fetchone()
    if existing_request:
        return jsonify({'status': 'error', 'message': '好友請求已發送'}), 400
    cursor.execute("""
        INSERT INTO friends (user_username, friend_username, status, created_at, updated_at)
        VALUES (%s, %s, 'pending', NOW(), NOW())
    """, (user_username, friend_username))
    db.commit()
    return jsonify({'status': 'success', 'message': '好友請求已發送'}), 200

@app.route('/get_friend_requests', methods=['GET'])
def get_friend_requests():
    """取得待處理好友請求 API"""
    if 'user' not in session:
        return jsonify({'error': '用戶未登入'}), 401
    username = session['user']
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT u.full_name, f.user_username 
        FROM friends AS f
        JOIN users AS u ON f.user_username = u.username
        WHERE f.friend_username = %s AND f.status = 'pending'
    """, (username,))
    requests_list = cursor.fetchall()
    return jsonify(requests_list), 200

@app.route('/handle_friend_request', methods=['POST'])
def handle_friend_request():
    """處理好友請求 API：接受或拒絕好友請求"""
    data = request.get_json()
    friend_username = data.get('friend_username')
    action = data.get('action')
    if 'user' not in session:
        return jsonify({'error': '用戶未登入'}), 401
    if not friend_username or action not in ['accept', 'decline']:
        return jsonify({'error': '無效的請求'}), 400
    username = session['user']
    db = get_db()
    cursor = db.cursor()
    if action == 'accept':
        cursor.execute("UPDATE friends SET status = 'accepted' WHERE user_username = %s AND friend_username = %s", (friend_username, username))
    elif action == 'decline':
        cursor.execute("DELETE FROM friends WHERE user_username = %s AND friend_username = %s", (friend_username, username))
    db.commit()
    return jsonify({'status': 'success'})



@app.route('/posts', methods=['POST'])
def create_post():
    data = request.get_json()
    title = data.get('title')
    content = data.get('content')
    user_id = data.get('user_id')
    tags = data.get('tags') or []
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO posts (user_id, title, content) VALUES (%s, %s, %s)", (user_id, title, content))
        post_id = cursor.lastrowid
        for tag_name in tags:
            cursor.execute("SELECT id FROM tags WHERE name = %s", (tag_name,))
            tag = cursor.fetchone()
            if not tag:
                cursor.execute("INSERT INTO tags (name) VALUES (%s)", (tag_name,))
                tag_id = cursor.lastrowid
            else:
                tag_id = tag[0]
            cursor.execute("INSERT INTO post_tags (post_id, tag_id) VALUES (%s, %s)", (post_id, tag_id))
        db.commit()
        return jsonify({'status': '文章發佈成功', 'id': post_id}), 201
    except Exception as e:
        db.rollback()
        print(f"Error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/posts/<int:post_id>', methods=['PUT'])
def edit_post(post_id):
    data = request.get_json()
    title = data.get('title')
    content = data.get('content')
    tags = data.get('tags') or []
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("UPDATE posts SET title = %s, content = %s WHERE id = %s", (title, content, post_id))
        cursor.execute("DELETE FROM post_tags WHERE post_id = %s", (post_id,))
        for tag_name in tags:
            cursor.execute("SELECT id FROM tags WHERE name = %s", (tag_name,))
            tag = cursor.fetchone()
            if not tag:
                cursor.execute("INSERT INTO tags (name) VALUES (%s)", (tag_name,))
                tag_id = cursor.lastrowid
            else:
                tag_id = tag[0]
            cursor.execute("INSERT INTO post_tags (post_id, tag_id) VALUES (%s, %s)", (post_id, tag_id))
        db.commit()
        return jsonify({'status': '文章已更新'}), 200
    except Exception as e:
        db.rollback()
        print(f"Error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/posts/<int:post_id>', methods=['DELETE'])
def delete_post(post_id):
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("DELETE FROM posts WHERE id = %s", (post_id,))
        cursor.execute("DELETE FROM post_tags WHERE post_id = %s", (post_id,))
        cursor.execute("DELETE FROM comments WHERE post_id = %s", (post_id,))
        db.commit()
        return jsonify({'status': '文章已刪除'}), 200
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/posts', methods=['GET'])
def get_posts():
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT posts.id, posts.title, posts.content, posts.created_at, 
                   IFNULL(GROUP_CONCAT(tags.name SEPARATOR ', '), '') AS tags
            FROM posts
            LEFT JOIN post_tags ON posts.id = post_tags.post_id
            LEFT JOIN tags ON post_tags.tag_id = tags.id
            GROUP BY posts.id
        """)
        posts = cursor.fetchall()
        return jsonify(posts), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/comments', methods=['POST'])
def create_comment():
    data = request.get_json()
    post_id = data.get('post_id')
    user_id = data.get('user_id')
    content = data.get('content')
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("INSERT INTO comments (post_id, user_id, content) VALUES (%s, %s, %s)", (post_id, user_id, content))
        db.commit()
        return jsonify({'status': '留言發佈成功'}), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/comments/<int:post_id>', methods=['GET'])
def get_comments(post_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT * FROM comments WHERE post_id = %s", (post_id,))
        comments = cursor.fetchall()
        return jsonify(comments), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    


@app.route('/get_chat_messages', methods=['GET'])
def get_chat_messages():
    user_username = session.get('user')
    friend_username = request.args.get('friend_username')
    if not user_username:
        return jsonify({'error': '用戶未登入'}), 401
    if not friend_username:
        return jsonify({'error': '缺少好友名稱'}), 400
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT sender_username, receiver_username, message, created_at 
            FROM messages 
            WHERE (sender_username = %s AND receiver_username = %s)
               OR (sender_username = %s AND receiver_username = %s)
            ORDER BY created_at
        """, (user_username, friend_username, friend_username, user_username))
        messages_list = cursor.fetchall()
        return jsonify({'messages': messages_list}), 200
    except Exception as e:
        print(f"Database error: {e}")
        return jsonify({'error': '伺服器錯誤，無法取得聊天訊息'}), 500

@app.route('/send_chat_message', methods=['POST'])
def send_chat_message():
    data = request.json
    sender_username = session.get('user')
    friend_username = data.get('friend_username')
    message = data.get('message')
    if not sender_username or not friend_username or not message:
        return jsonify({'error': '缺少必要資訊'}), 400
    db = get_db()
    cursor = db.cursor()
    cursor.execute("""
        INSERT INTO messages (sender_username, receiver_username, message, created_at)
        VALUES (%s, %s, %s, NOW())
    """, (sender_username, friend_username, message))
    db.commit()
    return jsonify({'status': 'success'})

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/get_current_user', methods=['GET'])
def get_current_user():
    username = session.get('user')
    return jsonify({'username': username})


# =============================================================================
# 課程相關功能（教師／學生）
# =============================================================================
@app.route('/student-course', endpoint="studentcourse")
def studentcourse():
    """學生課程頁面"""
    return render_template('student-course.html')

@app.route('/teacher-course')
def teachercourse():
    """教師課程頁面"""
    return render_template('teacher-course.html')

@app.route('/create_course', methods=['POST'])
def create_course():
    """
    建立課程 API：教師可建立新課程
    """
    if 'user' not in session:
        return jsonify({'error': '用戶未登入，請重新登入'}), 401
    data = request.get_json()
    course_name = data.get('name', '').strip()
    course_description = data.get('description', '').strip()
    teacher_username = session.get('user')
    if not course_name:
        return jsonify({'error': '課程名稱不可為空或僅包含空白'}), 400
    if not course_description:
        return jsonify({'error': '課程描述不可為空或僅包含空白'}), 400
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT id FROM users WHERE username = %s AND role = 'teacher'", (teacher_username,))
    teacher = cursor.fetchone()
    if not teacher:
        return jsonify({'error': '無效的教師帳號或用戶角色不是教師'}), 403
    teacher_id = teacher['id']
    cursor.execute(
        "INSERT INTO courses (course_name, description, teacher_id) VALUES (%s, %s, %s)",
        (course_name, course_description, teacher_id)
    )
    db.commit()
    return jsonify({'status': '課程創建成功'}), 201

@app.route('/apply_course', methods=['POST'])
def apply_course():
    """
    學生申請加入課程 API
    """
    if 'user' not in session or session.get('role') != 'student':
        return jsonify({'error': '無權限申請課程'}), 403
    data = request.get_json()
    course_id = data.get('course_id')
    student_id = session['user_id']
    if not course_id:
        return jsonify({'error': '課程 ID 不得為空'}), 400
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM enrollments WHERE student_id = %s AND course_id = %s", (student_id, course_id))
    enrollment = cursor.fetchone()
    if enrollment:
        return jsonify({'error': '已申請過此課程'}), 400
    cursor.execute("INSERT INTO enrollments (student_id, course_id, status) VALUES (%s, %s, 'pending')", (student_id, course_id))
    db.commit()
    return jsonify({'status': '申請成功'}), 201

@app.route('/get_teacher_courses', methods=['GET'])
def get_teacher_courses():
    """
    教師查看自己開設課程的 API
    """
    if 'user' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '無權限查看課程'}), 403
    teacher_id = session.get('user_id')
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("SELECT id, course_name FROM courses WHERE teacher_id = %s", (teacher_id,))
        courses = cursor.fetchall()
        return jsonify(courses), 200
    except Exception as e:
        return jsonify({'error': f'無法加載課程：{str(e)}'}), 500

@app.route('/get_students_for_course/<int:course_id>', methods=['GET'])
def get_students_for_course(course_id):
    """
    教師查看指定課程學生名單 API
    """
    if 'user_id' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '無權限查看學生名單'}), 403
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT u.username, u.full_name
            FROM enrollments e
            JOIN users u ON e.student_id = u.id
            WHERE e.course_id = %s AND e.status = 'approved'
        """, (course_id,))
        students = cursor.fetchall()
        return jsonify(students), 200
    except Exception as e:
        return jsonify({'error': f'無法加載該課程的學生名單：{str(e)}'}), 500

@app.route('/get_joined_courses', methods=['GET'])
def get_joined_courses():
    """
    學生取得自己已加入的課程 API
    """
    user_id = session.get('user_id')
    if not user_id or session.get('role') != 'student':
        return jsonify({'error': '未登錄或無學生權限，無法查詢課程'}), 401
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT c.id, c.course_name
            FROM courses c
            JOIN enrollments e ON e.course_id = c.id
            WHERE e.student_id = %s
        """, (user_id,))
        courses = cursor.fetchall()
        return jsonify(courses), 200
    except Exception as e:
        return jsonify({'error': '無法加載已加入課程'}), 500

@app.route('/get_courses', methods=['GET'])
def get_courses():
    """
    學生取得可申請課程 API（排除已加入的課程）
    """
    user_id = session.get('user_id')
    if not user_id or session.get('role') != 'student':
        return jsonify({'error': '未登錄或無學生權限，無法查詢課程'}), 403
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = """
            SELECT id, course_name
            FROM courses
            WHERE id NOT IN (
                SELECT course_id
                FROM enrollments
                WHERE student_id = %s
            )
        """
        cursor.execute(query, (user_id,))
        courses = cursor.fetchall()
        return jsonify(courses), 200
    except Exception as e:
        return jsonify({'error': f'無法加載可申請課程：{str(e)}'}), 500

@app.route('/get_application_status', methods=['GET'])
def get_application_status():
    """
    學生取得課程申請狀態 API
    """
    if 'user_id' not in session or session.get('role') != 'student':
        return jsonify({'error': '無權限查看申請狀態'}), 403
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT c.course_name, e.status 
            FROM enrollments e
            JOIN courses c ON e.course_id = c.id
            WHERE e.student_id = %s AND e.status IN ('pending', 'rejected')
        """, (session['user_id'],))
        applications = cursor.fetchall()
        return jsonify(applications), 200
    except Exception as e:
        return jsonify({'error': f'無法加載申請狀態：{str(e)}'}), 500

@app.route('/get_pending_requests/<int:course_id>', methods=['GET'])
def get_pending_requests_for_course(course_id):
    """
    教師取得指定課程待處理申請 API
    """
    if 'user_id' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '無權限查看待處理申請'}), 403
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT e.id AS enrollment_id, u.full_name, u.username
            FROM enrollments e
            JOIN users u ON e.student_id = u.id
            WHERE e.course_id = %s AND e.status = 'pending'
        """, (course_id,))
        pending_requests = cursor.fetchall()
        return jsonify(pending_requests), 200
    except Exception as e:
        return jsonify({'error': f'無法加載該課程的待處理申請：{str(e)}'}), 500

@app.route('/approve_request/<int:request_id>', methods=['POST'])
def approve_request(request_id):
    """
    教師接受學生申請 API
    """
    if 'user_id' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '無權限操作'}), 403
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("""
            UPDATE enrollments
            SET status = 'approved'
            WHERE id = %s AND status = 'pending'
        """, (request_id,))
        db.commit()
        if cursor.rowcount == 0:
            return jsonify({'error': '未找到待處理的申請或申請已被處理'}), 404
        return jsonify({'status': 'success', 'message': '申請已被接受'}), 200
    except Exception as e:
        return jsonify({'error': f'無法處理申請：{str(e)}'}), 500

@app.route('/reject_request/<int:request_id>', methods=['POST'])
def reject_request(request_id):
    """
    教師拒絕學生申請 API
    """
    if 'user_id' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '無權限操作'}), 403
    db = get_db()
    cursor = db.cursor()
    try:
        cursor.execute("""
            UPDATE enrollments
            SET status = 'rejected'
            WHERE id = %s AND status = 'pending'
        """, (request_id,))
        db.commit()
        if cursor.rowcount == 0:
            return jsonify({'error': '未找到待處理的申請或申請已被處理'}), 404
        return jsonify({'status': 'success', 'message': '申請已被拒絕'}), 200
    except Exception as e:
        return jsonify({'error': f'無法處理申請：{str(e)}'}), 500
    

# 1. 顯示前端頁面
@app.route("/score")
def score_page():
    return render_template("score.html")

# 2. 取得計分項目（自動匯入 homeworks 與 quizzes）
@app.route("/get_score_items", methods=["GET"])
def get_score_items():
    course_id = request.args.get("course_id")
    if not course_id:
        return jsonify({"error": "必須提供 course_id"}), 400
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        # 先檢查 score_items 是否已有資料
        sql = "SELECT * FROM score_items WHERE course_id = %s"
        cursor.execute(sql, (course_id,))
        items = cursor.fetchall()
        if not items:
            # 若無資料，從 homeworks 匯入
            sql_hw = "SELECT id, title FROM homeworks WHERE course_id = %s"
            cursor.execute(sql_hw, (course_id,))
            homeworks = cursor.fetchall()
            for hw in homeworks:
                insert_sql = ("INSERT INTO score_items (course_id, source_id, name, type, percentage) "
                              "VALUES (%s, %s, %s, %s, %s)")
                cursor.execute(insert_sql, (course_id, hw["id"], hw["title"], "作業", 0))
            # 從 quizzes 匯入
            sql_quiz = "SELECT id, name FROM quizzes WHERE course_id = %s"
            cursor.execute(sql_quiz, (course_id,))
            quizzes = cursor.fetchall()
            for q in quizzes:
                insert_sql = ("INSERT INTO score_items (course_id, source_id, name, type, percentage) "
                              "VALUES (%s, %s, %s, %s, %s)")
                cursor.execute(insert_sql, (course_id, q["id"], q["name"], "測驗", 0))
            db.commit()
            cursor.execute(sql, (course_id,))
            items = cursor.fetchall()
        return jsonify(items), 200
    except Exception as e:
        print("取得 score_items 失敗:", e)
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        db.close()

# 3. 更新計分項目（僅更新百分比）
@app.route("/update_score_items", methods=["PUT"])
def update_score_items():
    data = request.json
    course_id = data.get("course_id")
    updates = data.get("updates", [])
    if not course_id or not updates:
        return jsonify({"error": "資料不完整"}), 400
    db = get_db()
    cursor = db.cursor()
    try:
        for upd in updates:
            item_id = upd["id"]
            new_percentage = upd["percentage"]
            sql = "UPDATE score_items SET percentage = %s WHERE id = %s AND course_id = %s"
            cursor.execute(sql, (new_percentage, item_id, course_id))
        db.commit()
        return jsonify({"message": "更新成功"}), 200
    except Exception as e:
        db.rollback()
        print("更新 score_items 失敗:", e)
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        db.close()

# 4. 新增計分項目（手動新增）
@app.route("/add_score_item", methods=["POST"])
def add_score_item():
    data = request.json
    course_id = data.get("course_id")
    name = data.get("name")
    percentage = data.get("percentage")
    item_type = data.get("type")  # "作業" 或 "測驗"
    if not course_id or not name or percentage is None or not item_type:
        return jsonify({"error": "資料不完整"}), 400
    db = get_db()
    cursor = db.cursor()
    try:
        # 手動新增時，source_id 設為 0 表示無來源（可依需求調整）
        sql = ("INSERT INTO score_items (course_id, source_id, name, type, percentage) "
               "VALUES (%s, %s, %s, %s, %s)")
        cursor.execute(sql, (course_id, 0, name, item_type, percentage))
        db.commit()
        return jsonify({"message": "新增項目成功"}), 200
    except Exception as e:
        db.rollback()
        print("新增 score_item 失敗:", e)
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        db.close()

# 5. 刪除計分項目
@app.route("/delete_score_item/<int:item_id>", methods=["DELETE"])
def delete_score_item(item_id):
    course_id = request.args.get("course_id")
    if not course_id:
        return jsonify({"error": "必須提供 course_id"}), 400
    db = get_db()
    cursor = db.cursor()
    try:
        sql = "DELETE FROM score_items WHERE id = %s AND course_id = %s"
        cursor.execute(sql, (item_id, course_id))
        db.commit()
        return jsonify({"message": "刪除成功"}), 200
    except Exception as e:
        db.rollback()
        print("刪除 score_item 失敗:", e)
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        db.close()

# 6. 取得學生成績（依各項目得分與老師設定百分比計算總分）
@app.route("/get_student_scores", methods=["GET"])
def get_student_scores():
    """
    回傳格式示例：
    [
      {
         "student_id": 1,
         "full_name": "王小明",
         "scores": { "1": 85, "2": 90, ... },
         "total_score": 88.5
      },
      ...
    ]
    這裡 score_items 表中的 id 為本系統記錄 ID
    """
    course_id = request.args.get("course_id")
    if not course_id:
        return jsonify({"error": "必須提供 course_id"}), 400
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        # 取得該課程所有學生（透過 enrollments 與 users 表）
        sql_students = """
            SELECT u.id AS student_id, u.full_name
            FROM enrollments e
            JOIN users u ON e.student_id = u.id
            WHERE e.course_id = %s AND e.status = 'approved'
        """
        cursor.execute(sql_students, (course_id,))
        students = cursor.fetchall()
        
        # 取得 score_items
        sql_items = "SELECT * FROM score_items WHERE course_id = %s"
        cursor.execute(sql_items, (course_id,))
        score_items = cursor.fetchall()
        
        # 建立學生分數映射，key 為 (student_id, score_item_id)
        score_map = {}
        for item in score_items:
            if item["type"] == "作業":
                # homework_submissions 的欄位名稱為 score
                sql_hw_score = "SELECT student_id, score FROM homework_submissions WHERE homework_id = %s"
                cursor.execute(sql_hw_score, (item["source_id"],))
                for row in cursor.fetchall():
                    key = (row["student_id"], item["id"])
                    score_map[key] = float(row["score"])
            elif item["type"] == "測驗":
                # student_quiz_attempts 的欄位名稱為 total_score
                sql_quiz_score = "SELECT student_id, total_score FROM student_quiz_attempts WHERE quiz_id = %s"
                cursor.execute(sql_quiz_score, (item["source_id"],))
                for row in cursor.fetchall():
                    key = (row["student_id"], item["id"])
                    score_map[key] = float(row["total_score"])
        
        result = []
        for stu in students:
            stu_id = stu["student_id"]
            stu_scores = {}
            total_score = 0.0
            for item in score_items:
                key = (stu_id, item["id"])
                raw_score = score_map.get(key, 0.0)
                stu_scores[str(item["id"])] = raw_score
                total_score += (raw_score / 100) * float(item["percentage"])
            result.append({
                "student_id": stu_id,
                "full_name": stu["full_name"],
                "scores": stu_scores,
                "total_score": round(total_score, 2)
            })
        return jsonify(result), 200
    except Exception as e:
        print("取得學生成績失敗:", e)
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        db.close()


@app.route('/quizzes.html')
def quizzes_page_html():
    course_id = request.args.get('course_id')
    return render_template('quizzes.html', course_id=course_id)

@app.route('/quizzes', endpoint='quizzes_root')
def quizzes_page_root():
    course_id = request.args.get('course_id')
    return render_template('quizzes.html', course_id=course_id)


@app.route('/quiz_editor.html')
def quiz_editor():
    course_id = request.args.get('course_id')
    quiz_id = request.args.get('quiz_id')
    return render_template('quiz_editor.html', course_id=course_id, quiz_id=quiz_id)

@app.route('/create_quiz', methods=['POST'])
def create_quiz_endpoint():
    if 'user' not in session or session.get('role') != 'teacher':
        return jsonify({'error': '未登入或無權限'}), 403

    data = request.get_json()
    if not data:
        return jsonify({"error": "未提供資料"}), 400

    course_id = data.get("course_id")
    name = data.get("name")
    description = data.get("description", "")
    teacher_id = session.get("user_id")

    if not course_id or not name:
        return jsonify({"error": "必須提供 course_id 與測驗名稱"}), 400

    try:
        db = get_db()
        cursor = db.cursor()
        sql = """
            INSERT INTO quizzes (course_id, teacher_id, name, description)
            VALUES (%s, %s, %s, %s)
        """
        cursor.execute(sql, (course_id, teacher_id, name, description))
        db.commit()
        # 使用 quizzes 表中的自動產生的 id
        quiz_id = cursor.lastrowid
        return jsonify({"quiz_id": quiz_id}), 200
    except Exception as e:
        db.rollback()
        print("建立測驗失敗:", e)
        return jsonify({"error": str(e)}), 500


@app.route('/get_homeworks/<int:course_id>', methods=['GET'])
def get_homeworks(course_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = """
            SELECT h.id AS homework_id, h.title, h.description
            FROM homeworks h
            WHERE h.course_id = %s
        """
        cursor.execute(query, (course_id,))
        homeworks = cursor.fetchall()
        return jsonify(homeworks), 200
    except Exception as e:
        return jsonify({'error': f'無法加載作業：{str(e)}'}), 500
    
@app.route('/get_homework_submissions/<int:homework_id>', methods=['GET'])
def get_homework_submissions(homework_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = """
            SELECT 
                u.id AS student_id,
                u.full_name AS student_name,
                COALESCE(hs.file_path, '未繳交') AS file_path,
                hs.submitted_at, hs.score
            FROM users u
            LEFT JOIN homework_submissions hs 
                ON u.id = hs.student_id AND hs.homework_id = %s
            WHERE u.id IN (
                SELECT student_id FROM enrollments 
                WHERE course_id = (SELECT course_id FROM homeworks WHERE id = %s)
            )
        """
        cursor.execute(query, (homework_id, homework_id))
        submissions = cursor.fetchall()
        for submission in submissions:
            if submission["file_path"] and submission["file_path"] != "未繳交":
                filename = os.path.basename(submission["file_path"])
                submission["file_path"] = f"/uploads/{filename}"
        return jsonify(submissions), 200
    except Exception as e:
        print(f"❌ 無法加載作業提交狀況: {e}")
        return jsonify({'error': f'無法加載作業提交狀況：{str(e)}'}), 500
    finally:
        cursor.close()
        


@app.route('/get_announcements/<int:course_id>', methods=['GET'])
def get_announcements(course_id):
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = """
            SELECT id, content, created_at
            FROM announcements
            WHERE course_id = %s
            ORDER BY created_at DESC
        """
        cursor.execute(query, (course_id,))
        announcements = cursor.fetchall()
        return jsonify(announcements)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

ALLOWED_MATERIAL_EXTENSIONS = {'pdf', 'doc', 'docx', 'ipynb'}

def allowed_material_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_MATERIAL_EXTENSIONS







# =============================================================================
# 主函式啟動應用程式
# =============================================================================
if __name__ == '__main__':
    app.run(debug=True)
