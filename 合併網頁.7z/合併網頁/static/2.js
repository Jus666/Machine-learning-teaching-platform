document.addEventListener("DOMContentLoaded", function() {
    console.log("app.js 文件加載成功");

    // LLM 按鈕點擊事件
    const llmBtn = document.getElementById("llm-btn");
    if (llmBtn) {
        llmBtn.addEventListener("click", function() {
            window.location.href = "/llm";  // 使用 Flask 路由導航到 LLM 頁面
        });
    }

    // 資源庫按鈕點擊事件
    const resourcesBtn = document.getElementById("resources-btn");
    if (resourcesBtn) {
        resourcesBtn.addEventListener("click", function() {
            window.location.href = "/resources";  // 使用 Flask 路由導航到資源庫頁面
        });
    }

    // 練習按鈕點擊事件
    const practiceBtn = document.getElementById("practice-btn");
    if (practiceBtn) {
        practiceBtn.addEventListener("click", function() {
            alert("練習功能尚未實現");
        });
    }

    // 隨機練習按鈕點擊事件
    const questionBtn = document.getElementById("question-btn");
    if (questionBtn) {
        questionBtn.addEventListener("click", function() {
            window.location.href = "/question";  // 使用 Flask 路由導航到隨機練習頁面
        });
    }

    // 題庫按鈕點擊事件
    const questionbankBtn = document.getElementById("question-bank-btn");
    if (questionbankBtn) {
        questionbankBtn.addEventListener("click", function() {
            window.location.href = "/question-bank";  // 使用 Flask 路由導航到隨機練習頁面
        });
    }

    // 論壇按鈕點擊事件
    const forumBtn = document.getElementById("forum-btn");
    if (forumBtn) {
        forumBtn.addEventListener("click", function() {
            window.location.href = "/forum";  // 使用 Flask 路由導航到論壇頁面
        });
    }

    // 程式碼比較按鈕點擊事件
    const codeCompareBtn = document.getElementById("code-compare-btn");
    if (codeCompareBtn) {
        codeCompareBtn.addEventListener("click", function() {
            window.location.href = "/code-compare";  // 使用 Flask 路由導航到程式碼比較頁面
        });
    }

    // 翻譯點擊事件
    const translateBtn = document.getElementById("translate-btn");
    if (translateBtn) {
        translateBtn.addEventListener("click", function() {
            window.location.href = "/translate";  // 使用 Flask 路由導航到程式碼比較頁面
        });
    }
    
    // 聊天室點擊事件
    const chatBtn = document.getElementById("chat-btn");
    if (chatBtn) {
        chatBtn.addEventListener("click", function() {
            window.location.href = "/chat";  // 使用 Flask 路由導航到程式碼比較頁面
        });
    }

    // 課程點擊事件
    const studentcourseBtn = document.getElementById("student-course-btn");
    if (studentcourseBtn) {
        studentcourseBtn.addEventListener("click", function() {
            window.location.href = "/student-course";  // 使用 Flask 路由導航到程式碼比較頁面
        });
    }

    // 管理課程點擊事件
    const teachercourseBtn = document.getElementById("teacher-course-btn");
    if (teachercourseBtn) {
        teachercourseBtn.addEventListener("click", function() {
            window.location.href = "/teacher-course";  // 使用 Flask 路由導航到程式碼比較頁面
        });
    }



    // 個人資料按鈕點擊事件
    const personalinformationBtn = document.getElementById("personal-information-btn");
    if (personalinformationBtn) {
        personalinformationBtn.addEventListener("click", function() {
            window.location.href = "/personal-information";  // 使用 Flask 路由導航到程式碼比較頁面
        });
    }

    // 社交按鈕點擊事件
    const socialBtn = document.getElementById("social-btn");
    if (socialBtn) {
        socialBtn.addEventListener("click", function() {
            window.location.href = "/social";  // 使用 Flask 路由導航到程式碼比較頁面
        });
    }

    // 設置按鈕點擊事件
    const settingsBtn = document.getElementById("settings-btn");
    if (settingsBtn) {
        settingsBtn.addEventListener("click", function() {
            alert("設置功能尚未實現");
        });
    }

    // 登出按鈕點擊事件
    const logoutBtn = document.getElementById("logout-btn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", function() {
            alert("登出功能尚未實現");
        });
    }


    // 返回主選單按鈕點擊事件（所有頁面通用）
    const backButton = document.getElementById("back-to-menu-btn");
    if (backButton) {
        backButton.addEventListener("click", function() {
            window.location.href = "/home";  // 使用 Flask 路由導航到主選單
        });
    }
    
    // 顯示聊天記錄
    function displayChatHistory() {
        const responseDiv = document.getElementById("llm-response");
        responseDiv.innerHTML = "";  // 清空現有的顯示

        // 遍歷所有聊天記錄，依次顯示
        chatHistory.forEach((message) => {
            const messageElement = document.createElement("div");
            messageElement.classList.add(message.role);  // 用角色來區分 "user" 或 "llm"
            messageElement.innerText = `${message.role === "user" ? "你：" : "LLM：" } ${message.content}`;
            responseDiv.appendChild(messageElement);  // 添加到回應框中
        });

        // 確保回應框的最新內容可見
        responseDiv.scrollTop = responseDiv.scrollHeight;
    }

    // 即時聊天室處理
    const sendBtn = document.getElementById("send-btn");
    if (sendBtn) {
        sendBtn.addEventListener("click", function() {
            const messageInput = document.getElementById("message-input");
            const messageText = messageInput.value.trim();
            
            if (messageText !== "") {
                messages.push({ user: currentUser.name, text: messageText });  // 添加新訊息
                displayMessages();  // 顯示訊息
                messageInput.value = '';  // 清空輸入框
            }
        });
    }

    function displayMessages() {
        const messageContainer = document.getElementById("messages");
        messageContainer.innerHTML = '';  // 清空現有訊息
        messages.forEach(message => {
            const messageElement = document.createElement("p");
            messageElement.textContent = `${message.user}: ${message.text}`;  // 顯示訊息
            messageContainer.appendChild(messageElement);
        });
    }

    // 資源庫處理 - 檢視文件
    function viewResource(resourceName) {
        fetch(`/uploads/${resourceName}`)  // 從後端檢索文件內容
        .then(response => response.text())  // 將文件轉為文字顯示
        .then(data => {
            alert(`檢視檔案內容：\n${data}`);  // 顯示文件內容
        })
        .catch(error => {
            alert("無法檢視此檔案類型");
            console.error('Error:', error);
        });
    }
});
