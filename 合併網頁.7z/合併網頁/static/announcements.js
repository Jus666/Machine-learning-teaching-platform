document.addEventListener("DOMContentLoaded", () => {
    console.log("公告管理頁面初始化");
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get("course_id");
    const sendAnnouncementForm = document.getElementById("send-announcement-form");
    const viewAnnouncementsBtn = document.getElementById("view-announcements-btn");
    const announcementsList = document.getElementById("announcements-list");
  
    sendAnnouncementForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const content = document.getElementById("announcement-content").value.trim();
      if (!content) {
        alert("公告內容不能為空！");
        return;
      }
      try {
        const response = await fetch(`/send_announcement/${courseId}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content })
        });
        if (response.ok) {
          alert("公告新增成功！");
          sendAnnouncementForm.reset();
          loadAnnouncements();
        } else {
          const errorData = await response.json();
          alert("公告新增失敗：" + errorData.error);
        }
      } catch (error) {
        console.error("新增公告時發生錯誤：", error);
        alert("新增公告失敗，請稍後再試！");
      }
    });
  
    viewAnnouncementsBtn.addEventListener("click", () => {
      loadAnnouncements();
    });
  
    async function loadAnnouncements() {
      try {
        const response = await fetch(`/get_announcements/${courseId}`);
        if (!response.ok) throw new Error("無法載入公告");
        const announcements = await response.json();
        announcementsList.innerHTML = "";
        if (announcements.length === 0) {
          announcementsList.innerHTML = "<p>目前沒有公告。</p>";
          return;
        }
        announcements.forEach(announcement => {
          const li = document.createElement("li");
          li.textContent = `公告: ${announcement.content} - ${announcement.created_at}`;
          announcementsList.appendChild(li);
        });
      } catch (error) {
        console.error("載入公告時發生錯誤：", error);
        announcementsList.innerHTML = "<p>載入公告失敗，請稍後再試！</p>";
      }
    }
  
    loadAnnouncements();
  });
  