document.addEventListener("DOMContentLoaded", () => {
    const socket = io();
  
    const messagesDiv = document.getElementById("chat-messages");
    const messageInput = document.getElementById("message-input");
    const sendBtn = document.getElementById("send-btn");
    const backBtn = document.getElementById("back-to-menu-btn-chat");
  
    // 連線建立
    socket.on("connect", () => {
      console.log("已連線到伺服器");
    });
  
    // 收到訊息時顯示
    socket.on("chat_message", (data) => {
      displayMessage(data);
    });
  
    // 顯示一則訊息
    function displayMessage({ from, message, timestamp }) {
      const msgEl = document.createElement("div");
      msgEl.classList.add("message", from === CURRENT_USER ? "sent" : "received");
      msgEl.innerHTML = `
        <div class="username">${from}</div>
        <div class="text">${message}</div>
        <div class="timestamp">${new Date(timestamp).toLocaleTimeString()}</div>
      `;
      messagesDiv.appendChild(msgEl);
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }
  
    // 發送訊息
    sendBtn.addEventListener("click", () => {
      const text = messageInput.value.trim();
      if (!text) return;
      const payload = {
        from: CURRENT_USER,
        message: text,
        timestamp: new Date().toISOString(),
      };
      socket.emit("chat_message", payload);
      messageInput.value = "";
    });
  
    // Enter 送出
    messageInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        sendBtn.click();
      }
    });
  
    // 返回主選單
    backBtn.addEventListener("click", () => {
      window.location.href = "/home";
    });
  });
  