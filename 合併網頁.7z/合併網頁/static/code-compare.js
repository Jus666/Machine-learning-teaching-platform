// 計算編輯距離（Levenshtein Distance）
function levenshtein(a, b) {
    const matrix = [];

    for (let i = 0; i <= b.length; i++) {
        matrix[i] = [i];
    }
    for (let j = 0; j <= a.length; j++) {
        matrix[0][j] = j;
    }

    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1, // substitution
                    matrix[i][j - 1] + 1,     // insertion
                    matrix[i - 1][j] + 1      // deletion
                );
            }
        }
    }

    return matrix[b.length][a.length];
}

// 計算相似度
function compareCodes() {
    const codeA = document.getElementById("codeA").value;
    const codeB = document.getElementById("codeB").value;

    if (codeA === "" || codeB === "") {
        alert("請輸入程式碼 A 和程式碼 B");
        return;
    }

    // 計算兩段程式碼的編輯距離
    const distance = levenshtein(codeA, codeB);

    // 最大可能的編輯距離
    const maxLength = Math.max(codeA.length, codeB.length);

    // 檢查是否最大長度為 0
    if (maxLength === 0) {
        alert("兩段程式碼都是空的，無法計算相似度");
        return;
    }

    // 相似度百分比
    const similarity = ((1 - distance / maxLength) * 100).toFixed(2);

    // 顯示結果
    const resultDiv = document.getElementById("result");
    resultDiv.style.display = "block";
    resultDiv.innerHTML = `程式碼 A 與程式碼 B 的相似度為：${similarity}%`;
}

// 退出按鈕功能 - 返回主選單
document.getElementById("back-to-menu-btn").addEventListener("click", function() {
    window.location.href = "/home";  // 返回主選單頁面
});
