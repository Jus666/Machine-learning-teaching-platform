document.addEventListener("DOMContentLoaded", function () {
    console.log("forum.js 文件加載成功");

    const availableTags = [
        "分類", "迴歸", "決策樹", "支持向量機", "隨機森林", "神經網絡",
        "深度學習", "強化學習", "K-均值", "PCA", "集成學習",
        "交叉驗證", "特徵選擇", "過擬合", "超參數調整"
    ];

    const tagsContainer = document.getElementById("tags-container");

    // 初始化標籤，點擊後亮光
    availableTags.forEach(tag => {
        const tagElement = document.createElement("span");
        tagElement.className = "tag";
        tagElement.innerText = tag;

        // 點擊切換標籤的選擇狀態
        tagElement.addEventListener("click", function () {
            tagElement.classList.toggle("selected");
        });

        tagsContainer.appendChild(tagElement);
    });

    let posts = [];  // 全局變數來存儲文章數據

    // 發佈文章處理
    document.getElementById("post-form").addEventListener("submit", function (event) {
        event.preventDefault();  // 阻止表單提交後頁面刷新
        const title = document.getElementById("title").value;
        const content = document.getElementById("content").value;

        // 獲取被選中的標籤
        const selectedTags = Array.from(document.querySelectorAll(".tag.selected")).map(tag => tag.innerText);

        // 構建發送到後端的數據
        const postData = {
            title: title,
            content: content,
            user_id: 1,  // 假設用戶ID為1，實際應該從後端session中獲取
            tags: selectedTags
        };

        // 使用 fetch 發送請求到後端 API
        fetch('/posts', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(postData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === '文章發佈成功') {
                alert("文章發佈成功");
                // 在成功發佈後直接將文章插入全局變數中並更新顯示
                posts.push({
                    title: title,
                    content: content,
                    tags: selectedTags,
                    created_at: new Date().toISOString(),
                    id: data.id  // 獲取剛剛新增的文章的ID
                });
                updatePostList();  // 顯示最新的文章
            } else {
                console.error("發佈失敗：", data.error);
            }
        })
        .catch(error => {
            console.error("發生錯誤：", error);
        });

        // 重置表單和標籤
        document.getElementById("post-form").reset();
        Array.from(document.querySelectorAll(".tag.selected")).forEach(tag => tag.classList.remove("selected"));
    });

    // 顯示文章列表並更新畫面
    function updatePostList() {
        const postList = document.getElementById("post-list");
        postList.innerHTML = '';  // 清空現有文章

        posts.forEach(post => {
            const postItem = document.createElement("li");
            postItem.innerHTML = `
                <h3>${post.title} - ${post.author || '匿名用戶'}</h3>
                <p>${post.content}</p>
                <p>標籤: ${(typeof post.tags === 'string' ? post.tags.split(', ') : post.tags).join(', ')}</p>
                <small>發佈時間: ${new Date(post.created_at).toLocaleString()}</small>
                <div>
                    <button class="edit-btn" data-post-id="${post.id}">編輯</button>
                    <button class="delete-btn" data-post-id="${post.id}">刪除</button>
                </div>
                <div>
                    <h4>留言區:</h4>
                    <ul id="comments-${post.id}"></ul>
                    <textarea id="comment-input-${post.id}" placeholder="輸入留言..."></textarea>
                    <button class="comment-btn" data-post-id="${post.id}">發佈留言</button>
                </div>
            `;
            postList.appendChild(postItem);  // 顯示每篇文章

            // 顯示每篇文章的留言
            displayComments(post.id);
        });

        // 綁定刪除功能
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function () {
                const postId = parseInt(button.getAttribute('data-post-id'));
                deletePost(postId);
            });
        });

        // 綁定編輯功能
        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', function () {
                const postId = parseInt(button.getAttribute('data-post-id'));
                editPost(postId);
            });
        });

        // 綁定留言按鈕點擊事件
        document.querySelectorAll('.comment-btn').forEach(button => {
            button.addEventListener('click', function () {
                const postId = parseInt(button.getAttribute('data-post-id'));
                const commentInput = document.getElementById(`comment-input-${postId}`);
                const commentText = commentInput.value.trim();

                if (commentText) {
                    const commentData = {
                        post_id: postId,
                        user_id: 1,  // 假設留言用戶ID為1
                        content: commentText
                    };

                    fetch('/comments', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(commentData)
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === '留言發佈成功') {
                            commentInput.value = '';  // 清空留言輸入框
                            displayComments(postId);  // 更新留言顯示
                        } else {
                            console.error("留言失敗：", data.error);
                        }
                    })
                    .catch(error => {
                        console.error("發生錯誤：", error);
                    });
                }
            });
        });
    }

    // 加載並顯示文章列表
    function loadPosts() {
        fetch('/posts')
            .then(response => response.json())
            .then(fetchedPosts => {
                posts = fetchedPosts;  // 將文章數據存儲到全局變數
                updatePostList();  // 更新文章顯示
            });
    }

    // 顯示文章的留言
    function displayComments(postId) {
        fetch(`/comments/${postId}`)
            .then(response => response.json())
            .then(comments => {
                const commentsList = document.getElementById(`comments-${postId}`);
                commentsList.innerHTML = '';  // 清空現有留言

                comments.forEach(comment => {
                    const commentItem = document.createElement('li');
                    commentItem.innerHTML = `
                        <p>${comment.content} - ${comment.author || '匿名留言者'}</p>
                        <small>留言時間: ${new Date(comment.created_at).toLocaleString()}</small>
                    `;
                    commentsList.appendChild(commentItem);
                });
            });
    }

    // 刪除文章功能
    function deletePost(postId) {
        fetch(`/posts/${postId}`, {
            method: 'DELETE'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === '文章已刪除') {
                loadPosts();  // 重新加載文章列表
                alert("文章已刪除");
            } else {
                console.error("刪除失敗：", data.error);
            }
        })
        .catch(error => {
            console.error("發生錯誤：", error);
        });
    }

    // 編輯文章功能
    function editPost(postId) {
        const post = posts.find(post => post.id === postId);  // 使用全局變數 posts
        document.getElementById("title").value = post.title;
        document.getElementById("content").value = post.content;

        // 重置標籤選擇狀態
        Array.from(document.querySelectorAll(".tag.selected")).forEach(tag => tag.classList.remove("selected"));
        post.tags.forEach(tag => {
            const tagElement = Array.from(document.querySelectorAll(".tag")).find(t => t.innerText === tag);
            if (tagElement) tagElement.classList.add("selected");
        });

        // 更新文章
        document.getElementById("post-form").addEventListener("submit", function (event) {
            event.preventDefault();
            const updatedTitle = document.getElementById("title").value;
            const updatedContent = document.getElementById("content").value;
            const updatedTags = Array.from(document.querySelectorAll(".tag.selected")).map(tag => tag.innerText);

            const updateData = {
                title: updatedTitle,
                content: updatedContent,
                tags: updatedTags
            };

            fetch(`/posts/${postId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updateData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === '文章已更新') {
                    loadPosts();  // 更新文章顯示
                    alert("文章已更新");
                } else {
                    console.error("更新失敗：", data.error);
                }
            })
            .catch(error => {
                console.error("發生錯誤：", error);
            });
        }, { once: true });
    }

    // 搜尋文章功能
    document.getElementById("search-btn").addEventListener("click", function () {
        const searchTerm = document.getElementById("search-bar").value.toLowerCase();
        
        const filteredPosts = posts.filter(post => {
            const tags = Array.isArray(post.tags) 
                ? post.tags 
                : (typeof post.tags === 'string' ? post.tags.split(', ') : []);
    
            return post.title.toLowerCase().includes(searchTerm) ||
                   post.content.toLowerCase().includes(searchTerm) ||
                   tags.some(tag => tag.toLowerCase().includes(searchTerm));
        });
        
        displayFilteredPosts(filteredPosts);
    });
    

    // 顯示搜尋結果
    function displayFilteredPosts(filteredPosts) {
        const postList = document.getElementById("post-list");
        postList.innerHTML = '';  // 清空現有文章

        if (filteredPosts.length === 0) {
            postList.innerHTML = "<p>未找到符合條件的文章</p>";
            return;
        }

        filteredPosts.forEach(post => {
            const postItem = document.createElement("li");
            postItem.innerHTML = `
                <h3>${post.title} - ${post.author || '匿名用戶'}</h3>
                <p>${post.content}</p>
                <p>標籤: ${(typeof post.tags === 'string' ? post.tags.split(', ') : post.tags).join(', ')}</p>
                <small>發佈時間: ${new Date(post.created_at).toLocaleString()}</small>
            `;
            postList.appendChild(postItem);  // 顯示每篇文章
        });
    }

    // 返回主選單按鈕
    document.getElementById("back-to-menu-btn").addEventListener("click", function () {
        window.location.href = "/home";  // 返回主選單頁面
    });

    // 初始化顯示文章列表
    loadPosts();
});
