// 定義新聞抓取和動態展示功能
document.addEventListener("DOMContentLoaded", () => {
    const newsContainer = document.getElementById("news-container");

    // 動態加載新聞
    fetch('/fetch_ai_news')
        .then(response => {
            if (!response.ok) throw new Error("HTTP error! status: " + response.status);
            return response.json();
        })
        .then(data => {
            if (data.length === 0) {
                newsContainer.innerHTML = "<p>目前沒有可用的新聞。</p>";
            } else {
                displayNews(data);
            }
        })
        .catch(error => {
            console.error("Error fetching AI news:", error);
            newsContainer.innerHTML = "<p>無法載入最新新聞，請稍後再試。</p>";
        });

    // 顯示新聞的函數
    function displayNews(news) {
        newsContainer.innerHTML = ""; // 清空容器
        news.forEach(article => {
            const newsItem = document.createElement("div");
            newsItem.className = "news-item";

            const newsImage = document.createElement("img");
            newsImage.src = article.image_url || "/static/images/default.jpg"; // 加載預設圖片
            newsImage.alt = "新聞圖片";
            newsImage.onerror = () => {
                // 如果圖片加載失敗，使用預設圖片
                newsImage.src = "/static/images/default.jpg";
            };

            const newsTitle = document.createElement("h3");
            newsTitle.textContent = article.title;

            const newsLink = document.createElement("a");
            newsLink.href = article.link;
            newsLink.target = "_blank";
            newsLink.textContent = "閱讀更多";

            newsItem.appendChild(newsImage);
            newsItem.appendChild(newsTitle);
            newsItem.appendChild(newsLink);
            newsContainer.appendChild(newsItem);
        });
    }
});

