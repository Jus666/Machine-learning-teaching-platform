document.addEventListener("DOMContentLoaded", () => {
  console.log("作業管理頁面初始化");

  // 從 URL 取得 course_id
  const urlParams = new URLSearchParams(window.location.search);
  const courseId = urlParams.get("course_id");

  // 取得 DOM 元素
  const assignHomeworkForm = document.getElementById("assign-homework-form");
  const viewHomeworkSubmissionsBtn = document.getElementById("view-homework-submissions-btn");
  const homeworkList = document.getElementById("homework-list");
  let submissionDetailSection = document.getElementById("submission-detail-section");
  const aiGradingModal = document.getElementById("ai-grading-modal");
  const gradingCriteriaInput = document.getElementById("grading-criteria");
  const confirmAiGradingBtn = document.getElementById("confirm-ai-grading");
  const cancelAiGradingBtn = document.getElementById("cancel-ai-grading");
  const aiGradeAllBtn = document.getElementById("ai-grade-all-btn");
  const useAssignmentDescriptionBtn = document.getElementById("use-assignment-description-btn");

  // 全域變數
  let currentHomeworkId = null;
  let currentAssignmentTitle = "";
  let currentAssignmentDescription = "";

  // 確保提交表格存在，若不存在則動態建立
  function ensureSubmissionTable() {
    let table = document.getElementById("submission-table");
    if (!table) {
      if (!submissionDetailSection) {
        submissionDetailSection = document.createElement("section");
        submissionDetailSection.id = "submission-detail-section";
        document.body.appendChild(submissionDetailSection);
      }
      table = document.createElement("table");
      table.id = "submission-table";
      table.border = "1";

      const thead = document.createElement("thead");
      const headerRow = document.createElement("tr");
      ["學生名稱", "繳交狀況", "檔案內容", "評分", "AI 評分"].forEach(text => {
        const th = document.createElement("th");
        th.textContent = text;
        headerRow.appendChild(th);
      });
      thead.appendChild(headerRow);
      table.appendChild(thead);

      const tbody = document.createElement("tbody");
      table.appendChild(tbody);

      submissionDetailSection.appendChild(table);
    }
    return table.querySelector("tbody");
  }

  // 載入作業列表
  async function loadHomeworkList() {
    try {
      const response = await fetch(`/get_homeworks/${courseId}`);
      if (!response.ok) throw new Error("無法加載作業列表");
      const homeworks = await response.json();
      if (!homeworkList) {
        console.error("找不到 homework-list 元素");
        return;
      }
      homeworkList.innerHTML = "";
      if (homeworks.length === 0) {
        homeworkList.innerHTML = "<p>目前沒有作業。</p>";
        return;
      }
      homeworks.forEach(homework => {
        const li = document.createElement("li");
        li.innerHTML = `<strong>作業名稱:</strong> ${homework.title} <br><strong>描述:</strong> ${homework.description}`;
        const viewBtn = document.createElement("button");
        viewBtn.textContent = "查看繳交狀況";
        viewBtn.addEventListener("click", () => {
          currentHomeworkId = homework.homework_id;
          currentAssignmentTitle = homework.title;
          currentAssignmentDescription = homework.description;
          const aiTitleElem = document.getElementById("ai-assignment-title");
          const aiDescElem = document.getElementById("ai-assignment-description");
          if (aiTitleElem) aiTitleElem.textContent = currentAssignmentTitle;
          if (aiDescElem) aiDescElem.textContent = currentAssignmentDescription;
          loadHomeworkSubmissions(homework.homework_id);
        });
        li.appendChild(viewBtn);
        homeworkList.appendChild(li);
      });
    } catch (error) {
      console.error("加載作業列表時發生錯誤：", error);
      if (homeworkList) {
        homeworkList.innerHTML = "<p>加載作業列表失敗，請稍後再試！</p>";
      }
    }
  }

  // 新增作業
  if (assignHomeworkForm) {
    assignHomeworkForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const homeworkTitleElem = document.getElementById("homework-title");
      const homeworkDescriptionElem = document.getElementById("homework-description");
      const homeworkFileElem = document.getElementById("homework-file");
      const homeworkTitle = homeworkTitleElem ? homeworkTitleElem.value.trim() : "";
      const homeworkDescription = homeworkDescriptionElem ? homeworkDescriptionElem.value.trim() : "";
      const homeworkFile = homeworkFileElem ? homeworkFileElem.files[0] : null;
      if (!homeworkTitle || !homeworkDescription) {
        alert("請輸入作業名稱和描述！");
        return;
      }
      const formData = new FormData();
      formData.append("course_id", courseId);
      formData.append("title", homeworkTitle);
      formData.append("description", homeworkDescription);
      if (homeworkFile) {
        formData.append("file", homeworkFile);
      }
      try {
        const response = await fetch("/assign_homework", { method: "POST", body: formData });
        if (response.ok) {
          alert("作業新增成功！");
          assignHomeworkForm.reset();
          loadHomeworkList();
        } else {
          const errorData = await response.json();
          alert("作業新增失敗：" + errorData.message);
        }
      } catch (error) {
        console.error("新增作業時發生錯誤：", error);
        alert("新增作業失敗，請稍後再試！");
      }
    });
  }

  // 查看作業繳交狀況
  if (viewHomeworkSubmissionsBtn) {
    viewHomeworkSubmissionsBtn.addEventListener("click", () => {
      const homeworkListSection = document.getElementById("homework-list-section");
      if (homeworkListSection) {
        homeworkListSection.style.display = "block";
      } else {
        console.warn("找不到 homework-list-section 元素");
      }
      loadHomeworkList();
    });
  }

  // 載入作業提交狀況
  async function loadHomeworkSubmissions(homeworkId) {
    try {
      const response = await fetch(`/get_homework_submissions/${homeworkId}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "無法加載作業提交情況");
      }
      const submissions = await response.json();

      const submissionTableBody = ensureSubmissionTable();
      if (submissionDetailSection) {
        submissionDetailSection.style.display = "block";
      }
      submissionTableBody.innerHTML = "";

      if (submissions.length === 0) {
        submissionTableBody.innerHTML = `<tr><td colspan="5" style="text-align:center;">目前沒有學生繳交作業。</td></tr>`;
        return;
      }
      submissions.forEach(submission => {
        const row = document.createElement("tr");
        const nameCell = document.createElement("td");
        nameCell.textContent = submission.student_name || "未知學生";
        row.appendChild(nameCell);
        const statusCell = document.createElement("td");
        statusCell.textContent = submission.file_path === "未繳交" ? "未繳交" : "已繳交";
        row.appendChild(statusCell);
        const fileCell = document.createElement("td");
        if (submission.file_path !== "未繳交") {
          const link = document.createElement("a");
          link.href = submission.file_path;
          link.textContent = "下載作業";
          link.target = "_blank";
          fileCell.appendChild(link);
        } else {
          fileCell.textContent = "無";
        }
        row.appendChild(fileCell);
        const gradeCell = document.createElement("td");
        if (submission.file_path !== "未繳交") {
          const input = document.createElement("input");
          input.type = "number";
          input.min = 0;
          input.max = 100;
          input.value = submission.score || "";
          input.placeholder = "分數";
          input.style.marginRight = "10px";
          const gradeButton = document.createElement("button");
          gradeButton.textContent = "提交分數";
          gradeButton.addEventListener("click", async () => {
            const score = input.value;
            if (!score || isNaN(score) || score < 0 || score > 100) {
              alert("請輸入有效分數（0-100）！");
              return;
            }
            try {
              await gradeHomework(submission.student_id, homeworkId, score);
              alert("分數提交成功！");
              loadHomeworkSubmissions(homeworkId);
            } catch (error) {
              console.error("提交分數時發生錯誤：", error);
              alert("提交分數失敗，請稍後重試！");
            }
          });
          gradeCell.appendChild(input);
          gradeCell.appendChild(gradeButton);
        } else {
          gradeCell.textContent = "無法評分";
        }
        row.appendChild(gradeCell);
        const aiGradeCell = document.createElement("td");
        if (submission.file_path !== "未繳交") {
          const aiButton = document.createElement("button");
          aiButton.textContent = "AI 評分";
          aiButton.addEventListener("click", () => openAiGradingModal(homeworkId, courseId, submission.student_id));
          aiGradeCell.appendChild(aiButton);
        } else {
          aiGradeCell.textContent = "無法評分";
        }
        row.appendChild(aiGradeCell);
        submissionTableBody.appendChild(row);
      });

    } catch (error) {
      console.error("加載作業提交狀況時發生錯誤：", error);
      alert("無法加載作業提交狀況，請稍後重試！");
    }
  }

  // 返回作業列表
  const backToListBtn = document.getElementById("back-to-homework-list");
  if (backToListBtn) {
    backToListBtn.addEventListener("click", () => {
      if (submissionDetailSection) {
        submissionDetailSection.style.display = "none";
      }
      const homeworkListSection = document.getElementById("homework-list-section");
      if (homeworkListSection) {
        homeworkListSection.style.display = "block";
      }
      if (aiGradingModal) {
        aiGradingModal.style.display = "none";
      }
    });
  }

  async function gradeHomework(studentId, homeworkId, score) {
    if (!studentId || !homeworkId || score === undefined) {
      console.error("缺少必要的參數：studentId, homeworkId 或 score");
      throw new Error("缺少必要的參數");
    }
    try {
      const response = await fetch("/grade_homework", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ student_id: studentId, homework_id: homeworkId, score })
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "無法提交分數");
      }
      console.log("分數提交成功！");
    } catch (error) {
      console.error("提交分數時發生錯誤：", error.message);
      throw error;
    }
  }

  // AI 個別評分
  function openAiGradingModal(homeworkId, courseId, studentId) {
    console.log(`打開 AI 評分視窗（個別） | 作業 ID: ${homeworkId}, 課程 ID: ${courseId}, 學生 ID: ${studentId}`);
    currentHomeworkId = homeworkId;
    const aiTitleElem = document.getElementById("ai-assignment-title");
    const aiDescElem = document.getElementById("ai-assignment-description");
    if (aiTitleElem) aiTitleElem.textContent = currentAssignmentTitle;
    if (aiDescElem) aiDescElem.textContent = currentAssignmentDescription;
    aiGradingModal.style.display = "block";
  }

  // AI 全部評分
  function openAiGradingModalAll(homeworkId, courseId) {
    console.log(`打開 AI 評分視窗（全部） | 作業 ID: ${homeworkId}, 課程 ID: ${courseId}`);
    currentHomeworkId = homeworkId;
    const aiTitleElem = document.getElementById("ai-assignment-title");
    const aiDescElem = document.getElementById("ai-assignment-description");
    if (aiTitleElem) aiTitleElem.textContent = currentAssignmentTitle;
    if (aiDescElem) aiDescElem.textContent = currentAssignmentDescription;
    aiGradingModal.style.display = "block";
  }

  if (useAssignmentDescriptionBtn) {
    useAssignmentDescriptionBtn.addEventListener("click", () => {
      gradingCriteriaInput.value = currentAssignmentDescription;
    });
  }

  if (cancelAiGradingBtn) {
    cancelAiGradingBtn.addEventListener("click", () => {
      aiGradingModal.style.display = "none";
    });
  }

  if (aiGradeAllBtn) {
    aiGradeAllBtn.addEventListener("click", () => {
      openAiGradingModalAll(currentHomeworkId, courseId);
    });
  }

  if (confirmAiGradingBtn) {
    confirmAiGradingBtn.addEventListener("click", async () => {
      const criteria = gradingCriteriaInput.value.trim();
      if (!criteria) {
        alert("請輸入評分標準！");
        return;
      }
      try {
        await aiGradeAllHomework(courseId, currentHomeworkId, criteria);
        alert("AI 評分完成！");
        aiGradingModal.style.display = "none";
        gradingCriteriaInput.value = "";
        await loadHomeworkSubmissions(currentHomeworkId);
      } catch (error) {
        console.error("AI 評分失敗：", error);
        alert("AI 評分失敗，請稍後重試！");
      }
    });
  }

  async function aiGradeAllHomework(courseId, homeworkId, criteria) {
    try {
      const response = await fetch("/ai_grade_homework", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          course_id: courseId,
          homework_id: homeworkId,
          criteria: criteria
        })
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "AI 評分失敗");
      }
      console.log("全部 AI 評分成功！");
      return await response.json();
    } catch (error) {
      console.error("全部 AI 評分發生錯誤：", error);
      throw error;
    }
  }

  // 初始化：載入作業列表
  loadHomeworkList();
});
