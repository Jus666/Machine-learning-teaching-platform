document.addEventListener("DOMContentLoaded", function () {
    // 當用戶點擊「提交問題」按鈕時觸發
    document.getElementById("submit-llm-query").addEventListener("click", function () {
      const query = document.getElementById("llm-query").value;
      if (query.trim() === "") {
        alert("請輸入問題");
        return;
      }
  
      // 顯示用戶訊息
      displayMessage("user", query);
  
      // 創建 LLM 回應容器，初始顯示 "LLM: "
      const llmMessageElement = document.createElement("div");
      llmMessageElement.classList.add("llm");
      llmMessageElement.innerText = "LLM: ";
      document.getElementById("llm-response").appendChild(llmMessageElement);
      document.getElementById("llm-response").scrollTop = document.getElementById("llm-response").scrollHeight;
  
      // 發送查詢到後端並處理流式回應
      fetch("/llm", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query: query }),
      })
        .then(response => {
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          const reader = response.body.getReader();
          const decoder = new TextDecoder("utf-8");
          let buffer = "";
          // 累積所有流式回應的內容
          let accumulatedText = "";
  
          function processStream({ done, value }) {
            if (done) return;
            // 將接收到的二進位數據解碼為字串並加入緩衝區
            buffer += decoder.decode(value, { stream: true });
            // 以換行符分割數據
            const lines = buffer.split("\n");
            // 將最後一行（可能不完整）保留於 buffer 中
            buffer = lines.pop() || "";
            
            // 處理每一行
            lines.forEach(line => {
              if (line.trim()) {
                try {
                  const data = JSON.parse(line);
                  if (data.response) {
                    // 累積新的回應內容
                    accumulatedText += data.response;
                    // 若包含完整的 <think>... </think> 區段，僅顯示 </think> 後的內容
                    if (accumulatedText.indexOf("</think>") !== -1) {
                      const finalText = accumulatedText.substring(accumulatedText.indexOf("</think>") + 8).trim();
                      llmMessageElement.innerText = "LLM: " + finalText;
                    } else if (accumulatedText.indexOf("<think>") !== -1) {
                      // 如果只收到 <think> 但未閉合，則顯示提示文字
                      llmMessageElement.innerText = "LLM: 正在思考中...";
                    } else {
                      // 如果沒有任何 <think> 標籤，則直接累加
                      llmMessageElement.innerText += data.response;
                    }
                    // 自動滾動到底部
                    document.getElementById("llm-response").scrollTop = document.getElementById("llm-response").scrollHeight;
                  } else if (data.error) {
                    console.error("API 錯誤:", data.error);
                    llmMessageElement.innerText += `[錯誤: ${data.error}]`;
                  }
                } catch (error) {
                  console.error("JSON 解析錯誤:", error, "原始數據:", line);
                }
              }
            });
            // 繼續讀取下一塊數據
            return reader.read().then(processStream);
          }
          return reader.read().then(processStream);
        })
        .catch(error => {
          console.error("Error:", error);
          // 若發生錯誤，顯示提示文字
          const llmMessageElement = document.querySelector(".llm");
          llmMessageElement.innerText += "[請求錯誤, 請稍後再試]";
          document.getElementById("llm-response").scrollTop = document.getElementById("llm-response").scrollHeight;
        });
  
      // 清空查詢輸入框
      document.getElementById("llm-query").value = "";
    });
  
    // 清除記憶按鈕的功能
    document.getElementById("clear-history-btn").addEventListener("click", function () {
      fetch("/clear_history", { method: "POST" })
        .then(response => {
          if (response.ok) {
            document.getElementById("llm-response").innerHTML = "";
            alert("記憶已清除！");
          } else {
            alert("無法清除記憶，請稍後再試。");
          }
        })
        .catch(error => {
          console.error("Error:", error);
          alert("請求出錯，請稍後再試。");
        });
    });
  
    // 返回主選單按鈕的功能
    document.getElementById("back-to-menu-btn").addEventListener("click", function () {
      window.location.href = "/home";
    });
  
    // 顯示訊息函數：用於在頁面上顯示用戶或 LLM 的訊息
    function displayMessage(sender, message) {
      const messageElement = document.createElement("div");
      messageElement.classList.add(sender);
      messageElement.innerText = sender === "user" ? `用戶: ${message}` : `LLM: ${message}`;
      document.getElementById("llm-response").appendChild(messageElement);
      document.getElementById("llm-response").scrollTop = document.getElementById("llm-response").scrollHeight;
    }
  });
  