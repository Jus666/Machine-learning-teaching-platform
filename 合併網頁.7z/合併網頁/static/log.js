document.addEventListener("DOMContentLoaded", function() {
    console.log("log.js 文件加載成功");

    // 顯示或隱藏頁面
    function hideAllPages() {
        document.getElementById("login-page").style.display = "none";
        document.getElementById("register-page").style.display = "none";
    }

    function showLoginPage() {
        hideAllPages();
        const loginPage = document.getElementById("login-page");
        if (loginPage) {
            loginPage.style.display = "block";
        }
    }

    function showRegisterPage() {
        hideAllPages();
        const registerPage = document.getElementById("register-page");
        if (registerPage) {
            registerPage.style.display = "block";
        }
    }

    function showMenuPage() {
        window.location.href = '/home'; // 登入成功後跳轉到主頁面
    }

    // 註冊用戶
    const registerForm = document.getElementById("register-form");
    if (registerForm) {
        registerForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const username = document.getElementById("new-username").value;
            const password = document.getElementById("new-password").value;
            const fullName = document.getElementById("name").value;
            const role = document.getElementById("role").value;

            // 構建註冊請求
            const requestData = {
                username: username,
                password: password,
                full_name: fullName,
                role: role
            };

            // 發送註冊請求
            fetch("/register", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === '註冊成功') {
                    alert("註冊成功！");
                    showMenuPage();
                } else {
                    alert(data.error || "註冊失敗");
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("註冊請求失敗");
            });
        });
    }

    // 用戶登入
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const username = document.getElementById("username").value;
            const password = document.getElementById("password").value;

            // 構建登入請求
            const requestData = {
                username: username,
                password: password
            };

            // 發送登入請求
            fetch("/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(requestData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === '登入成功') {
                    alert("登入成功！");
                    showMenuPage();
                } else {
                    alert(data.error || "登入失敗");
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("登入請求失敗");
            });
        });
    }

    // 切換到註冊頁面
    const registerLink = document.getElementById("register-link");
    if (registerLink) {
        registerLink.addEventListener("click", function() {
            showRegisterPage();
        });
    }

    // 切換回登入頁面
    const loginLink = document.getElementById("login-link");
    if (loginLink) {
        loginLink.addEventListener("click", function() {
            showLoginPage();
        });
    }

    // 頁面加載時顯示登入頁面
    showLoginPage();
});
