document.addEventListener("DOMContentLoaded", () => {
    console.log("教材管理頁面初始化");
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get("course_id");
    const uploadMaterialBtn = document.getElementById("upload-material-btn");
    const deleteMaterialBtn = document.getElementById("delete-material-btn");
    const materialsList = document.getElementById("materials-list");
    const MATERIAL_UPLOAD_FOLDER = "static/materials";
  
    uploadMaterialBtn.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = ".txt,.pdf,.doc,.docx,.ppt,.pptx,.ipynb";
      input.onchange = async () => {
        const file = input.files[0];
        if (!file) return;
        const formData = new FormData();
        formData.append("file", file);
        formData.append("course_id", courseId);
        try {
          const response = await fetch("/upload_material", {
            method: "POST",
            body: formData
          });
          if (response.ok) {
            alert("檔案上傳成功！");
            loadMaterials();
          } else {
            const errorData = await response.json();
            alert("檔案上傳失敗：" + errorData.error);
          }
        } catch (error) {
          console.error("上傳檔案發生錯誤：", error);
          alert("檔案上傳發生錯誤，請稍後再試！");
        }
      };
      input.click();
    });
  
    deleteMaterialBtn.addEventListener("click", async () => {
      const selectedItem = materialsList.querySelector(".selected");
      if (!selectedItem) {
        alert("請選擇要刪除的檔案！");
        return;
      }
      const filename = selectedItem.getAttribute("data-filename");
      if (!filename) {
        alert("無法取得檔案名稱！");
        return;
      }
      if (!confirm("確定要刪除檔案 " + filename + " 嗎？")) return;
      try {
        const response = await fetch(`/delete_material/${filename}`, { method: "DELETE" });
        if (response.ok) {
          alert("檔案刪除成功！");
          loadMaterials();
        } else {
          const errorData = await response.json();
          alert("檔案刪除失敗：" + errorData.error);
        }
      } catch (error) {
        console.error("刪除檔案時發生錯誤：", error);
        alert("刪除檔案發生錯誤，請稍後再試！");
      }
    });
  
    async function loadMaterials() {
      try {
        const response = await fetch("/get_materials?course_id=" + courseId);
        if (!response.ok) throw new Error("無法加載教材");
        const materials = await response.json();
        materialsList.innerHTML = "";
        if (materials.length === 0) {
          materialsList.innerHTML = "<p>目前沒有教材檔案。</p>";
          return;
        }
        materials.forEach(material => {
          const container = document.createElement("div");
          container.classList.add("material-item");
          const nameSpan = document.createElement("span");
          nameSpan.textContent = material.original_filename || material.filename;
          container.appendChild(nameSpan);
          // 檢視按鈕
          const viewBtn = document.createElement("button");
          viewBtn.textContent = "檢視";
          viewBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            window.open("/" + MATERIAL_UPLOAD_FOLDER + "/" + material.filename, "_blank");
          });
          container.appendChild(viewBtn);
          // 下載按鈕
          const downloadBtn = document.createElement("button");
          downloadBtn.textContent = "下載";
          downloadBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const a = document.createElement("a");
            a.href = "/" + MATERIAL_UPLOAD_FOLDER + "/" + material.filename;
            a.download = material.original_filename || material.filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
          });
          container.appendChild(downloadBtn);
          // 刪除按鈕
          const deleteBtn = document.createElement("button");
          deleteBtn.textContent = "刪除";
          deleteBtn.addEventListener("click", async (e) => {
            e.stopPropagation();
            if (!confirm("確定要刪除檔案 " + (material.original_filename || material.filename) + " 嗎？")) return;
            try {
              const response = await fetch(`/delete_material/${material.filename}`, { method: "DELETE" });
              if (response.ok) {
                alert("檔案刪除成功！");
                loadMaterials();
              } else {
                const errorData = await response.json();
                alert("檔案刪除失敗：" + errorData.error);
              }
            } catch (error) {
              console.error("刪除檔案時發生錯誤：", error);
              alert("刪除檔案發生錯誤，請稍後再試！");
            }
          });
          container.appendChild(deleteBtn);
          container.addEventListener("click", () => {
            const alreadySelected = materialsList.querySelector(".selected");
            if (alreadySelected) {
              alreadySelected.classList.remove("selected");
            }
            container.classList.add("selected");
          });
          container.setAttribute("data-filename", material.filename);
          materialsList.appendChild(container);
        });
      } catch (error) {
        console.error("加載教材時發生錯誤：", error);
        materialsList.innerHTML = "<p>加載教材失敗，請稍後再試！</p>";
      }
    }
  
    loadMaterials();
  });
  