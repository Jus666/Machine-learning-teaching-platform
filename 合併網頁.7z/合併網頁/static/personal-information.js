window.onload = function() {
    // 請求個人資料
    fetch('/get_personal_info')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('無法獲取個人資料，請重新登入');
                window.location.href = '/';
            } else {
                document.getElementById('username').textContent = data.username;
                document.getElementById('full_name').textContent = data.full_name;
                document.getElementById('password').textContent = data.password;
            }
        })
        .catch(error => {
            console.error('Error fetching personal info:', error);
        });

    // 返回主選單按鈕
    document.getElementById('back-to-home-btn').addEventListener('click', function() {
        window.location.href = '/home';
    });
};

// 個人資料按鈕點擊事件
const personalinformationBtn = document.getElementById("personal-information-btn");
if (personalinformationBtn) {
    personalinformationBtn.addEventListener("click", function() {
        window.location.href = "/personal-information";  // 使用 Flask 路由導航到個人資料頁面
    });
}
