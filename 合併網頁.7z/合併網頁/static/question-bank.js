document.addEventListener("DOMContentLoaded", function() {
    // 章節和題目資料
    const questions = {
        'chapter1': [
            {
                question: "1. 在 Python 中，哪個符號用於進行註釋？",
                options: ["A. //", "B. #", "C. /* */", "D. <!-- -->"],
                correct: 1,
                explanation: "在 Python 中，# 用於添加單行註釋，註釋不會影響程式運行。"
            },
            {
                question: "2. 哪個函數可以用來獲取用戶的輸入？",
                options: ["A. input()", "B. print()", "C. read()", "D. scan()"],
                correct: 0,
                explanation: "input() 函數用來從使用者處接收輸入，並將其轉換為字串。"
            },
            {
                question: "3. 在 Python 中，哪種數據類型用於存儲文本數據？",
                options: ["A. int", "B. float", "C. str", "D. bool"],
                correct: 2,
                explanation: "str（字符串）是用來表示文本數據的類型。"
            },
            {
                question: "4. 下面哪個語句可以正確的打印出「Hello, World!」？",
                options: ["A. echo \"Hello, World!\"", "B. print(\"Hello, World!\")", "C. printf(\"Hello, World!\")", "D. cout << \"Hello, World!\""],
                correct: 1,
                explanation: "print() 函數用來輸出內容到螢幕，Python 使用小括號表示函數調用。"
            },
            {
                question: "5. 哪個函數用來計算列表 my_list 中元素的數量？",
                options: ["A. sum(my_list)", "B. count(my_list)", "C. len(my_list)", "D. size(my_list)"],
                correct: 2,
                explanation: "len() 函數用來計算列表或其他容器類型中的元素個數。"
            },
            {
                "question": "6. 以下哪個選項代表 Python 中的有效變量名稱？",
                "options": ["A. 1_variable", "B. my-variable", "C. my_variable", "D. my variable"],
                "correct": 2,
                "explanation": "在 Python 中，變量名稱必須以字母或下劃線開頭，不能包含空格或破折號。"
            },
            {
                "question": "7. 如果 x = 5，那麼 x // 2 的結果是什麼？",
                "options": ["A. 2.5", "B. 2", "C. 3", "D. 1"],
                "correct": 1,
                "explanation": "// 是整除運算符，它返回整數部分，5 除以 2 等於 2.5，整數部分是 2。"
            },
            {
                "question": "8. 下列哪個運算符用於檢查兩個值是否相等？",
                "options": ["A. =", "B. ==", "C. !=", "D. <>"],
                "correct": 1,
                "explanation": "== 用來檢查兩個值是否相等，而 = 是賦值運算符。"
            },
            {
                "question": "9. range(1, 5) 在 Python 中生成哪一組數字？",
                "options": ["A. [1, 2, 3, 4, 5]", "B. [1, 2, 3, 4]", "C. [1, 2, 3]", "D. [2, 3, 4, 5]"],
                "correct": 1,
                "explanation": "range(1, 5) 生成的是從 1 到 4 的數字，不包括上限 5。"
            },
            {
                "question": "10. 哪個選項可以用來定義一個函數？",
                "options": ["A. function myFunction()", "B. def myFunction()", "C. func myFunction()", "D. define myFunction()"],
                "correct": 1,
                "explanation": "在 Python 中，使用 def 關鍵字來定義函數。"
            },
            {
                "question": "11. 如果有一個字典 d = {\"apple\": 1, \"banana\": 2}，下列哪個選項正確地返回 banana 的值？",
                "options": ["A. d[1]", "B. d[\"banana\"]", "C. d.get(\"apple\")", "D. d[\"orange\"]"],
                "correct": 1,
                "explanation": "通過字典的鍵（key）來訪問其對應的值（value），在這裡 d[\"banana\"] 返回 2。"
            },
            {
                "question": "12. 下面的代碼輸出結果是什麼？\nx = 10\ny = 2\nprint(x % y)",
                "options": ["A. 0", "B. 2", "C. 5", "D. 10"],
                "correct": 0,
                "explanation": "% 是取餘數運算符，10 除以 2 的餘數是 0。"
            },
            {
                "question": "13. 下列哪個語句用於處理異常？",
                "options": ["A. if", "B. except", "C. try-except", "D. while"],
                "correct": 2,
                "explanation": "在 Python 中，try-except 語句用來捕獲並處理異常，以防止程序崩潰。"
            },
            {
                "question": "14. 哪個語句用於檢查某個值是否在列表 my_list 中？",
                "options": ["A. if my_list not in value:", "B. if value not in my_list:", "C. if my_list has value:", "D. if my_list != value:"],
                "correct": 1,
                "explanation": "in 關鍵字用來檢查值是否存在於列表或其他容器中，not in 則表示值不存在。"
            },
            {
                "question": "15. 如果有一個 for 循環 for i in range(5)，循環會執行多少次？",
                "options": ["A. 4", "B. 5", "C. 6", "D. 無限次"],
                "correct": 1,
                "explanation": "range(5) 生成的是 0 到 4 的數字，總共 5 個數字，因此循環執行 5 次。"
            }            
            // ... 其他題目可以繼續補充
        ],
        'chapter2': [
            {
                question: "1. 在機器學習中，將數據集劃分為訓練集和測試集的主要目的是什麼？",
                options: ["A. 增加數據集的大小", "B. 測試不同的演算法", "C. 評估模型在未見數據上的表現", "D. 優化模型的超參數"],
                correct: 2,
                explanation: "劃分數據集的目的是為了評估模型的泛化能力，訓練集用來讓模型學習，測試集用來驗證模型的效能。"
            },
            {
                question: "2. 下列哪一個是常見的分類演算法？",
                options: ["A. 線性回歸", "B. 決策樹", "C. K均值聚類", "D. 主成分分析"],
                correct: 1,
                explanation: "決策樹是一種常見的分類演算法。線性回歸是迴歸演算法，K均值是聚類演算法，主成分分析是降維方法。"
            },
            {
                question: "3. 在訓練分類模型時，train_test_split 函數的主要作用是什麼？",
                options: ["A. 訓練模型", "B. 切分數據集為訓練集和測試集", "C. 優化模型的參數", "D. 標準化數據"],
                correct: 1,
                explanation: "train_test_split 函數用來將數據集分為訓練集和測試集，這樣可以分別用來訓練和評估模型。"
            },
            {
                question: "4. 下列哪一項是準確率（Accuracy）的正確計算公式？",
                options: ["A. 正確分類的數量 / 測試數據的總數量", "B. 正確分類的數量 / 訓練數據的總數量", "C. 正確分類的數量 / 分類模型的運行時間", "D. 測試數據的總數量 / 訓練數據的總數量"],
                correct: 0,
                explanation: "準確率是指模型正確分類的樣本數量佔測試集樣本總數的比例。"
            },
            {
                question: "5. 在使用決策樹分類器時，哪個參數控制樹的最大深度？",
                options: ["A. n_estimators", "B. max_depth", "C. learning_rate", "D. criterion"],
                correct: 1,
                explanation: "max_depth 參數用來設置決策樹的最大深度，這可以控制模型的複雜度，避免過擬合。"
            },
            {
                "question": "6. 什麼是過擬合（Overfitting）？",
                "options": ["A. 模型在訓練集上的表現不佳", "B. 模型在測試集上的表現優於訓練集", "C. 模型過於複雜，以至於在訓練集上表現良好，但在測試集上表現不佳", "D. 模型過於簡單，無法在訓練和測試集上達到好的結果"],
                "correct": 2,
                "explanation": "過擬合指的是模型學習了訓練數據中的細節和噪聲，導致它在訓練集上表現良好，但在測試集上泛化能力差。"
            },
            {
                "question": "7. 下列哪一種方法可以用來防止模型過擬合？",
                "options": ["A. 增加模型的複雜度", "B. 增加數據集的樣本量", "C. 減少訓練次數", "D. 減少測試集的大小"],
                "correct": 1,
                "explanation": "增加數據集樣本量可以讓模型學習到更多的特徵，從而減少過擬合的風險。其他方法還包括使用正則化或剪枝技術等。"
            },
            {
                "question": "8. 當我們在訓練一個分類模型時，應該選擇哪種評估指標來檢查模型的性能？",
                "options": ["A. 平均絕對誤差（MAE）", "B. 均方誤差（MSE）", "C. 準確率（Accuracy）", "D. 平均方根誤差（RMSE）"],
                "correct": 2,
                "explanation": "對於分類問題，常用的評估指標是準確率，它衡量的是模型正確分類的樣本數佔總樣本數的比例。"
            },
            {
                "question": "9. 在 Python 的 scikit-learn 庫中，哪個函數用來將數據集分為訓練集和測試集？",
                "options": ["A. train_test_split()", "B. split_data()", "C. test_train_split()", "D. train_data_split()"],
                "correct": 0,
                "explanation": "train_test_split() 是 Scikit-learn 庫中的常用函數，用來將數據集隨機分為訓練集和測試集。"
            },
            {
                "question": "10. 在訓練決策樹模型時，criterion 參數的作用是什麼？",
                "options": ["A. 控制數據集的分割比例", "B. 設置模型的評估指標，例如基尼不純度或信息增益", "C. 控制模型的學習速率", "D. 決定模型的訓練次數"],
                "correct": 1,
                "explanation": "criterion 參數用來設置決策樹分裂時使用的準則，常見的有基尼不純度（gini）和信息增益（entropy）。這些準則決定如何選擇節點進行分裂。"
            }            
            // 可以繼續補充更多的題目
        ],
        'chapter3': [
            {
                "question": "1. 哪個分類器適合處理線性可分的二分類問題？",
                "options": ["A. 決策樹", "B. 隨機森林", "C. 邏輯迴歸", "D. k近鄰分類器"],
                "correct": 2,
                "explanation": "邏輯迴歸是一種線性分類模型，適合用於處理線性可分的問題。它基於輸入特徵的線性組合來預測輸出標籤，並常用於二分類問題。雖然名字裡有「迴歸」，但它實際上是一種分類算法。"
            },
            {
                "question": "2. 下列哪種方法能有效處理非線性分類問題？",
                "options": ["A. 支援向量機 (SVM) 使用線性核", "B. k近鄰分類器 (k-NN)", "C. 邏輯迴歸", "D. 朴素貝葉斯"],
                "correct": 1,
                "explanation": "k-NN 是一種非參數分類算法，可以處理非線性資料。它基於相似度來進行分類，不需要建立具體的模型，而是根據最近的 k 個鄰居來決定類別。雖然 SVM 也可以通過核函數處理非線性問題，但選項中指定的是「線性核」，這適用於線性問題。"
            },
            {
                "question": "3. 當你有一個高維數據集並希望進行分類時，哪個分類器更合適？",
                "options": ["A. 朴素貝葉斯", "B. 支援向量機 (SVM)", "C. 邏輯迴歸", "D. k近鄰分類器 (k-NN)"],
                "correct": 1,
                "explanation": "SVM 特別適合處理高維數據，因為它能有效地找到不同類別之間的最大邊界，甚至在非常高的維度下。通過使用不同的核函數，SVM 可以很好地應對非線性和高維數據。"
            },
            {
                "question": "4. 下列哪個分類器是基於貝葉斯定理的？",
                "options": ["A. 支援向量機", "B. 朴素貝葉斯", "C. 邏輯迴歸", "D. 決策樹"],
                "correct": 1,
                "explanation": "朴素貝葉斯分類器是基於貝葉斯定理的一種簡單但有效的模型。它假設每個特徵在給定類別的情況下是獨立的，這就是所謂的「朴素」假設。雖然假設簡單，但它在文本分類等高維資料中表現良好。"
            },
            {
                "question": "5. 哪個分類器通過多棵決策樹的集成來進行預測？",
                "options": ["A. k近鄰分類器", "B. 邏輯迴歸", "C. 隨機森林", "D. 朴素貝葉斯"],
                "correct": 2,
                "explanation": "隨機森林是一種基於多個決策樹的集成學習方法。它通過構建多棵隨機的決策樹，並通過投票機制來決定最終的分類結果。這種集成方法可以提高模型的穩定性和準確性，並降低單棵決策樹過擬合的風險。"
            },
            {
                "question": "6. 哪個分類器需要設置一個鄰居數 k 來進行分類？",
                "options": ["A. 隨機森林", "B. 決策樹", "C. k近鄰分類器 (k-NN)", "D. 支援向量機"],
                "correct": 2,
                "explanation": "k-NN 是基於鄰居間的距離來進行分類的。k 表示最近鄰居的數量，通過計算測試樣本與訓練資料中每個點的距離來決定其類別，鄰居中佔多數的類別即為預測類別。選擇不同的 k 值會影響分類結果。"
            },
            {
                "question": "7. 當你的資料中有大量噪聲時，哪個分類器最有可能出現過擬合的問題？",
                "options": ["A. 決策樹", "B. 支援向量機 (SVM)", "C. 隨機森林", "D. 朴素貝葉斯"],
                "correct": 0,
                "explanation": "決策樹容易在訓練資料中過擬合，特別是當數據中存在噪聲時。決策樹會嘗試適應所有的訓練數據，包括噪聲，這可能導致其對測試集的泛化能力較差。隨機森林可以通過多棵樹來減少這種影響，但單一決策樹通常需要使用剪枝等技術來防止過擬合。"
            },
            {
                "question": "8. 哪一個分類器通常通過不斷地提升弱學習器來進行集成？",
                "options": ["A. 決策樹", "B. 隨機森林", "C. 梯度提升機 (Gradient Boosting Machine, GBM)", "D. k近鄰分類器 (k-NN)"],
                "correct": 2,
                "explanation": "梯度提升機是一種集成學習方法，它通過不斷地增加新的弱學習器（通常是決策樹），來修正前一輪模型的錯誤。每次新增的模型都是為了減少前一次的預測誤差，這種方式能夠產生一個更強大的最終模型。"
            },
            {
                "question": "9. 在文本分類任務中，哪個分類器經常被選用，特別是對於高維和稀疏的數據集？",
                "options": ["A. 朴素貝葉斯", "B. 支援向量機", "C. 決策樹", "D. 隨機森林"],
                "correct": 0,
                "explanation": "朴素貝葉斯分類器因其簡單、高效，特別適合文本分類任務。文本數據往往是高維和稀疏的，朴素貝葉斯基於特徵的條件獨立假設，能夠在這些場景下表現良好，並且運行速度非常快。"
            },
            {
                "question": "10. 在支援向量機 (SVM) 中，核函數的作用是什麼？",
                "options": ["A. 減少計算資源", "B. 提高模型的解釋性", "C. 將資料映射到高維空間以便處理非線性問題", "D. 提高分類器的速度"],
                "correct": 2,
                "explanation": "核函數的作用是將資料從低維空間映射到高維空間，從而在高維空間中使非線性可分的資料變得線性可分。這是 SVM 強大的地方，可以通過不同的核函數（如 RBF 核、多項式核等）來處理複雜的分類問題。"
            }
        ],
        'chapter4': [
            {
                "question": "1. 在分類問題中，哪個指標可以衡量模型的正確預測佔總預測的比例？",
                "options": ["A. 精確率 (Precision)", "B. 召回率 (Recall)", "C. 準確率 (Accuracy)", "D. F1-Score"],
                "correct": 2,
                "explanation": "準確率是模型正確分類的數量佔總樣本數的比例，常用於衡量分類模型的總體效能。"
            },
            {
                "question": "2. 哪個演算法是用於二分類問題的基線模型？",
                "options": ["A. 支援向量機 (SVM)", "B. 邏輯迴歸 (Logistic Regression)", "C. k近鄰分類 (k-NN)", "D. 隨機森林 (Random Forest)"],
                "correct": 1,
                "explanation": "邏輯迴歸是一個常用的二分類基線模型，適合線性可分的二分類問題。儘管名字中含有「迴歸」，但實際上它是一個分類模型。"
            },
            {
                "question": "3. 在混淆矩陣中，\"True Positive\" (TP) 是什麼意思？",
                "options": ["A. 預測為正類，實際為負類", "B. 預測為負類，實際為正類", "C. 預測為正類，實際也為正類", "D. 預測為負類，實際也為負類"],
                "correct": 2,
                "explanation": "在混淆矩陣中，\"True Positive\" (TP) 表示模型將實際為正類的數據正確地預測為正類。"
            },
            {
                "question": "4. 什麼是F1-Score？",
                "options": ["A. 精確率和召回率的加權平均", "B. 精確率和召回率的調和平均", "C. 準確率和召回率的加權平均", "D. 準確率和精確率的加權平均"],
                "correct": 1,
                "explanation": "F1-Score 是精確率 (Precision) 和召回率 (Recall) 的調和平均，它平衡了精確率和召回率，用於處理類別不均衡問題。"
            },
            {
                "question": "5. 哪個分類演算法適合處理高維數據且支持線性與非線性分類？",
                "options": ["A. 邏輯迴歸 (Logistic Regression)", "B. 支援向量機 (SVM)", "C. 決策樹 (Decision Tree)", "D. 朴素貝葉斯 (Naive Bayes)"],
                "correct": 1,
                "explanation": "支援向量機 (SVM) 可以通過選擇不同的核函數來處理線性和非線性分類問題，特別適合於高維數據。"
            },
            {
                "question": "6. 哪個評估指標用於衡量分類模型對正類別的召回率？",
                "options": ["A. 精確率 (Precision)", "B. 召回率 (Recall)", "C. 準確率 (Accuracy)", "D. F1-Score"],
                "correct": 1,
                "explanation": "召回率（Recall）是指模型成功預測出所有實際正類別中的比例，衡量模型對正類別的敏感度。"
            },
            {
                "question": "7. 在分類問題中，當數據不均衡時，應該使用哪個評估指標？",
                "options": ["A. 準確率 (Accuracy)", "B. F1-Score", "C. 均方誤差 (MSE)", "D. 平均絕對誤差 (MAE)"],
                "correct": 1,
                "explanation": "F1-Score 更適合於數據不均衡的情況，因為它是精確率和召回率的調和平均，能更好地反映模型的性能。"
            },
            {
                "question": "8. 交叉驗證 (Cross Validation) 的主要目的是什麼？",
                "options": ["A. 提高模型的運行速度", "B. 增加訓練集的大小", "C. 減少模型的過擬合", "D. 減少模型的欠擬合"],
                "correct": 2,
                "explanation": "交叉驗證通過多次分割數據集來驗證模型性能，從而減少過擬合風險，使模型在測試集上的表現更加穩定。"
            },
            {
                "question": "9. 在使用 k近鄰分類器 (k-NN) 時，k 值越小會導致什麼結果？",
                "options": ["A. 模型的複雜度下降", "B. 模型容易過擬合", "C. 模型的計算速度加快", "D. 模型更具泛化能力"],
                "correct": 1,
                "explanation": "在 k-NN 中，較小的 k 值意味著分類決策依賴於更少的鄰居，這可能會使模型過擬合到訓練數據上的細節和噪聲。"
            },
            {
                "question": "10. 隨機森林 (Random Forest) 是什麼類型的模型？",
                "options": ["A. 集成學習 (Ensemble Learning)", "B. 單一決策樹 (Single Decision Tree)", "C. 聚類演算法 (Clustering Algorithm)", "D. 維度減少演算法 (Dimensionality Reduction Algorithm)"],
                "correct": 0,
                "explanation": "隨機森林是一種集成學習方法，通過多個決策樹的集成來進行分類或迴歸，從而提高模型的穩定性和準確性。"
            }            
        ],
        'chapter5': [
            {
                "question": "1. 數據預處理的第一步通常是什麼？",
                "options": ["A. 標準化", "B. 缺失值處理", "C. 特徵選擇", "D. 模型構建"],
                "correct": 1,
                "explanation": "在數據預處理的過程中，第一步通常是處理數據集中的缺失值。這是因為缺失值會影響模型的訓練和準確性，必須先處理才能進行後續的步驟。"
            },
            {
                "question": "2. 在數據標準化中，數據會被轉換為什麼樣的形式？",
                "options": ["A. 所有值介於 0 和 1 之間", "B. 所有值有相同的範圍", "C. 均值為 0，標準差為 1", "D. 所有特徵被轉換為二進制形式"],
                "correct": 2,
                "explanation": "數據標準化是將數據轉換成均值為 0、標準差為 1 的形式，這樣可以消除不同特徵之間尺度差異的影響，特別是在梯度下降等演算法中很有用。"
            },
            {
                "question": "3. 什麼是 One-Hot 編碼的作用？",
                "options": ["A. 使所有數據值介於 0 和 1 之間", "B. 將連續型變量轉換為類別型變量", "C. 將類別變量轉換為二進制變量", "D. 用於處理缺失數據"],
                "correct": 2,
                "explanation": "One-Hot 編碼將類別變量轉換為二進制變量，每個類別用一個獨立的二進制向量表示，從而解決類別之間沒有順序關係的問題。"
            },
            {
                "question": "4. 當數據分佈範圍差異很大時，應該使用哪種預處理技術？",
                "options": ["A. 正規化", "B. One-Hot 編碼", "C. 缺失值處理", "D. 主成分分析（PCA）"],
                "correct": 0,
                "explanation": "當數據的分佈範圍差異很大時，正規化可以將數據縮放到相同的範圍（如 [0,1]），以防止某些特徵對模型的影響過大。"
            },
            {
                "question": "5. 當我們希望降低數據的維度並保留大部分信息時，應該使用哪種技術？",
                "options": ["A. 標準化", "B. 缺失值插補", "C. 正規化", "D. 主成分分析（PCA）"],
                "correct": 3,
                "explanation": "PCA 是一種用於降維的技術，通過選擇數據中最具變異性的特徵來降低數據的維度，同時保留數據中的大部分信息。"
            },
            {
                "question": "6. 在數據預處理中，為什麼要進行數據平衡？",
                "options": ["A. 平衡數據以減少計算資源", "B. 平衡數據以避免模型偏向多數類別", "C. 平衡數據以加快訓練速度", "D. 平衡數據以減少特徵數量"],
                "correct": 1,
                "explanation": "當數據不平衡時（即某些類別的數據樣本明顯多於其他類別），模型可能會偏向於多數類別。通過平衡數據，可以減少模型對多數類別的偏見，提升模型的泛化能力。"
            },
            {
                "question": "7. Label Encoding 是如何處理類別變量的？",
                "options": ["A. 將每個類別轉換為唯一的整數標籤", "B. 將類別變量轉換為二進制向量", "C. 將類別變量範圍壓縮到 [0,1]", "D. 將數值型變量轉換為類別型變量"],
                "correct": 0,
                "explanation": "Label Encoding 是將類別變量轉換為數值型標籤，每個類別對應一個唯一的整數值。這種方法適合類別之間有順序關係的情況。"
            },
            {
                "question": "8. 哪種方法不屬於數據清理的範疇？",
                "options": ["A. 缺失值處理", "B. 去除重複值", "C. 標準化", "D. 修正異常值"],
                "correct": 2,
                "explanation": "數據清理的主要內容包括缺失值處理、去除重複值和修正異常值等，而標準化屬於數據轉換範疇，並不直接屬於數據清理。"
            },
            {
                "question": "9. 當我們的數據集非常稀疏時，應該使用哪種編碼方法來表示類別特徵？",
                "options": ["A. One-Hot 編碼", "B. Label 編碼", "C. 數值型編碼", "D. 稀疏矩陣表示法"],
                "correct": 0,
                "explanation": "當數據非常稀疏時，One-Hot 編碼將類別變量轉換為二進制向量，並且每個類別獨立地表示，這種方法能更好地處理稀疏性問題。"
            },
            {
                "question": "10. 在進行主成分分析（PCA）時，為什麼需要對數據進行標準化？",
                "options": ["A. 防止 PCA 過度偏向具有較大數值範圍的特徵", "B. 讓 PCA 更容易計算", "C. 確保所有特徵具有相同的平均值", "D. 為了將數據縮放到 [0,1] 範圍"],
                "correct": 0,
                "explanation": "PCA 受特徵尺度影響很大，較大的特徵數值範圍會導致 PCA 偏向這些特徵。標準化可以將所有特徵縮放到相同的尺度，避免這種情況發生。"
            }
        ]            
    };

    let currentChapter = 'chapter1';  // 預設章節
    const questionContainer = document.getElementById('question-container');
    const resultContainer = document.getElementById('result-container');
    const scoreDisplay = document.getElementById('score');
    const correctAnswersDisplay = document.getElementById('correct-answers');

    // 顯示章節的題目
    function displayQuestions(chapter) {
        questionContainer.innerHTML = '';  // 清空現有的題目

        questions[chapter].forEach((q, index) => {
            const questionElement = document.createElement('div');
            questionElement.className = 'question';

            // 顯示題目
            const questionText = document.createElement('h3');
            questionText.innerText = `${index + 1}. ${q.question}`;
            questionElement.appendChild(questionText);

            // 顯示選項
            q.options.forEach((option, optionIndex) => {
                const optionElement = document.createElement('div');
                optionElement.className = 'option';

                const radioInput = document.createElement('input');
                radioInput.type = 'radio';
                radioInput.name = `question${index}`;
                radioInput.value = optionIndex;
                radioInput.id = `question${index}-option${optionIndex}`;

                const label = document.createElement('label');
                label.setAttribute('for', radioInput.id);
                label.innerText = option;

                optionElement.appendChild(radioInput);
                optionElement.appendChild(label);

                questionElement.appendChild(optionElement);
            });

            questionContainer.appendChild(questionElement);
        });
    }

    // 計算成績
    function calculateScore(chapter) {
        let score = 0;
        let totalQuestions = questions[chapter].length;
        let correctAnswers = [];

        questions[chapter].forEach((q, index) => {
            const selectedOption = document.querySelector(`input[name="question${index}"]:checked`);
            if (selectedOption && parseInt(selectedOption.value) === q.correct) {
                score += 1;
            }

            correctAnswers.push({
                question: q.question,
                correctAnswer: q.options[q.correct],
                explanation: q.explanation
            });
        });

        return { score, totalQuestions, correctAnswers };
    }

    // 顯示成績和正確解答
    function displayResults(scoreData) {
        const { score, totalQuestions, correctAnswers } = scoreData;
        let finalScore = (score / totalQuestions) * 100;  // 以 100 分計算

        scoreDisplay.innerText = `你的成績是 ${finalScore} 分`;

        correctAnswersDisplay.innerHTML = '';
        correctAnswers.forEach((answerData, index) => {
            const answerElement = document.createElement('div');
            answerElement.className = 'answer';

            const questionText = document.createElement('h4');
            questionText.innerText = `${index + 1}. ${answerData.question}`;
            answerElement.appendChild(questionText);

            const correctAnswerText = document.createElement('p');
            correctAnswerText.innerHTML = `<strong>正確答案: </strong> ${answerData.correctAnswer}`;
            answerElement.appendChild(correctAnswerText);

            const explanationText = document.createElement('p');
            explanationText.innerHTML = `<strong>解釋: </strong> ${answerData.explanation}`;
            answerElement.appendChild(explanationText);

            correctAnswersDisplay.appendChild(answerElement);
        });

        resultContainer.style.display = 'block';
    }

    // 初始化顯示第一章題目
    displayQuestions(currentChapter);

    // 監聽章節選擇
    document.getElementById('chapter-select').addEventListener('change', function(event) {
        currentChapter = event.target.value;
        displayQuestions(currentChapter);
        resultContainer.style.display = 'none';  // 切換章節後隱藏結果
    });

    // 提交按鈕功能
    document.getElementById('submit-btn').addEventListener('click', function() {
        const scoreData = calculateScore(currentChapter);
        displayResults(scoreData);
    });
});
