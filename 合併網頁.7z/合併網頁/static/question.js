// 機器學習基本概念選擇題數據，包含解釋
const questions = [
    {
        question: "1. 什麼是過擬合 (Overfitting)？",
        options: ["模型對訓練數據的適應過度，導致泛化能力差", "模型無法適應訓練數據", "模型在新數據上的表現很好", "增加訓練數據能解決過擬合"],
        correct: 0,
        explanation: "過擬合是模型過度適應訓練數據而無法泛化到新數據。"
    },
    {
        question: "2. 在監督學習中，哪一項是標籤 (Label)？",
        options: ["模型的輸出", "模型的輸入", "特徵的選擇", "訓練數據"],
        correct: 0,
        explanation: "標籤是監督學習中的正確答案，通常是模型的輸出。"
    },
    {
        question: "3. 以下哪一項是用於回歸問題的演算法？",
        options: ["K-最近鄰", "線性回歸", "決策樹", "支持向量機"],
        correct: 1,
        explanation: "線性回歸是一種用於回歸問題的演算法。"
    },
    {
        question: "4. 哪一種是無監督學習方法？",
        options: ["K-均值聚類", "線性回歸", "羅吉斯迴歸", "支持向量機"],
        correct: 0,
        explanation: "K-均值聚類是無監督學習的常見方法之一。"
    },
    {
        question: "5. 偏差-方差權衡的作用是什麼？",
        options: ["用來調整模型的複雜度和準確性", "減少訓練數據的數量", "增加訓練數據", "選擇正確的特徵"],
        correct: 0,
        explanation: "偏差-方差權衡是指在模型的複雜度和泛化能力之間找到平衡。"
    }
];

let currentQuestion = 0;
let userAnswers = [];

// 顯示問題
function displayQuestion() {
    const questionContainer = document.getElementById("question");
    const optionsContainer = document.getElementById("options");
    const question = questions[currentQuestion];

    questionContainer.innerText = question.question;
    optionsContainer.innerHTML = '';

    // 顯示選項，並檢查是否已選過答案
    question.options.forEach((option, index) => {
        const isChecked = userAnswers[currentQuestion] === index ? 'checked' : '';
        const optionElement = document.createElement('div');
        optionElement.className = 'option';
        optionElement.innerHTML = `<input type="radio" name="answer" value="${index}" id="option${index}" ${isChecked}>
                                   <label for="option${index}">${option}</label>`;
        optionsContainer.appendChild(optionElement);
    });

    // 切換按鈕顯示
    const nextButton = document.getElementById("nextquestion-button");
    const finishButton = document.getElementById("finish-button");

    if (currentQuestion === questions.length - 1) {
        nextButton.style.display = "none"; // 隱藏“下一題”按鈕
        finishButton.style.display = "block"; // 顯示“完成”按鈕
    } else {
        nextButton.style.display = "block"; // 顯示“下一題”按鈕
        finishButton.style.display = "none"; // 隱藏“完成”按鈕
    }
}

// 保存用戶的答案
function saveAnswer() {
    const selectedOption = document.querySelector('input[name="answer"]:checked');
    if (selectedOption) {
        userAnswers[currentQuestion] = parseInt(selectedOption.value);
    }
}

// 下一題按鈕功能
function nextQuestion() {
    saveAnswer();
    if (currentQuestion < questions.length - 1) {
        currentQuestion++;
        displayQuestion();
    }
}

// 上一題按鈕功能
function prevQuestion() {
    saveAnswer();
    if (currentQuestion > 0) {
        currentQuestion--;
        displayQuestion();
    }
}

// 計算分數並顯示最終解答與分數
function finishQuiz() {
    saveAnswer();
    let score = 0;
    let resultHTML = "<h2>結果：</h2>";
    
    questions.forEach((question, index) => {
        const userAnswer = userAnswers[index];
        const correctAnswer = question.correct;
        const isCorrect = userAnswer === correctAnswer;

        // 計算分數
        if (isCorrect) {
            score += 20;
        }

        // 顯示每個問題的結果和解釋
        resultHTML += `
            <div>
                <h3>${question.question}</h3>
                <p>您的答案: ${question.options[userAnswer] !== undefined ? question.options[userAnswer] : '未選擇'}</p>
                <p>正確答案: ${question.options[correctAnswer]}</p>
                <p>解釋: ${question.explanation}</p>
            </div><hr>`;
    });

    resultHTML += `<h3>您的總分: ${score} / 100</h3>`;

    // 包裹結果在白色半透明方框中
    const quizContainer = document.getElementById("quiz-container");
    quizContainer.innerHTML = `<div class="result-box">${resultHTML}</div>`;
}

window.onload = function() {
    displayQuestion();
}
