document.addEventListener("DOMContentLoaded", () => {
  console.log("Quiz Editor initialized");
  const urlParams = new URLSearchParams(window.location.search);
  const courseId = urlParams.get("course_id");
  const quizIdParam = urlParams.get("quiz_id");
  const mode = urlParams.get("mode"); // "edit" 或 "view"

  // 取得各區塊與表單元件
  const createQuizForm = document.getElementById("create-quiz-form");
  const quizCreationSection = document.getElementById("quiz-creation-section");
  const questionManagementSection = document.getElementById("question-management-section");
  const scoreDisplay = document.getElementById("score-display");
  const uploadQuestionForm = document.getElementById("upload-question-form");
  const questionTypeSelect = document.getElementById("question-type");
  const questionText = document.getElementById("question-text");
  const questionOptionsContainer = document.getElementById("question-options-container");
  const addOptionBtn = document.getElementById("add-option-btn");
  const questionScoreInput = document.getElementById("question-score");
  const finalizeQuizBtn = document.getElementById("finalize-quiz-btn");
  const quizTotalScoreSpan = document.getElementById("quiz-total-score");
  const questionsListDiv = document.getElementById("questions-list");

  let currentQuizId = quizIdParam ? quizIdParam : null;
  let quizTotalScore = 0;

  // 如果 URL 中已有 quiz_id，則代表是既有測驗（編輯或僅查看），否則必須先建立測驗
  if (currentQuizId) {
    quizCreationSection.style.display = "none";
    questionManagementSection.style.display = "block";
    scoreDisplay.style.display = "block";
    if (mode === "view") {
      uploadQuestionForm.style.display = "none";
      finalizeQuizBtn.style.display = "none";
    } else {
      uploadQuestionForm.style.display = "block";
      finalizeQuizBtn.style.display = "block";
    }
    loadQuestions();
  } else {
    quizCreationSection.style.display = "block";
    questionManagementSection.style.display = "none";
    scoreDisplay.style.display = "none";
  }

  // 載入題目列表，呼叫後端 API: /get_quiz_questions?quiz_id=...
  async function loadQuestions() {
    if (!currentQuizId) {
      alert("請先建立測驗！");
      return;
    }
    try {
      const response = await fetch(`/get_quiz_questions?quiz_id=${currentQuizId}`);
      if (response.status === 404) {
        questionsListDiv.innerHTML = "<p>尚無題目</p>";
        return;
      }
      if (!response.ok) throw new Error("無法載入題目");
      const questions = await response.json();
      questionsListDiv.innerHTML = "";
      if (questions.length === 0) {
        questionsListDiv.innerHTML = "<p>尚無題目</p>";
        return;
      }
      questions.forEach((q, index) => {
        const qDiv = document.createElement("div");
        qDiv.className = "question-item";
        qDiv.style.borderBottom = "1px solid #ddd";
        qDiv.style.padding = "5px 0";
        // 注意此處使用 q.id（代表資料庫中的題目主鍵）
        qDiv.innerHTML = `<strong>${index + 1}. [${q.question_type === 'multiple_choice' ? "選擇題" : "簡答題"}]</strong> ${q.question_text} (分數: ${q.score})`;
        if (q.question_type === 'multiple_choice' && q.options && q.options.length > 0) {
          const ul = document.createElement("ul");
          q.options.forEach((opt, idx) => {
            const li = document.createElement("li");
            li.textContent = `${idx + 1}. ${opt.option_text} ${opt.is_correct ? "(正確)" : ""}`;
            ul.appendChild(li);
          });
          qDiv.appendChild(ul);
        }
        // 若為編輯模式則顯示編輯與刪除按鈕
        if (mode !== "view") {
          const editBtn = document.createElement("button");
          editBtn.textContent = "編輯";
          editBtn.addEventListener("click", () => {
            editQuestion(q);
          });
          qDiv.appendChild(editBtn);

          const deleteBtn = document.createElement("button");
          deleteBtn.textContent = "刪除";
          deleteBtn.addEventListener("click", () => {
            deleteQuestion(q.id, q.score);
          });
          qDiv.appendChild(deleteBtn);
        }
        questionsListDiv.appendChild(qDiv);
      });
    } catch (error) {
      console.error("載入題目失敗", error);
      alert("載入題目失敗，請稍後再試！");
    }
  }

  // 編輯題目：可修改題目內容、分數、選項內容與正確答案（僅適用於選擇題）
  async function editQuestion(question) {
    const newText = prompt("修改題目內容：", question.question_text);
    if (newText === null) return;
    const newScoreStr = prompt("修改分數：", question.score);
    const newScore = parseFloat(newScoreStr);
    if (!newText || isNaN(newScore)) {
      alert("無效的輸入");
      return;
    }
    let newOptions = [];
    if (question.question_type === "multiple_choice") {
      for (let i = 0; i < question.options.length; i++) {
        const opt = question.options[i];
        let newOptText = prompt(`修改選項 ${i + 1} 內容：`, opt.option_text);
        if (newOptText === null) {
          newOptText = opt.option_text;
        }
        newOptions.push({ option_text: newOptText, is_correct: false });
      }
      const correctIndexStr = prompt("請輸入正確選項的編號（從 1 開始）：", "1");
      const correctIndex = parseInt(correctIndexStr, 10);
      if (isNaN(correctIndex) || correctIndex < 1 || correctIndex > newOptions.length) {
        alert("正確選項輸入錯誤");
        return;
      }
      newOptions = newOptions.map((opt, idx) => ({
        option_text: opt.option_text,
        is_correct: idx === correctIndex - 1
      }));
    }
    try {
      const payload = {
        quiz_id: currentQuizId,
        question_id: question.id,
        question_text: newText,
        score: newScore
      };
      if (question.question_type === "multiple_choice") {
        payload.options = newOptions;
      }
      const response = await fetch("/update_question", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (response.ok) {
        alert("題目更新成功");
        quizTotalScore = quizTotalScore - question.score + newScore;
        quizTotalScoreSpan.textContent = quizTotalScore;
        loadQuestions();
      } else {
        const errorData = await response.json();
        alert("題目更新失敗：" + errorData.error);
      }
    } catch (error) {
      console.error("更新題目時發生錯誤", error);
    }
  }

  // 刪除題目
  async function deleteQuestion(question_id, score) {
    if (!confirm("確定刪除此題目？")) return;
    try {
      const response = await fetch("/delete_question", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quiz_id: currentQuizId,
          question_id: question_id
        })
      });
      if (response.ok) {
        alert("題目刪除成功");
        quizTotalScore -= score;
        quizTotalScoreSpan.textContent = quizTotalScore;
        loadQuestions();
      } else {
        const errorData = await response.json();
        alert("題目刪除失敗：" + errorData.error);
      }
    } catch (error) {
      console.error("刪除題目時發生錯誤", error);
    }
  }

  // 建立新測驗（僅在無 quiz_id 時使用）
  createQuizForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const quizName = document.getElementById("quiz-name").value.trim();
    const quizDescription = document.getElementById("quiz-description").value.trim();
    if (!quizName) {
      alert("測驗名稱不能為空！");
      return;
    }
    try {
      const response = await fetch("/create_quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ course_id: courseId, name: quizName, description: quizDescription })
      });
      if (response.ok) {
        const data = await response.json();
        alert("測驗建立成功！");
        // 後端回傳的屬性是 quiz_id，不是 id
        quizCreationSection.style.display = "none";
        currentQuizId = data.quiz_id;
        quizTotalScore = 0;
        quizTotalScoreSpan.textContent = quizTotalScore;
        questionManagementSection.style.display = "block";
        scoreDisplay.style.display = "block";
        // 更新 URL，加入 quiz_id 參數
        const newUrl = new URL(window.location);
        newUrl.searchParams.set("quiz_id", currentQuizId);
        window.history.replaceState({}, "", newUrl);
        loadQuestions();
      } else {
        const errorData = await response.json();
        alert("測驗建立失敗：" + errorData.error);
      }
    } catch (error) {
      console.error("建立測驗時發生錯誤：", error);
      alert("建立測驗失敗，請稍後再試！");
    }
  });

  // 當題型變更時：若選擇題則產生預設 4 個選項欄位
  questionTypeSelect.addEventListener("change", () => {
    if (questionTypeSelect.value === "multiple_choice") {
      questionOptionsContainer.innerHTML = "";
      for (let i = 0; i < 4; i++) {
        const optionDiv = document.createElement("div");
        optionDiv.classList.add("option-row");

        const radio = document.createElement("input");
        radio.type = "radio";
        radio.name = "correct_option";
        radio.value = i;
        optionDiv.appendChild(radio);

        const textInput = document.createElement("input");
        textInput.type = "text";
        textInput.className = "option-text";
        textInput.placeholder = "選項內容";
        optionDiv.appendChild(textInput);

        questionOptionsContainer.appendChild(optionDiv);
      }
      questionOptionsContainer.style.display = "block";
    } else {
      questionOptionsContainer.style.display = "none";
    }
  });

  // 新增選項（僅適用於選擇題）
  addOptionBtn.addEventListener("click", () => {
    const optionDiv = document.createElement("div");
    optionDiv.classList.add("option-row");

    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "correct_option";
    radio.value = questionOptionsContainer.querySelectorAll(".option-row").length;
    optionDiv.appendChild(radio);

    const textInput = document.createElement("input");
    textInput.type = "text";
    textInput.className = "option-text";
    textInput.placeholder = "選項內容";
    optionDiv.appendChild(textInput);

    questionOptionsContainer.appendChild(optionDiv);
  });

  // 上傳題目（新增題目）
  uploadQuestionForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const qType = questionTypeSelect.value;
    const qText = questionText.value.trim();
    const qScore = parseFloat(questionScoreInput.value);
    if (!qText || isNaN(qScore)) {
      alert("請填寫題目內容與有效分數！");
      return;
    }
    if (qScore <= 0 || qScore > 100) {
      alert("題目分數必須大於 0 且不超過 100！");
      return;
    }
    let options = [];
    if (qType === "multiple_choice") {
      const optionRows = questionOptionsContainer.querySelectorAll(".option-row");
      const selectedRadio = questionOptionsContainer.querySelector('input[name="correct_option"]:checked');
      if (!selectedRadio) {
        alert("請選擇正確答案！");
        return;
      }
      const correctIndex = parseInt(selectedRadio.value, 10);
      let valid = true;
      optionRows.forEach((row, index) => {
        const textInput = row.querySelector(".option-text");
        const text = textInput.value.trim();
        if (!text) {
          alert("所有選項都必須填寫！");
          valid = false;
        } else {
          options.push({
            option_text: text,
            is_correct: index === correctIndex
          });
        }
      });
      if (!valid || options.length < 4) {
        alert("至少必須有 4 個完整選項！");
        return;
      }
    }
    try {
      const payload = {
        quiz_id: currentQuizId,
        question_type: qType,
        question_text: qText,
        score: qScore,
        options: options
      };
      console.log("上傳題目 payload:", payload);
      const response = await fetch("/upload_question", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (response.ok) {
        alert("題目上傳成功！");
        quizTotalScore += qScore;
        quizTotalScoreSpan.textContent = quizTotalScore;
        uploadQuestionForm.reset();
        questionOptionsContainer.innerHTML = "";
        loadQuestions();
      } else {
        const errorData = await response.json();
        alert("題目上傳失敗：" + errorData.error);
      }
    } catch (error) {
      console.error("上傳題目時發生錯誤：", error);
      alert("上傳題目失敗，請稍後再試！");
    }
  });

  // 最終建立測驗：檢查所有題目的分數總和必須等於 100 分
  finalizeQuizBtn.addEventListener("click", async () => {
    if (quizTotalScore !== 100) {
      alert("所有題目的分數總和必須等於 100 分，目前總分：" + quizTotalScore);
      return;
    }
    try {
      const response = await fetch("/finalize_quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quiz_id: currentQuizId })
      });
      if (response.ok) {
        alert("測驗最終建立成功！");
        window.location.href = "quizzes.html?course_id=" + courseId;
      } else {
        const errorData = await response.json();
        alert("最終建立測驗失敗：" + errorData.error);
      }
    } catch (error) {
      console.error("最終建立測驗時發生錯誤：", error);
      alert("最終建立測驗失敗，請稍後再試！");
    }
  });
});
