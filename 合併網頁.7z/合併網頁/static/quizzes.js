document.addEventListener("DOMContentLoaded", () => {
    console.log("測驗管理頁面初始化");
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get("course_id");
  
    const createQuizForm = document.getElementById("create-quiz-form");
    const uploadQuestionForm = document.getElementById("upload-question-form");
    const questionTypeSelect = document.getElementById("question-type");
    const questionText = document.getElementById("question-text");
    const questionOptionsContainer = document.getElementById("question-options-container");
    const addOptionBtn = document.getElementById("add-option-btn");
    const questionScoreInput = document.getElementById("question-score");
    const quizzesListDiv = document.getElementById("quizzes-list");
    const finalizeQuizBtn = document.getElementById("finalize-quiz-btn");
    const quizTotalScoreSpan = document.getElementById("quiz-total-score");
  
    let currentQuizId = null;
    let quizTotalScore = 0;
  
    createQuizForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const quizName = document.getElementById("quiz-name").value.trim();
      const quizDescription = document.getElementById("quiz-description").value.trim();
      if (!quizName) {
        alert("測驗名稱不能為空！");
        return;
      }
      try {
        const response = await fetch("/create_quiz", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ course_id: courseId, name: quizName, description: quizDescription })
        });
        if (response.ok) {
          const data = await response.json();
          alert("測驗建立成功！");
          createQuizForm.reset();
          currentQuizId = data.quiz_id;
          quizTotalScore = 0;
          quizTotalScoreSpan.textContent = quizTotalScore;
          uploadQuestionForm.style.display = "block";
          finalizeQuizBtn.style.display = "block";
          loadQuizzes();
        } else {
          const errorData = await response.json();
          alert("測驗建立失敗：" + errorData.error);
        }
      } catch (error) {
        console.error("建立測驗時發生錯誤：", error);
        alert("建立測驗失敗，請稍後再試！");
      }
    });
  
    // 當題型變更時：若為選擇題則自動產生 4 個選項輸入欄位
    questionTypeSelect.addEventListener("change", () => {
      if (questionTypeSelect.value === "multiple_choice") {
        questionOptionsContainer.innerHTML = "";
        for (let i = 0; i < 4; i++) {
          const optionDiv = document.createElement("div");
          optionDiv.classList.add("option-row");
  
          const radio = document.createElement("input");
          radio.type = "radio";
          radio.name = "correct_option";
          radio.value = i;
          optionDiv.appendChild(radio);
  
          const textInput = document.createElement("input");
          textInput.type = "text";
          textInput.className = "option-text";
          textInput.placeholder = "選項內容";
          optionDiv.appendChild(textInput);
  
          questionOptionsContainer.appendChild(optionDiv);
        }
        questionOptionsContainer.style.display = "block";
      } else {
        questionOptionsContainer.style.display = "none";
      }
    });
  
    addOptionBtn.addEventListener("click", () => {
      const optionDiv = document.createElement("div");
      optionDiv.classList.add("option-row");
  
      const radio = document.createElement("input");
      radio.type = "radio";
      radio.name = "correct_option";
      radio.value = questionOptionsContainer.querySelectorAll(".option-row").length;
      optionDiv.appendChild(radio);
  
      const textInput = document.createElement("input");
      textInput.type = "text";
      textInput.className = "option-text";
      textInput.placeholder = "選項內容";
      optionDiv.appendChild(textInput);
  
      questionOptionsContainer.appendChild(optionDiv);
    });
  
    uploadQuestionForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const qType = questionTypeSelect.value;
      const qText = questionText.value.trim();
      const qScore = parseFloat(questionScoreInput.value);
      if (!qText || isNaN(qScore)) {
        alert("請填寫題目內容與有效分數！");
        return;
      }
      if (qScore <= 0 || qScore > 100) {
        alert("題目分數必須大於 0 且不超過 100！");
        return;
      }
      let options = [];
      if (qType === "multiple_choice") {
        const optionRows = questionOptionsContainer.querySelectorAll(".option-row");
        const selectedRadio = questionOptionsContainer.querySelector('input[name="correct_option"]:checked');
        if (!selectedRadio) {
          alert("請選擇正確答案！");
          return;
        }
        const correctIndex = parseInt(selectedRadio.value, 10);
        optionRows.forEach((row, index) => {
          const textInput = row.querySelector(".option-text");
          const text = textInput.value.trim();
          if (!text) {
            alert("所有選項都必須填寫！");
            return;
          }
          options.push({
            option_text: text,
            is_correct: index === correctIndex
          });
        });
        if (options.length < 4) {
          alert("至少必須有 4 個選項！");
          return;
        }
      }
      try {
        const response = await fetch("/upload_question", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            quiz_id: currentQuizId,
            question_type: qType,
            question_text: qText,
            score: qScore,
            options: options
          })
        });
        if (response.ok) {
          alert("題目上傳成功！");
          quizTotalScore += qScore;
          quizTotalScoreSpan.textContent = quizTotalScore;
          uploadQuestionForm.reset();
          questionOptionsContainer.innerHTML = "";
          loadQuizzes();
        } else {
          const errorData = await response.json();
          alert("題目上傳失敗：" + errorData.error);
        }
      } catch (error) {
        console.error("上傳題目時發生錯誤：", error);
        alert("上傳題目失敗，請稍後再試！");
      }
    });
  
    finalizeQuizBtn.addEventListener("click", async () => {
      if (quizTotalScore !== 100) {
        alert("所有題目的分數總和必須等於 100 分，目前總分：" + quizTotalScore);
        return;
      }
      try {
        const response = await fetch("/finalize_quiz", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ quiz_id: currentQuizId })
        });
        if (response.ok) {
          alert("測驗最終建立成功！");
          currentQuizId = null;
          quizTotalScore = 0;
          quizTotalScoreSpan.textContent = quizTotalScore;
          uploadQuestionForm.style.display = "none";
          finalizeQuizBtn.style.display = "none";
          loadQuizzes();
        } else {
          const errorData = await response.json();
          alert("最終建立測驗失敗：" + errorData.error);
        }
      } catch (error) {
        console.error("最終建立測驗時發生錯誤：", error);
        alert("最終建立測驗失敗，請稍後再試！");
      }
    });
  
    async function loadQuizzes() {
      try {
        const response = await fetch("/get_quizzes?course_id=" + courseId);
        if (!response.ok) throw new Error("無法載入測驗");
        const quizzes = await response.json();
        quizzesListDiv.innerHTML = "";
        if (quizzes.length === 0) {
          quizzesListDiv.innerHTML = "<p>目前沒有測驗。</p>";
          return;
        }
        quizzes.forEach(quiz => {
          const div = document.createElement("div");
          div.classList.add("quiz-item");
          div.textContent = quiz.name;
          div.addEventListener("click", () => {
            currentQuizId = quiz.id;
            uploadQuestionForm.style.display = "block";
            finalizeQuizBtn.style.display = "block";
            // 此處可進一步載入該測驗的題目列表與作答狀況
          });
          quizzesListDiv.appendChild(div);
        });
      } catch (error) {
        console.error("載入測驗時發生錯誤：", error);
        quizzesListDiv.innerHTML = "<p>載入測驗失敗，請稍後再試！</p>";
      }
    }
  
    loadQuizzes();
  });
  