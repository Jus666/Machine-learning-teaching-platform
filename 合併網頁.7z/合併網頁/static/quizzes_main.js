document.addEventListener("DOMContentLoaded", () => {
  const urlParams = new URLSearchParams(window.location.search);
  const courseId = urlParams.get("course_id");
  
  const newQuizBtn = document.getElementById("new-quiz-btn");
  const quizzesListDiv = document.getElementById("quizzes-list");

  // 按下「新增測驗」時，導向 quiz_editor.html 進行測驗建立
  newQuizBtn.addEventListener("click", () => {
    window.location.href = `quiz_editor.html?course_id=${courseId}`;
  });

  // 載入測驗列表
  async function loadQuizzes() {
    try {
      const response = await fetch(`/get_quizzes?course_id=${courseId}`);
      if (!response.ok) throw new Error("無法載入測驗");
      const quizzes = await response.json();
      quizzesListDiv.innerHTML = "";
      if (quizzes.length === 0) {
        quizzesListDiv.innerHTML = "<p>目前沒有測驗。</p>";
        return;
      }
      quizzes.forEach(quiz => {
        const quizDiv = document.createElement("div");
        quizDiv.classList.add("quiz-item");
        quizDiv.style.borderBottom = "1px solid #ddd";
        quizDiv.style.padding = "10px";
        // 顯示測驗名稱與狀態
        quizDiv.innerHTML = `<strong>${quiz.name}</strong> ${quiz.finalized ? "(已最終建立)" : "(未完成)"}<br>`;
        
        // 編輯按鈕：傳入 quiz_id 與 mode=edit，表示進入編輯模式
        const editBtn = document.createElement("button");
        editBtn.textContent = "編輯";
        editBtn.addEventListener("click", () => {
          window.location.href = `quiz_editor.html?course_id=${courseId}&quiz_id=${quiz.id}&mode=edit`;
        });
        quizDiv.appendChild(editBtn);
        
        // 查看按鈕：傳入 quiz_id 與 mode=view，表示僅查看模式
        const viewBtn = document.createElement("button");
        viewBtn.textContent = "查看";
        viewBtn.style.marginLeft = "10px";
        viewBtn.addEventListener("click", () => {
            window.location.href = `quiz_editor.html?course_id=${courseId}&quiz_id=${quiz.id}&mode=view`;
        });
        quizDiv.appendChild(viewBtn);
        
        // 刪除按鈕：呼叫後端 API 刪除此測驗
        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "刪除";
        deleteBtn.style.marginLeft = "10px";
        deleteBtn.addEventListener("click", async () => {
          if (confirm("確定刪除此測驗嗎？")) {
            try {
              const delResponse = await fetch("/delete_quiz", {
                method: "DELETE",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ quiz_id: quiz.id })
              });
              if (delResponse.ok) {
                alert("測驗刪除成功");
                loadQuizzes();
              } else {
                const errorData = await delResponse.json();
                alert("測驗刪除失敗：" + errorData.error);
              }
            } catch (error) {
              console.error("刪除測驗時發生錯誤", error);
            }
          }
        });
        quizDiv.appendChild(deleteBtn);
        
        quizzesListDiv.appendChild(quizDiv);
      });
    } catch (error) {
      console.error("載入測驗時發生錯誤：", error);
      quizzesListDiv.innerHTML = "<p>載入測驗失敗，請稍後再試！</p>";
    }
  }

  loadQuizzes();
});
