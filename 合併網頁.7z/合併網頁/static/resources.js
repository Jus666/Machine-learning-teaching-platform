document.addEventListener('DOMContentLoaded', () => {
    const courseId = document.getElementById('course-id').value;
    const currentUserId = document.getElementById('user-id').value;
    const uploadFileBtn = document.getElementById('upload-file-btn');
    const viewFilesBtn = document.getElementById('view-files-btn');
    const uploadSection = document.querySelector('.upload-section');
    const fileListSection = document.querySelector('.file-list-section');
    const uploadForm = document.getElementById('upload-form');
    const viewFilesFromUploadBtn = document.getElementById('view-files-from-upload-btn');
    const fileList = document.getElementById('file-list');
    const categoryList = document.getElementById('category-list');
    const categoryTitle = document.getElementById('category-title');
    const uploadCategorySelect = document.getElementById('upload-category');

    let allResources = [];   // 儲存從後端取得的所有資源資料
    let currentCategory = "all"; // 預設顯示全部

    // 切換至上傳區
    uploadFileBtn.addEventListener('click', () => {
        uploadSection.style.display = 'block';
        fileListSection.style.display = 'none';
    });

    // 切換至資源列表區
    viewFilesBtn.addEventListener('click', () => {
        uploadSection.style.display = 'none';
        fileListSection.style.display = 'block';
        loadResources();
    });

    // 從上傳區也可點選「查看文件列表」
    viewFilesFromUploadBtn.addEventListener('click', () => {
        uploadSection.style.display = 'none';
        fileListSection.style.display = 'block';
        loadResources();
    });

    // 上傳表單送出（加入分類選擇）
    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fileInput = document.getElementById('file-input');
        if (fileInput.files.length === 0) {
            alert('請選擇檔案');
            return;
        }
        const file = fileInput.files[0];
        const selectedCategory = uploadCategorySelect.value;
        const formData = new FormData();
        formData.append('course_id', courseId);
        formData.append('user_id', currentUserId);
        formData.append('file', file);
        formData.append('category', selectedCategory);

        try {
            const res = await fetch('/upload-resource', {
                method: 'POST',
                body: formData
            });
            if (res.ok) {
                alert('上傳成功！');
                fileInput.value = "";
                loadResources();
            } else {
                alert('上傳失敗，請稍後再試。');
            }
        } catch (error) {
            console.error(error);
            alert('上傳失敗，請稍後再試。');
        }
    });

    // 取得資源清單
    async function loadResources() {
        fileList.innerHTML = '載入中...';
        try {
            const res = await fetch(`/list-resources?courseId=${courseId}`);
            if (!res.ok) {
                fileList.innerHTML = '載入失敗。';
                return;
            }
            const data = await res.json();
            allResources = data;
            displayResources();
        } catch (error) {
            console.error(error);
            fileList.innerHTML = '載入失敗。';
        }
    }

    // 根據目前所選分類過濾並顯示資源
    function displayResources() {
        let filtered = allResources;
        if (currentCategory !== "all") {
            filtered = allResources.filter(item => item.category === currentCategory);
        }
        fileList.innerHTML = '';
        if (filtered.length === 0) {
            fileList.innerHTML = '<li>目前無資料</li>';
            return;
        }
        filtered.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.resource_name} (${item.resource_type}) - 分類：${item.category}`;
            
            // 檢視按鈕
            const viewBtn = document.createElement('button');
            viewBtn.textContent = '檢視';
            viewBtn.style.marginLeft = '10px';
            viewBtn.addEventListener('click', () => {
                window.open(`/view-resource/${item.id}`, '_blank');
            });
            li.appendChild(viewBtn);
            
            // 下載按鈕
            const downloadBtn = document.createElement('button');
            downloadBtn.textContent = '下載';
            downloadBtn.style.marginLeft = '10px';
            downloadBtn.addEventListener('click', () => {
                window.location.href = `/download-resource/${item.id}`;
            });
            li.appendChild(downloadBtn);
            
            // 如果是本人上傳，加入刪除與編輯分類按鈕
            if (item.user_id == currentUserId) {
                const deleteBtn = document.createElement('button');
                deleteBtn.textContent = '刪除';
                deleteBtn.style.marginLeft = '10px';
                deleteBtn.addEventListener('click', () => {
                    if (confirm('確定要刪除這筆資源嗎？')) {
                        deleteResource(item.id);
                    }
                });
                li.appendChild(deleteBtn);
                
                const editBtn = document.createElement('button');
                editBtn.textContent = '編輯分類';
                editBtn.style.marginLeft = '10px';
                editBtn.addEventListener('click', () => {
                    // 建立下拉選單
                    const select = document.createElement('select');
                    const options = [
                        { value: 'recommended', label: '推薦' },
                        { value: 'documents', label: '資料集' },
                        { value: 'images', label: '教材' },
                        { value: 'videos', label: '程式碼' },
                        { value: 'others', label: '其他' }
                    ];
                    options.forEach(opt => {
                        const option = document.createElement('option');
                        option.value = opt.value;
                        option.textContent = opt.label;
                        if (item.category === opt.value) {
                            option.selected = true;
                        }
                        select.appendChild(option);
                    });
                    // 建立確定與取消按鈕
                    const confirmBtn = document.createElement('button');
                    confirmBtn.textContent = '確定';
                    confirmBtn.style.marginLeft = '5px';
                    const cancelBtn = document.createElement('button');
                    cancelBtn.textContent = '取消';
                    cancelBtn.style.marginLeft = '5px';

                    // 當使用者點選確定，呼叫更新 API
                    confirmBtn.addEventListener('click', () => {
                        const newCategory = select.value;
                        updateResourceCategory(item.id, newCategory);
                        li.removeChild(select);
                        li.removeChild(confirmBtn);
                        li.removeChild(cancelBtn);
                    });
                    // 取消則直接移除下拉與按鈕
                    cancelBtn.addEventListener('click', () => {
                        li.removeChild(select);
                        li.removeChild(confirmBtn);
                        li.removeChild(cancelBtn);
                    });

                    li.appendChild(select);
                    li.appendChild(confirmBtn);
                    li.appendChild(cancelBtn);
                });
                li.appendChild(editBtn);
            }
            fileList.appendChild(li);
        });
    }

    // 刪除資源 API
    async function deleteResource(resourceId) {
        try {
            const res = await fetch('/delete-resource', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    resource_id: resourceId,
                    user_id: currentUserId
                })
            });
            if (res.ok) {
                alert('刪除成功！');
                loadResources();
            } else {
                alert('刪除失敗，請稍後再試。');
            }
        } catch (error) {
            console.error(error);
            alert('刪除失敗，請稍後再試。');
        }
    }

    // 更新資源分類 API
    async function updateResourceCategory(resourceId, newCategory) {
        try {
            const res = await fetch('/update-resource-category', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    resource_id: resourceId,
                    new_category: newCategory,
                    user_id: currentUserId
                })
            });
            if (res.ok) {
                alert('更新分類成功！');
                loadResources();
            } else {
                alert('更新分類失敗，請稍後再試。');
            }
        } catch (error) {
            console.error(error);
            alert('更新分類失敗，請稍後再試。');
        }
    }

    // 左側分類清單點擊事件
    categoryList.querySelectorAll('.category-item').forEach(li => {
        li.addEventListener('click', () => {
            categoryList.querySelectorAll('.category-item').forEach(item => item.classList.remove('selected'));
            li.classList.add('selected');
            currentCategory = li.getAttribute('data-category');
            categoryTitle.textContent = li.textContent;
            displayResources();
        });
    });

    // 新增分類 (以選單形式供後續參考，不影響上傳檔案用的選單)
    document.getElementById('add-category-btn').addEventListener('click', function() {
        const newCategory = document.getElementById('custom-category').value.trim();
        if (newCategory) {
            // 此處僅在左側分類列表新增一個分類項目
            const li = document.createElement('li');
            li.className = 'category-item new-category';
            li.setAttribute('data-category', newCategory);
            li.textContent = newCategory;
            // 加入刪除按鈕以便移除該分類
            const delBtn = document.createElement('button');
            delBtn.textContent = '刪除';
            delBtn.style.marginLeft = '5px';
            delBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                li.remove();
            });
            li.appendChild(delBtn);
            categoryList.appendChild(li);
            document.getElementById('custom-category').value = '';
        }
    });
});
