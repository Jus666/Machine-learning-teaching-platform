document.addEventListener("DOMContentLoaded", () => {
  // DOM 節點
  const scoreItemsTableBody = document.querySelector("#score-items-table tbody");
  const updateScoreItemsBtn = document.getElementById("update-score-items-btn");
  const addScoreItemForm = document.getElementById("add-score-item-form");
  
  const studentScoresTableHead = document.querySelector("#student-scores-table thead tr");
  const studentScoresTableBody = document.querySelector("#student-scores-table tbody");
  
  // 暫存計分項目資料
  let scoreItemsData = [];
  
  // 初始化：載入計分項目與學生成績
  init();
  
  async function init() {
      if (!courseId) {
          alert("缺少 course_id 參數");
          return;
      }
      await loadScoreItems();
      await loadStudentScores();
  }
  
  // 1. 載入計分項目
  async function loadScoreItems() {
      try {
          const res = await fetch(`/get_score_items?course_id=${courseId}`);
          if (!res.ok) throw new Error("無法取得計分項目資料");
          scoreItemsData = await res.json();
          renderScoreItems(scoreItemsData);
      } catch (err) {
          console.error("載入計分項目錯誤:", err);
      }
  }
  
  // 2. 渲染計分項目表格
  function renderScoreItems(items) {
      scoreItemsTableBody.innerHTML = "";
      items.forEach(item => {
          const tr = document.createElement("tr");
          tr.innerHTML = `
              <td>${item.name}</td>
              <td>
                  <input type="number" class="item-percentage" data-item-id="${item.id}" value="${item.percentage}" min="0" max="100">
              </td>
              <td>
                  <span>${item.type}</span>
              </td>
              <td>
                  <button class="delete-item-btn" data-item-id="${item.id}">刪除</button>
              </td>
          `;
          scoreItemsTableBody.appendChild(tr);
      });
  }
  
  // 3. 更新計分項目設定（僅更新百分比）
  updateScoreItemsBtn.addEventListener("click", async () => {
      const inputs = document.querySelectorAll(".item-percentage");
      const updates = [];
      inputs.forEach(input => {
          const itemId = input.dataset.itemId;
          const percentage = Number(input.value);
          updates.push({ id: itemId, percentage });
      });
      try {
          const res = await fetch("/update_score_items", {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ course_id: courseId, updates })
          });
          if (!res.ok) throw new Error("更新失敗");
          alert("更新成功");
          await loadScoreItems();
          await loadStudentScores();
      } catch (err) {
          console.error("更新計分項目錯誤:", err);
          alert("更新失敗，請稍後再試");
      }
  });
  
  // 4. 新增計分項目
  addScoreItemForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const name = document.getElementById("new-item-name").value.trim();
      const percentage = Number(document.getElementById("new-item-percentage").value);
      const type = document.getElementById("new-item-type").value;
      try {
          const res = await fetch("/add_score_item", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ course_id: courseId, name, percentage, type })
          });
          if (!res.ok) throw new Error("新增項目失敗");
          alert("新增成功");
          addScoreItemForm.reset();
          await loadScoreItems();
          await loadStudentScores();
      } catch (err) {
          console.error("新增計分項目錯誤:", err);
          alert("新增失敗，請稍後再試");
      }
  });
  
  // 5. 刪除計分項目
  scoreItemsTableBody.addEventListener("click", async (e) => {
      if (e.target.classList.contains("delete-item-btn")) {
          const itemId = e.target.dataset.itemId;
          if (!confirm("確定要刪除此計分項目嗎？")) return;
          try {
              const res = await fetch(`/delete_score_item/${itemId}?course_id=${courseId}`, {
                  method: "DELETE"
              });
              if (!res.ok) throw new Error("刪除失敗");
              alert("刪除成功");
              await loadScoreItems();
              await loadStudentScores();
          } catch (err) {
              console.error("刪除計分項目錯誤:", err);
              alert("刪除失敗，請稍後再試");
          }
      }
  });
  
  // 6. 載入學生成績
  async function loadStudentScores() {
      try {
          const res = await fetch(`/get_student_scores?course_id=${courseId}`);
          if (!res.ok) throw new Error("無法取得學生成績");
          const data = await res.json();
          renderStudentScores(data);
      } catch (err) {
          console.error("載入學生成績錯誤:", err);
      }
  }
  
  // 7. 渲染學生成績表格
  function renderStudentScores(studentsData) {
      // 建立表頭：學生姓名，再依照計分項目插入欄位，最後加上總分欄
      studentScoresTableHead.innerHTML = `<th>學生姓名</th>`;
      scoreItemsData.forEach(item => {
          const th = document.createElement("th");
          th.textContent = item.name;
          studentScoresTableHead.appendChild(th);
      });
      studentScoresTableHead.innerHTML += `<th>總分</th>`;
      
      // 填入學生資料
      studentScoresTableBody.innerHTML = "";
      studentsData.forEach(student => {
          let rowHtml = `<td>${student.full_name}</td>`;
          scoreItemsData.forEach(item => {
              const score = student.scores[item.id] || 0;
              rowHtml += `<td>${score}</td>`;
          });
          rowHtml += `<td>${student.total_score}</td>`;
          const tr = document.createElement("tr");
          tr.innerHTML = rowHtml;
          studentScoresTableBody.appendChild(tr);
      });
  }
  
  // 8. 返回課程管理（依實際路由調整）
  document.getElementById("back-to-course-btn").addEventListener("click", () => {
      window.location.href = "/teacher-course";
  });
});
