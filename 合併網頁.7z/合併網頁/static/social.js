// 取得好友列表
async function fetchFriendsList() {
    console.log("Fetching friends list...");
    try {
        const response = await fetch('/get_friends_list');
        const data = await response.json();
        console.log('Friends List:', data);

        if (Array.isArray(data) && data.length > 0) {
            data.forEach(friend => displayFriend(friend));
        } else {
            console.log('No friends found');
            const friendList = document.getElementById('friend-list');
            if (friendList) friendList.innerHTML = '<p>目前沒有好友</p>';
        }
    } catch (error) {
        console.error('Error fetching friends list:', error);
    }
}

// 顯示好友列表
function displayFriend(friend) {
    const friendList = document.getElementById('friends-list');
    if (!friendList) {
        console.error('Friend list element not found');
        return;
    }
    const friendItem = document.createElement('li');
    friendItem.textContent = friend.full_name;  // 顯示 full_name 而不是 username

    const chatButton = document.createElement('button');
    chatButton.textContent = '聊天';
    chatButton.addEventListener('click', () => openChatWindow(friend.username));

    friendItem.appendChild(chatButton);
    friendList.appendChild(friendItem);
}


function openChatWindow(friendUsername) {
    const chatWindow = document.getElementById('chat-window');
    const chatFriendName = document.getElementById('chat-friend-name');
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    
    chatFriendName.textContent = `正在與 ${friendUsername} 聊天`;
    chatMessages.innerHTML = ''; // 清空之前的訊息
    chatWindow.style.display = 'block';

    // 假設在載入聊天視窗時從 session 或伺服器獲取登入的使用者名稱
    fetch('/get_current_user')
        .then(response => response.json())
        .then(data => {
            window.currentUser = data.username;  // 將目前使用者儲存在全域變數中

            // 載入聊天記錄
            return fetch(`/get_chat_messages?friend_username=${friendUsername}`);
        })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            if (data.messages) {
                data.messages.forEach(message => {
                    displayChatMessage(message, chatMessages);
                });
            } else {
                console.log('No chat messages found');
            }
        })
        .catch(error => console.error('Error fetching chat messages:', error));

    // 監聽發送訊息按鈕
    document.getElementById('send-chat-btn').onclick = () => {
        const message = chatInput.value.trim();
        if (message) {
            sendMessage(friendUsername, message);
            chatInput.value = '';
        }
    };
}

// 顯示聊天訊息
function displayChatMessage(message, chatMessages) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('chat-message');

    // 如果訊息的使用者名稱是當前登入者，顯示 "我"
    const displayName = message.sender === window.currentUser ? "我" : message.sender;
    
    messageElement.innerHTML = `<strong>${displayName}</strong>: ${message.text}`;
    chatMessages.appendChild(messageElement);
}

// 假設 sendMessage 是發送訊息的函數
function sendMessage(friendUsername, message) {
    fetch('/send_chat_message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ friend_username: friendUsername, message: message })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            console.log('Message sent successfully');
        } else {
            console.error('Error sending message:', data);
        }
    })
    .catch(error => console.error('Error sending message:', error));
}

// 顯示聊天訊息的函數
function displayChatMessage(message, chatMessages) {
    const messageElement = document.createElement('div');
    messageElement.classList.add('chat-message');

    // 設定訊息的樣式和內容
    const sender = document.createElement('strong');
    sender.textContent = `${message.sender_username}: `;
    const text = document.createElement('span');
    text.textContent = message.message;
    const timestamp = document.createElement('em');
    timestamp.textContent = ` (${new Date(message.created_at).toLocaleTimeString()})`;

    messageElement.appendChild(sender);
    messageElement.appendChild(text);
    messageElement.appendChild(timestamp);

    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight; // 自動滾動至最新訊息
}

// 發送訊息到後端
function sendMessage(friendUsername, message) {
    fetch('/send_chat_message', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ friend_username: friendUsername, message })
    })
    .then(response => {
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return response.json();
    })
    .then(result => {
        if (result.status === 'success') {
            // 成功發送訊息後顯示
            displayChatMessage({
                sender_username: '我', // 顯示為自己的名稱
                message: message,
                created_at: new Date().toISOString()
            }, document.getElementById('chat-messages'));
        } else {
            console.error('Error sending message:', result);
        }
    })
    .catch(error => console.error('Error sending message:', error));
}

// 搜尋使用者
async function searchUser(name) {
    try {
        const response = await fetch(`/search_user?name=${name}`);
        const data = await response.json();
        console.log('Search Results:', data);

        if (Array.isArray(data) && data.length > 0) {
            data.forEach(user => displaySearchResult(user));
        } else {
            console.log('No users found for search query');
            const searchResults = document.getElementById('search-results');
            if (searchResults) searchResults.innerHTML = '<p>找不到該用戶</p>';
        }
    } catch (error) {
        console.error('Error fetching search results:', error);
    }
}

// 顯示搜尋結果
function displaySearchResult(user) {
    const searchResults = document.getElementById('search-results');
    if (!searchResults) {
        console.error('Search results element not found');
        return;
    }
    const userItem = document.createElement('li');
    userItem.textContent = user.full_name;

    const addButton = document.createElement('button');
    addButton.textContent = '添加好友';
    addButton.addEventListener('click', () => sendFriendRequest(user.username));

    userItem.appendChild(addButton);
    searchResults.appendChild(userItem);
}

async function sendFriendRequest(friendUsername) {
    try {
        const response = await fetch('/send_friend_request', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ friend_username: friendUsername })
        });

        const result = await response.json();
        console.log('Friend Request Result:', result);

        if (response.ok) {
            alert(result.message);
        } else {
            alert(result.message || '發送好友請求時出現錯誤');
            console.error('Error sending friend request:', result);
        }
    } catch (error) {
        console.error('Error sending friend request:', error);
    }
}

// 取得好友請求列表
async function fetchFriendRequests() {
    console.log("Fetching friend requests...");
    try {
        const response = await fetch('/get_friend_requests');
        const data = await response.json();
        console.log('Friend Requests:', data);

        if (Array.isArray(data) && data.length > 0) {
            data.forEach(request => displayFriendRequest(request));
        } else {
            console.log('No friend requests found');
            const requestList = document.getElementById('friend-requests-list');
            if (requestList) requestList.innerHTML = '<p>目前沒有好友請求</p>';
        }
    } catch (error) {
        console.error('Error fetching friend requests:', error);
    }
}

function displayFriendRequest(request) {
    const requestList = document.getElementById('friend-requests-list');
    if (!requestList) {
        console.error('Friend requests element not found');
        return;
    }
    const requestItem = document.createElement('li');
    requestItem.textContent = request.full_name;  // 顯示 full_name 而不是 username

    const acceptButton = document.createElement('button');
    acceptButton.textContent = '同意';
    acceptButton.addEventListener('click', () => handleFriendRequest(request.user_username, 'accept'));

    const declineButton = document.createElement('button');
    declineButton.textContent = '拒絕';
    declineButton.addEventListener('click', () => handleFriendRequest(request.user_username, 'decline'));

    requestItem.appendChild(acceptButton);
    requestItem.appendChild(declineButton);
    requestList.appendChild(requestItem);
}

// 處理好友請求
async function handleFriendRequest(username, action) {
    try {
        const response = await fetch('/handle_friend_request', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ friend_username: username, action })
        });

        const result = await response.json();
        console.log(`Friend Request ${action}:`, result);

        if (result.status === 'success') {
            alert(`已${action === 'accept' ? '接受' : '拒絕'}好友請求 ${username}`);
            fetchFriendRequests();
            fetchFriendsList();
        } else {
            console.error(`Error ${action}ing friend request:`, result);
        }
    } catch (error) {
        console.error(`Error ${action}ing friend request:`, error);
    }
}

// 初始化，調用函數來顯示當前的好友列表和好友請求
fetchFriendsList();
fetchFriendRequests();

// 搜尋使用者事件監聽
const searchBtn = document.getElementById('search-btn');
if (searchBtn) {
    searchBtn.addEventListener('click', () => {
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            const searchQuery = searchInput.value.trim();
            if (searchQuery) {
                searchUser(searchQuery);
            } else {
                console.log("請輸入搜尋名稱。");
            }
        } else {
            console.error('Search input element not found');
        }
    });
}
