document.addEventListener("DOMContentLoaded", async () => {
    console.log("學生公告頁面初始化");
    // 從 URL 取得 course_id（若有）
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get("course_id");
  
    async function loadAnnouncements() {
      try {
        const response = await fetch(`/get_announcements/${courseId}`);
        if (!response.ok) throw new Error("無法載入公告");
        const announcements = await response.json();
        const announcementListElem = document.getElementById("announcement-list");
        announcementListElem.innerHTML = "";
        if (announcements.length === 0) {
          announcementListElem.innerHTML = "<p>目前沒有公告。</p>";
          return;
        }
        announcements.forEach((announcement) => {
          const li = document.createElement("li");
          // 假設公告有 title 與 content 欄位（若無，可自行修改）
          li.innerHTML = `<strong>${announcement.title || "公告"}</strong><br>${announcement.content}`;
          announcementListElem.appendChild(li);
        });
      } catch (error) {
        console.error("加載公告時發生錯誤：", error);
        alert("載入公告失敗，請稍後再試！");
      }
    }
  
    loadAnnouncements();
  });
  