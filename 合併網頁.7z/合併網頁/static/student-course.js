document.addEventListener("DOMContentLoaded", async () => {
    console.log("學生課程管理初始化");
  
    // 載入已加入課程與可加入課程
    loadJoinedCourses();
    loadAvailableCourses();
  
    // 載入已加入課程列表
    async function loadJoinedCourses() {
      try {
        const response = await fetch("/get_joined_courses");
        if (!response.ok) throw new Error("無法加載已加入課程");
        const courses = await response.json();
        const container = document.getElementById("joined-courses-container");
        container.innerHTML = "";
        if (courses.length === 0) {
          container.innerHTML = "<p>目前未加入任何課程。</p>";
          return;
        }
        courses.forEach((course) => {
          const courseCard = document.createElement("div");
          courseCard.classList.add("course-card");
          courseCard.innerHTML = `
            <h3>${course.course_name}</h3>
            <button onclick="window.location.href='student-materials.html?course_id=${course.id}'">教材</button>
            <button onclick="window.location.href='student-homeworks.html?course_id=${course.id}'">作業</button>
            <button onclick="window.location.href='student-announcements.html?course_id=${course.id}'">公告</button>
            <button onclick="window.location.href='student-quizzes.html?course_id=${course.id}'">測驗</button>
          `;
          container.appendChild(courseCard);
        });
      } catch (error) {
        console.error("載入已加入課程時發生錯誤：", error);
      }
    }
  
    // 載入可加入的課程列表
    async function loadAvailableCourses() {
      try {
        const response = await fetch("/get_courses");
        if (!response.ok) throw new Error("無法加載可加入的課程");
        const courses = await response.json();
        const selectElement = document.getElementById("available-courses");
        selectElement.innerHTML = '<option value="" disabled selected>請選擇課程</option>';
        courses.forEach((course) => {
          const option = document.createElement("option");
          option.value = course.id;
          option.textContent = course.course_name;
          selectElement.appendChild(option);
        });
      } catch (error) {
        console.error("載入可加入課程時發生錯誤：", error);
      }
    }
  
    // 申請加入課程
    document.getElementById("apply-course-form").addEventListener("submit", async (event) => {
      event.preventDefault();
      const selectElement = document.getElementById("available-courses");
      const selectedCourseId = selectElement.value;
      if (!selectedCourseId) {
        alert("請選擇課程！");
        return;
      }
      try {
        const response = await fetch("/apply_course", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ course_id: selectedCourseId })
        });
        if (response.ok) {
          alert("申請加入課程成功！");
          // 重新載入可加入與已加入課程列表
          loadAvailableCourses();
          loadJoinedCourses();
        } else {
          const errorData = await response.json();
          alert(`申請失敗：${errorData.error}`);
        }
      } catch (error) {
        console.error("申請加入課程時發生錯誤：", error);
        alert("申請加入課程時發生錯誤，請稍後重試！");
      }
    });
  });
  