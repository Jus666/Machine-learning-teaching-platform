document.addEventListener("DOMContentLoaded", async () => {
    console.log("學生作業頁面初始化");
    // 從 URL 取得 course_id（若有需要）
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get("course_id");
  
    // 載入老師指派的作業
    async function loadHomeworks() {
      try {
        const response = await fetch(`/get_homeworks/${courseId}`);
        if (!response.ok) throw new Error("無法載入作業");
        const homeworks = await response.json();
        const homeworkListElem = document.getElementById("homework-list");
        homeworkListElem.innerHTML = "";
        if (homeworks.length === 0) {
          homeworkListElem.innerHTML = "<p>目前沒有作業。</p>";
          return;
        }
        homeworks.forEach((hw) => {
          const li = document.createElement("li");
          li.innerHTML = `<strong>${hw.title}</strong><br>${hw.description}`;
          // 繳交按鈕（開啟彈窗）
          const submitBtn = document.createElement("button");
          submitBtn.textContent = "繳交作業";
          submitBtn.addEventListener("click", () => {
            openSubmitModal(hw.homework_id, hw.title);
          });
          li.appendChild(submitBtn);
          homeworkListElem.appendChild(li);
        });
      } catch (error) {
        console.error("載入作業時發生錯誤：", error);
        alert("載入作業失敗，請稍後再試！");
      }
    }
  
    // 載入學生已繳交作業紀錄
    async function loadSubmittedHomeworks() {
      try {
        const response = await fetch(`/get_my_submissions/${courseId}`);
        if (!response.ok) throw new Error("無法載入繳交紀錄");
        const submissions = await response.json();
        const submittedList = document.getElementById("submitted-homework-list");
        submittedList.innerHTML = "";
        if (submissions.length === 0) {
          submittedList.innerHTML = "<p>目前沒有繳交紀錄。</p>";
          return;
        }
        submissions.forEach((sub) => {
          const li = document.createElement("li");
          li.innerHTML = `
            <strong>作業:</strong> ${sub.homework_title}<br>
            <strong>繳交時間:</strong> ${sub.submitted_at}<br>
            <strong>得分:</strong> ${sub.score !== null ? sub.score : "未評分"}<br>
            <strong>評語:</strong> ${sub.feedback || "無評語"}<br>
          `;
          // 下載連結
          const downloadLink = document.createElement("a");
          downloadLink.href = `/uploads/${sub.file_path}`;
          downloadLink.textContent = "下載作業";
          downloadLink.target = "_blank";
          li.appendChild(downloadLink);
          // 檢視按鈕（開啟新視窗）
          const viewBtn = document.createElement("button");
          viewBtn.textContent = "檢視作業";
          viewBtn.addEventListener("click", () => {
            window.open(`/uploads/${sub.file_path}`, "_blank");
          });
          li.appendChild(viewBtn);
          submittedList.appendChild(li);
        });
      } catch (error) {
        console.error("載入繳交紀錄時發生錯誤：", error);
        alert("載入繳交紀錄失敗，請稍後再試！");
      }
    }
  
    // 繳交作業彈窗處理
    function openSubmitModal(homeworkId, homeworkTitle) {
      const modal = document.getElementById("submit-homework-modal");
      modal.style.display = "block";
      document.getElementById("selected-homework").textContent = `繳交作業: ${homeworkTitle}`;
      document.getElementById("submit-homework-form").dataset.homeworkId = homeworkId;
    }
  
    document.getElementById("cancel-submit").addEventListener("click", () => {
      document.getElementById("submit-homework-modal").style.display = "none";
    });
  
    // 繳交作業表單提交
    document.getElementById("submit-homework-form").addEventListener("submit", async (event) => {
      event.preventDefault();
      const homeworkId = event.target.dataset.homeworkId;
      const homeworkFile = document.getElementById("homework-file").files[0];
      if (!homeworkId) {
        alert("未選擇作業，請重新選擇！");
        return;
      }
      if (!homeworkFile) {
        alert("請上傳作業文件！");
        return;
      }
      const formData = new FormData();
      formData.append("homework_id", homeworkId);
      formData.append("file", homeworkFile);
      try {
        const response = await fetch("/submit_homework", {
          method: "POST",
          body: formData,
        });
        if (response.ok) {
          alert("作業繳交成功！");
          document.getElementById("submit-homework-form").reset();
          document.getElementById("submit-homework-modal").style.display = "none";
          loadSubmittedHomeworks();
        } else {
          const errorData = await response.json();
          alert(`作業繳交失敗：${errorData.error || "未知錯誤"}`);
        }
      } catch (error) {
        console.error("作業繳交時發生錯誤：", error);
        alert("作業繳交時發生錯誤，請檢查網絡連接並重試！");
      }
    });
  
    // 初始載入
    loadHomeworks();
    loadSubmittedHomeworks();
  });
  