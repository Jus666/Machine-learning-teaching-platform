document.addEventListener("DOMContentLoaded", async () => {
    console.log("學生教材頁面初始化");
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get("course_id");
  
    async function loadMaterials() {
      try {
        // 修改 fetch URL 與後端路由一致
        const response = await fetch(`/get_course_materials/${courseId}`);
        if (!response.ok) throw new Error("無法載入教材");
        const materials = await response.json();
        const container = document.getElementById("materials-list");
        container.innerHTML = "";
        if (materials.length === 0) {
          container.innerHTML = "<p>目前沒有教材。</p>";
          return;
        }
        materials.forEach((material) => {
          const item = document.createElement("div");
          item.classList.add("material-item");
          item.innerHTML = `<p><strong>${material.original_filename}</strong> (${material.uploaded_at})</p>`;
          const downloadLink = document.createElement("a");
          downloadLink.href = `/static/materials/${material.filename}`;
          downloadLink.textContent = "下載";
          downloadLink.target = "_blank";
          item.appendChild(downloadLink);
          container.appendChild(item);
        });
      } catch (error) {
        console.error("載入教材時發生錯誤：", error);
        alert("載入教材失敗，請稍後再試！");
      }
    }
  
    loadMaterials();
});
