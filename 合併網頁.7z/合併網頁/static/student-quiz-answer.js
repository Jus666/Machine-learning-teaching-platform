document.addEventListener("DOMContentLoaded", async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const quizId = urlParams.get("quiz_id");
  const courseId = urlParams.get("course_id");
  const quizNameElem = document.getElementById("quiz-name");
  const quizDescriptionElem = document.getElementById("quiz-description");
  const questionsContainer = document.getElementById("questions-container");
  const quizAnswerForm = document.getElementById("quiz-answer-form");

  let quizData = null;

  async function loadQuiz() {
    try {
      const response = await fetch(`/student/quiz?quiz_id=${quizId}`);
      if (!response.ok) throw new Error("Failed to load quiz");
      quizData = await response.json();
      quizNameElem.textContent = quizData.name;
      quizDescriptionElem.textContent = quizData.description;
      renderQuestions();
    } catch (error) {
      console.error(error);
      questionsContainer.innerHTML = "<p>載入測驗失敗，請稍後再試。</p>";
    }
  }

  function renderQuestions() {
    questionsContainer.innerHTML = "";
    quizData.questions.forEach((q, index) => {
      const div = document.createElement("div");
      div.style.borderBottom = "1px solid #ccc";
      div.style.padding = "10px";
      div.innerHTML = `<strong>${index + 1}. ${q.question_text}</strong> (分數: ${q.score})<br>`;
      if (q.question_type === "multiple_choice" && q.options) {
        q.options.forEach(opt => {
          const label = document.createElement("label");
          const radio = document.createElement("input");
          radio.type = "radio";
          radio.name = `question_${q.question_id}`;
          radio.value = opt.id; // 假設選項的 id 為 opt.id
          label.appendChild(radio);
          label.appendChild(document.createTextNode(opt.option_text));
          div.appendChild(label);
          div.appendChild(document.createElement("br"));
        });
      }
      questionsContainer.appendChild(div);
    });
  }

  quizAnswerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const answers = [];
    quizData.questions.forEach(q => {
      const selected = document.querySelector(`input[name="question_${q.question_id}"]:checked`);
      if (selected) {
        answers.push({
          question_id: q.question_id,
          chosen_option: parseInt(selected.value, 10)
        });
      }
    });
    if (answers.length !== quizData.questions.length) {
      alert("請回答所有題目");
      return;
    }
    try {
      const response = await fetch("/student/quiz_submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quiz_id: quizId,
          answers: answers
        })
      });
      if (response.ok) {
        const result = await response.json();
        alert("作答完成，總分：" + result.total_score);
        window.location.href = `student-quiz-view.html?quiz_id=${quizId}&course_id=${courseId}`;
      } else {
        const errorData = await response.json();
        alert("提交答案失敗：" + errorData.error);
      }
    } catch (error) {
      console.error("提交答案時發生錯誤", error);
      alert("提交答案失敗，請稍後再試！");
    }
  });

  loadQuiz();
});
