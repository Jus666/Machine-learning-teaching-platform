document.addEventListener("DOMContentLoaded", async () => {
  // 從 URL 參數取得 quiz_id 與 course_id
  const urlParams = new URLSearchParams(window.location.search);
  const quizId = urlParams.get("quiz_id");
  const courseId = urlParams.get("course_id");

  const quizNameElem = document.getElementById("quiz-name");
  const quizDescriptionElem = document.getElementById("quiz-description");
  const questionsContainer = document.getElementById("questions-container");

  // 載入測驗資料並動態生成題目內容
  async function loadQuiz() {
    try {
      const response = await fetch(`/student/quiz?quiz_id=${quizId}`);
      if (!response.ok) throw new Error("Failed to load quiz");
      const quiz = await response.json();
      quizNameElem.textContent = quiz.name;
      quizDescriptionElem.textContent = quiz.description;
      questionsContainer.innerHTML = "";

      // 對每一題動態生成顯示區塊
      quiz.questions.forEach((q, index) => {
        const div = document.createElement("div");
        div.style.borderBottom = "1px solid #ccc";
        div.style.padding = "10px";

        // 顯示題目文字與分數
        div.innerHTML = `<strong>${index + 1}. ${q.question_text}</strong> (分數: ${q.score})<br>`;

        // 如果是選擇題，列出所有選項
        if (q.question_type === "multiple_choice" && q.options) {
          const ul = document.createElement("ul");
          q.options.forEach((opt) => {
            const li = document.createElement("li");
            li.textContent = opt.option_text + (opt.is_correct ? " (正確)" : "");
            // 如果有學生答案，並且此選項為學生所選
            if (quiz.attempt && q.student_answer !== undefined) {
              if (opt.id === q.student_answer) {
                li.style.fontWeight = "bold";
                li.textContent += " <-- 你的答案";
              }
            }
            ul.appendChild(li);
          });
          div.appendChild(ul);
        }

        // 新增「AI解析」按鈕
        const aiButton = document.createElement("button");
        aiButton.textContent = "AI解析";
        aiButton.style.marginTop = "10px";
        aiButton.addEventListener("click", function () {
          // 取得正確答案（針對選擇題，將所有正確選項合併）
          let correctAnswer = "";
          if (q.question_type === "multiple_choice" && q.options) {
            q.options.forEach((opt) => {
              if (opt.is_correct) {
                correctAnswer += opt.option_text + "; ";
              }
            });
          }
          // 取得學生答案（針對選擇題）
          let studentAnswer = "";
          if (quiz.attempt && q.student_answer !== undefined) {
            if (q.question_type === "multiple_choice" && q.options) {
              q.options.forEach((opt) => {
                if (opt.id === q.student_answer) {
                  studentAnswer = opt.option_text;
                }
              });
            }
          }
          // 呼叫函數，請求 AI 解析該題目
          requestAIExplanation(q.question_text, correctAnswer, studentAnswer, div);
        });
        div.appendChild(aiButton);

        // 在題目區塊下新增一個空的解析結果容器
        const explanationContainer = document.createElement("div");
        explanationContainer.classList.add("ai-explanation");
        explanationContainer.style.marginTop = "5px";
        div.appendChild(explanationContainer);

        questionsContainer.appendChild(div);
      });
    } catch (error) {
      console.error(error);
      questionsContainer.innerHTML = "<p>載入測驗失敗，請稍後再試。</p>";
    }
  }

  // 請求 AI 解析題目，並更新指定題目的解析結果
  async function requestAIExplanation(questionText, correctAnswer, studentAnswer, containerElement) {
    // 找到剛剛在題目區塊中新增的解析結果容器
    const explanationContainer = containerElement.querySelector(".ai-explanation");
    // 先顯示「AI解析中...」提示
    explanationContainer.textContent = "AI解析中...";

    // 準備傳送給後端的資料
    const payload = {
      question: questionText,
      correct_answer: correctAnswer,
      student_answer: studentAnswer
    };

    try {
      const response = await fetch("/ai_explanation", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        throw new Error("AI解析失敗，請稍後再試");
      }
      const data = await response.json();
      // 假設後端回傳的解析內容存放在 data.explanation（請根據實際情況調整）
      explanationContainer.textContent = data.explanation;
    } catch (error) {
      console.error("AI解析錯誤:", error);
      explanationContainer.textContent = "[解析失敗]";
    }
  }

  loadQuiz();

  // 其他按鈕功能（清除記憶、返回主選單）保持不變
  document.getElementById("clear-history-btn").addEventListener("click", function () {
    fetch("/clear_history", {
      method: "POST",
    })
      .then(response => {
        if (response.ok) {
          document.getElementById("llm-response").innerHTML = "";
          alert("記憶已清除！");
        } else {
          alert("無法清除記憶，請稍後再試。");
        }
      })
      .catch(error => {
        console.error("Error:", error);
        alert("請求出錯，請稍後再試。");
      });
  });

  document.getElementById("back-to-menu-btn").addEventListener("click", function () {
    window.location.href = "/home";
  });
});
