document.addEventListener("DOMContentLoaded", async () => {
  const urlParams = new URLSearchParams(window.location.search);
  const courseId = urlParams.get("course_id");
  const quizzesContainer = document.getElementById("quizzes-container");
  
  async function loadQuizzes() {
    try {
      const response = await fetch(`/student/quizzes?course_id=${courseId}`);
      if (!response.ok) throw new Error("Failed to load quizzes");
      const quizzes = await response.json();
      quizzesContainer.innerHTML = "";
      quizzes.forEach(q => {
        const div = document.createElement("div");
        div.style.border = "1px solid #ccc";
        div.style.padding = "10px";
        div.style.marginBottom = "10px";
        div.innerHTML = `<h2>${q.name}</h2><p>${q.description}</p>`;
        if (q.completed) {
          div.innerHTML += `<p style="color: green;">已完成</p>`;
          const viewBtn = document.createElement("button");
          viewBtn.textContent = "查看測驗";
          viewBtn.onclick = () => {
            window.location.href = `student-quiz-view.html?quiz_id=${q.quiz_id}&course_id=${courseId}`;
          };
          div.appendChild(viewBtn);
        } else {
          const startBtn = document.createElement("button");
          startBtn.textContent = "開始作答";
          startBtn.onclick = () => {
            window.location.href = `student-quiz-answer.html?quiz_id=${q.quiz_id}&course_id=${courseId}`;
          };
          div.appendChild(startBtn);
        }
        quizzesContainer.appendChild(div);
      });
    } catch (error) {
      console.error(error);
      quizzesContainer.innerHTML = "<p>載入測驗失敗，請稍後再試。</p>";
    }
  }
  loadQuizzes();
});
