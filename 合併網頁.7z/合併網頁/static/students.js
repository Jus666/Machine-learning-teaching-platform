document.addEventListener("DOMContentLoaded", () => {
    console.log("學生管理頁面初始化");
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get("course_id");
    const studentListDiv = document.getElementById("student-list");
    const pendingRequestsDiv = document.getElementById("pending-requests");
  
    async function loadStudents() {
      try {
        const response = await fetch(`/get_students_for_course/${courseId}`);
        if (!response.ok) {
          console.error("無法加載該課程的學生");
          return;
        }
        const students = await response.json();
        studentListDiv.innerHTML = "";
        if (students.length === 0) {
          studentListDiv.innerHTML = "<p>目前沒有學生。</p>";
          return;
        }
        students.forEach(student => {
          const li = document.createElement("li");
          li.textContent = `${student.full_name} (${student.username})`;
          const removeBtn = document.createElement("button");
          removeBtn.textContent = "移除";
          removeBtn.addEventListener("click", async () => {
            try {
              const response = await fetch(`/remove_student/${courseId}/${student.id}`, { method: "DELETE" });
              if (response.ok) {
                alert("成功移除學生！");
                loadStudents();
              } else {
                alert("移除學生失敗！");
              }
            } catch (error) {
              console.error("移除學生時發生錯誤：", error);
            }
          });
          li.appendChild(removeBtn);
          studentListDiv.appendChild(li);
        });
      } catch (error) {
        console.error("加載學生時發生錯誤：", error);
      }
    }
  
    async function loadPendingRequests() {
      try {
        const response = await fetch(`/get_pending_requests/${courseId}`);
        if (!response.ok) {
          console.error("無法加載學生申請");
          return;
        }
        const requests = await response.json();
        pendingRequestsDiv.innerHTML = "";
        if (requests.length === 0) {
          pendingRequestsDiv.innerHTML = "<p>目前沒有學生申請。</p>";
          return;
        }
        requests.forEach(request => {
          const li = document.createElement("li");
          li.textContent = `${request.full_name || "未知"} (${request.username || "未知"})`;
          const approveBtn = document.createElement("button");
          approveBtn.textContent = "接受";
          approveBtn.addEventListener("click", async () => {
            try {
              const response = await fetch(`/approve_request/${request.enrollment_id}`, { method: "POST" });
              if (response.ok) {
                alert("已接受學生申請");
                loadPendingRequests();
              } else {
                alert("接受失敗，請重試！");
              }
            } catch (error) {
              console.error("接受申請時發生錯誤：", error);
            }
          });
          const rejectBtn = document.createElement("button");
          rejectBtn.textContent = "拒絕";
          rejectBtn.addEventListener("click", async () => {
            try {
              const response = await fetch(`/reject_request/${request.enrollment_id}`, { method: "POST" });
              if (response.ok) {
                alert("已拒絕學生申請");
                loadPendingRequests();
              } else {
                alert("拒絕失敗，請重試！");
              }
            } catch (error) {
              console.error("拒絕申請時發生錯誤：", error);
            }
          });
          li.appendChild(approveBtn);
          li.appendChild(rejectBtn);
          pendingRequestsDiv.appendChild(li);
        });
      } catch (error) {
        console.error("加載學生申請時發生錯誤：", error);
      }
    }
  
    loadStudents();
    loadPendingRequests();
  });
  