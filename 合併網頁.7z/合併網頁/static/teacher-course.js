document.addEventListener("DOMContentLoaded", () => {
  console.log("教師課程管理系統初始化完成");

  // 取得頁面上的 DOM 元素
  const courseListContainer = document.getElementById("course-list-container");
  const createCourseSection = document.getElementById("create-course-section");
  const createCourseForm = document.getElementById("create-course-form");
  const backToCourseListBtn = document.getElementById("back-to-course-list");
  const courseDetailSection = document.getElementById("course-detail-section");
  const courseTitle = document.getElementById("course-title");
  let currentCourseId = null;

  // 從後端取得教師的課程資料
  async function loadCoursesForTeacher() {
    try {
      const response = await fetch("/get_teacher_courses");
      const courses = await response.json();
      courseListContainer.innerHTML = "";
      if (courses.length === 0) {
        courseListContainer.innerHTML = "<p>目前沒有課程。</p>";
        return;
      }
      // 逐一產生課程卡片
      courses.forEach(course => {
        const courseCard = document.createElement("div");
        courseCard.classList.add("course-card");

        // 課程標題
        const titleElem = document.createElement("h3");
        titleElem.textContent = course.course_name || "未命名課程";
        courseCard.appendChild(titleElem);

        // 查看課程按鈕，點擊後顯示該課程的詳細功能選單
        const viewBtn = document.createElement("button");
        viewBtn.textContent = "查看課程";
        viewBtn.addEventListener("click", () => {
          currentCourseId = course.id;
          courseTitle.textContent = course.course_name;
          // 隱藏課程列表及創建表單，顯示課程詳情區域
          document.getElementById("teacher-course-list").style.display = "none";
          createCourseSection.style.display = "none";
          courseDetailSection.style.display = "block";
        });
        courseCard.appendChild(viewBtn);

        courseListContainer.appendChild(courseCard);
      });
    } catch (error) {
      console.error("加載教師課程時發生錯誤：", error);
    }
  }

  // 點擊「創建新課程」按鈕，顯示創建課程表單，隱藏課程列表
  document.getElementById("create-course-btn").addEventListener("click", () => {
    createCourseSection.style.display = "block";
    courseListContainer.style.display = "none";
  });

  // 點擊「取消」按鈕，返回課程列表，隱藏創建課程表單
  document.getElementById("cancel-create-course").addEventListener("click", () => {
    createCourseSection.style.display = "none";
    courseListContainer.style.display = "block";
    createCourseForm.reset();
  });

  // 提交創建課程表單，呼叫後端 /create_course API
  createCourseForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const courseName = document.getElementById("course-name").value.trim();
    const courseDescription = document.getElementById("course-description").value.trim();
    if (!courseName || !courseDescription) {
      alert("課程名稱與描述不能為空！");
      return;
    }
    try {
      const response = await fetch("/create_course", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: courseName, description: courseDescription })
      });
      if (response.ok) {
        alert("課程創建成功！");
        createCourseForm.reset();
        createCourseSection.style.display = "none";
        courseListContainer.style.display = "block";
        loadCoursesForTeacher();
      } else {
        const errorData = await response.json();
        alert(`課程創建失敗：${errorData.error || "未知錯誤"}`);
      }
    } catch (error) {
      console.error("創建課程時發生錯誤：", error);
      alert("創建課程失敗，請稍後重試！");
    }
  });

  // 當點擊功能選單按鈕時，將導向對應的後端路由
  document.querySelectorAll(".function-btn").forEach(btn => {
    btn.addEventListener("click", (e) => {
      const targetPage = e.target.getAttribute("data-target");
      // 假設 data-target 內的值為 "materials.html"、"homeworks.html" 等，
      // 將 .html 移除並在前面加上 "/"，形成正確路由，例如 "/materials"
      let route = targetPage;
      if (route.endsWith('.html')) {
        route = '/' + route.replace('.html', '');
      }
      // 導向指定路由，同時附帶目前的課程ID
      window.location.href = `${route}?course_id=${currentCourseId}`;
    });
  });

  // 初始化載入教師的課程
  loadCoursesForTeacher();
});
