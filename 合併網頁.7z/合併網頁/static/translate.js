document.getElementById("translateButton").addEventListener("click", translateText);

function translateText() {
    const text = document.getElementById("sourceText").value.trim();
    const targetLanguage = document.getElementById("languageSelect").value;

    if (!text) {
        alert("請輸入文字進行翻譯！");
        return;
    }

    fetch("/api/translate", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            text: text,
            source_language: "auto", // 自動偵測源語言
            target_language: targetLanguage,
        }),
    })
        .then((response) => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then((data) => {
            if (data.translated_text) {
                document.getElementById("translatedText").innerText = data.translated_text;
            } else {
                document.getElementById("translatedText").innerText = "翻譯失敗，請重試。";
            }
        })
        .catch((error) => {
            console.error("Error during translation:", error);
            document.getElementById("translatedText").innerText = "伺服器錯誤，請稍後再試。";
        });
}
